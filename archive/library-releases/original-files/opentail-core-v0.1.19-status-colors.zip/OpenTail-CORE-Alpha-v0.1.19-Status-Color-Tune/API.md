# OpenTail CORE Alpha v0.1.19 — Bench-only API

Same-origin JSON HTTP on the CORE Wi-Fi AP (`http://192.168.4.1`). The protocol header remains `opentail-core-alpha-v1` for backward compatibility; feature discovery is through `/api/v1/capabilities`.

## Existing interfaces preserved

- `GET /api/v1/status` — raw 8-bit physical `input_mask`, logical `simulated_mask`, logical `effective_mask`, arbitration/status LED/frames/FPS. New read-only `physical_function_mask` adds the remapped physical input function bits; the previous fields remain.
- `GET /api/v1/outputs` — unchanged **revision 2**, 2 physical outputs, up to 522 allocated pixels/output, 1–8 zones/output, active size, color order, calibration, role, zone readback and saved status.
- `POST /api/v1/outputs` — unchanged v0.1.17 request and readback behavior, committed to `ot_output_cfg/profile_v2`.
- `GET/POST /api/v1/show`, `/api/v1/show/start`, `/api/v1/show/stop`, `/api/v1/demo`, `/api/v1/simulate`, `/api/v1/stop`, status LED endpoints — preserved.

## New configurable trigger inputs

`GET /api/v1/triggers` returns:

```json
{
  "revision": 1,
  "saved_on_device": false,
  "bench_only": true,
  "physical_inputs": 8,
  "fixed_active_low": true,
  "raw_input_mask": 0,
  "physical_function_mask": 0,
  "effective_mask": 0,
  "supported_functions": ["disabled","park","brake","left","right","reverse","aux1","aux2","aux3"],
  "inputs": [
    {"index":1,"gpio":4,"function":"park","active":false},
    {"index":2,"gpio":5,"function":"brake","active":false},
    {"index":3,"gpio":6,"function":"left","active":false},
    {"index":4,"gpio":7,"function":"right","active":false},
    {"index":5,"gpio":8,"function":"reverse","active":false},
    {"index":6,"gpio":9,"function":"aux1","active":false},
    {"index":7,"gpio":10,"function":"aux2","active":false},
    {"index":8,"gpio":11,"function":"aux3","active":false}
  ]
}
```

`POST /api/v1/triggers` requires all eight input records (exact `index` 1 through 8 order):

```json
{"revision":1,"inputs":[{"index":1,"function":"park"},{"index":2,"function":"brake"},{"index":3,"function":"left"},{"index":4,"function":"right"},{"index":5,"function":"reverse"},{"index":6,"function":"aux1"},{"index":7,"function":"aux2"},{"index":8,"function":"aux3"}]}
```

- 200 JSON: returns the same document shape as GET after saving and NVS commit.
- 400: invalid/missing fields, unsupported function or wrong revision.
- 409: real inputs, simulations, demos or Shows active. Stop tests and release physical optocoupler inputs first.
- 500: cannot commit to NVS; previous active mapping is retained.

**Function semantics:** physical IN bits are interpreted through the configured map; multiple INs may share a function. `disabled` contributes no logical signal. `simulated_mask` is **already logical**, so simulator `park`/`brake`/`left`/`right`/`reverse` selections remain unchanged after remapping physical inputs. Existing Output Manager zone roles (`park_brake`, `parking`, `brake`, `left_turn`, `right_turn`, `reverse`, `aux1`–`aux3`, `decorative`, `off`) use logical signals, not physical pin numbers.

**Safety:** no automotive hardware failover, overvoltage protection, validated power distribution or road-legal operation. Bench testing only. No custom BLE Studio transport is implemented.
