# OpenTail CORE Alpha v0.1.19

- Isolated BLE-only onboard RGB status change to (140,0,255).
- Isolated Wi-Fi+BLE onboard RGB status change to (0,255,145).
- Bumped firmware version and matching Studio copy to v0.19.46 (UI version-only changes).
- Retains v0.1.18 Universal Trigger Manager, verified dynamic zones, saved configurations and existing status priorities.

25/25 host test gates pass. ESP-IDF build, boot, BLE/Wi-Fi color observation not yet verified on hardware.
