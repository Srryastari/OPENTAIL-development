# Windows installation — v0.1.19 (ESP-IDF v5.5.5)

1. Extract `opentail-core-v0.1.19-status-colors.zip` under `C:\Users\astari\Desktop\OpenTail` as a NEW project alongside your previous versions.
2. Open ESP-IDF PowerShell, then:

```powershell
cd "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.19-Status-Color-Tune"
```

3. Restore your existing custom Wi-Fi password without printing it. The following reads a local copy of your configured `sdkconfig` from the previous project and appends the secret line to the new `sdkconfig.defaults`. It aborts if the source is missing or still the default password.

```powershell
$base = "$env:USERPROFILE\Desktop\OpenTail"
$prior = @("$base\OpenTail-CORE-Alpha-v0.1.18-Universal-Triggers\sdkconfig", "$base\OpenTail-CORE-Alpha-v0.1.17-Universal-Bench\sdkconfig")
$line = $null
foreach ($candidate in $prior) {
  if (Test-Path $candidate) {
    $found = Select-String -Path $candidate -Pattern '^CONFIG_OPENTAIL_AP_PASSWORD=' | Select-Object -Last 1
    if ($found -and $found.Line -notmatch 'OpenTailLab-ChangeMe') { $line = $found.Line; break }
  }
}
if (!$line) { throw "No configured custom password found. Use idf.py menuconfig instead." }
foreach ($file in @('sdkconfig','sdkconfig.defaults')) {
  if (!(Test-Path $file)) { New-Item -ItemType File -Path $file | Out-Null }
  $rest = @(Get-Content $file | Where-Object { $_ -notmatch '^CONFIG_OPENTAIL_AP_PASSWORD=' })
  [System.IO.File]::WriteAllLines((Join-Path (Get-Location).Path $file), [string[]]($rest + $line), [System.Text.UTF8Encoding]::new($false))
}
Write-Host "Custom AP password applied without displaying it."
```

4. Build FIRST:

```powershell
idf.py set-target esp32s3
idf.py build
```

If the target command rewrites `sdkconfig`, verify that the password remains custom (without displaying it) before flashing. Only continue if `Project build complete` is shown.

5. Stop shows, power down external LED supply, ensure USB COM port free, then `idf.py -p COM9 flash` **without erase-flash**. Reconnect Studio using `http://192.168.4.1/studio` and confirm version `0.19.46`. If the status LED hue differs in real life, record the observation before adjusting again.

6. Verify saved GPIO16/17 output profiles and trigger mapping read back intact. Do not repeat previously verified physical tests unless an observed regression or code change requires it.

**Note:** ZIP files use normalized past file timestamps to avoid the earlier Windows Ninja/CMake reconfigure loop.
