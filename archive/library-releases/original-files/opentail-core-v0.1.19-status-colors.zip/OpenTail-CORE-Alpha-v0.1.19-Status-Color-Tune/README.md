# OpenTail CORE Alpha v0.1.19 — status-color refinement

**ESP-IDF source candidate, not cross-compiled or tested on an ESP32 in this environment.** Based directly on v0.1.18 Universal Trigger Manager. The previously user-confirmed physical baseline is v0.1.17; v0.1.18 device status must not be assumed.

## Changes (isolated)

- BLE-only onboard status pixel: raw RGB `160,0,255` -> **`140,0,255`**, a small move toward saturated blue-purple.
- Both Wi-Fi Studio and BLE connected: raw RGB `0,255,205` -> **`0,255,145`**, more teal and less sky blue.
- Firmware version `0.1.19-alpha`; embedded and standalone Studio copies `v0.19.46` (version-only UI bump; original controls retained).

No GPIO or output protocol changes. The universal 8-input Trigger Manager from v0.1.18, two physical pixel outputs GPIO16/17, dynamic 1–8 zones, NVS keys, BLE service and info characteristic, original show-mode rainbow status, fault priority and startup strobe remain unchanged.

## Before any flash

- Keep your last proven v0.1.17 firmware available for rollback.
- You **must** build on Windows using ESP-IDF 5.5.5 and confirm `Project build complete`.
- Restore the custom AP password in `sdkconfig` or `sdkconfig.defaults` from the previously configured project before build; no secrets are included in this ZIP.
- Do not run `erase-flash` or use high-power LED show effects on the existing 12V 4A test supply.
- GPIO48 onboard colors require an actual device check; host RGB unit tests do not establish real optical hues.

See `INSTALL-WINDOWS.md` for the step-by-step process. The matching standalone `.htm` files are also in this ZIP.

## Host regression report

25/25 gates passed, including six C host test suites, prior trigger/output arbitration, Studio save/readback mocks, and embedded/standalone Studio identity. Cross compilation and hardware validation pending.
