# OpenTail Android v0.1.7 — Unified Mobile Interface

This release implements the approved OpenTail UI concept in the actual Android WebView app, not as a static mockup:

- **One OpenTail header** with a controller connection badge and compact Wi-Fi and Bluetooth status cards.
- **One bottom navigation bar:** Home · Shows · Triggers · Layout · Settings.
- **Home, Triggers and Layout** now open as compact overview screens, not the large legacy Studio pages. They read live CORE output/trigger configuration when connected. The complete legacy editors remain reachable with **Edit** actions. Overview cards never send writes.
- **Show Modes** places output, zone, effect and Start/Stop upfront. Color, brightness, speed and timer are tucked under **Customize** and retain working BLE commands. Wi-Fi keeps its existing controls.
- **Settings screen** contains Wi-Fi connect/settings, Bluetooth discovery/authorization, native haptic and reconnection options, Studio theme, diagnostics, advanced Studio connection tools and Offline Studio.
- The duplicate native toolbars and separate BLE show dialog are removed. The original Studio pages, output mapping, triggers, presets, project import/export, native CORE Wi-Fi effects, and diagnostics remain accessible.
- When Wi-Fi becomes unavailable, the Android wrapper can load its **offline Studio** and keep the BLE control screen available if BLE remains connected/authorized.
- The status bar and navigation area are respected through the WebView layout and CSS safe-area padding.

## Compatibility and scope

- CORE **v0.1.20** and Studio **v0.19.47** stay unchanged.
- Existing BLE bench service/protocol, device authorization, Wi-Fi controls, haptics, preferred-device reconnection, output settings and firmware remain unchanged.
- Only Android app UI/integration is updated. A matching firmware/standalone `.htm` update is **not required** for this Android-only UI release.
- Firmware-level road safety, protective electronics, secure production pairing and hardware failover are **not implemented**. BLE effects are bench only.

## Easy APK build on Windows

1. Download and **Extract All** from the v0.1.7 ZIP. Do not double-click the launcher from within the ZIP preview.
2. Open `OpenTail-Android-v0.1.7` and double-click **`BUILD-APK.bat`**.
3. The launcher uses the JDK 17/21, installed Android SDK and Gradle 8.11.1, then runs `:app:assembleDebug`.
4. Successful builds produce `app\build\outputs\apk\debug\app-debug.apk` and open Explorer at that file.
5. Install the debug APK over the existing OpenTail app. If a signing conflict appears, preserve/export your saved project before considering uninstall.

## Device acceptance

- Confirm the header, two connection cards, and exactly one five-item bottom navigation.
- Open Shows, confirm the inline Wi-Fi/Bluetooth switch and no old BLE pop-up.
- Select Bluetooth and test the already-working brief Solid/Rainbow effects on the GPIO17 strip at low brightness.
- Turn Wi-Fi off and confirm BLE effects remain accessible if authorized.
- Return to Wi-Fi: CORE native controls must still work.
- Check compact Layout/Triggers overviews show live CORE data and **Edit** opens the original full editor; Settings can open Haptics, advanced CORE controls and Diagnostics.
- Verify BLE/Wi-Fi automatic reconnection, preferred controller, haptics and Android system navigation.

**Validation:** Java parsing, JavaScript syntax, existing BLE panel smoke tests, unified-shell navigation smoke tests, checksum integrity, and static regression checks completed here. This release has not been compiled with the Android SDK here; Android SDK APK compilation and phone hardware/UI testing are **not** possible in this environment; they're pending on your phone. Do not represent them as passed.

## Visual acceptance criterion

The in-chat concept reference (not the older Studio screenshot) is authoritative: compact header, two connection cards, a single Show Modes card with transport toggle and short settings, and five-item bottom nav. See VISUAL-REFERENCE.md.

## v0.1.7
See UI-REDESIGN.md for the precise scope and unchanged Live Lighting Preview.
