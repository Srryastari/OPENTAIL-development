# OpenTail Android v0.1.7 — interactive concept visual implementation

Phone-sized previews in visual-reference/*.png are from local Chromium at 390 × 780 CSS pixels with mocked connection state. They are **not screenshots of a real phone**.

The approved in-chat concept is the design target: black surfaces, outlined round pill controls, white slider thumbs, instant percentages, green active/connected states, one fixed five-tab navigation, and the same interaction semantics.

This is a first interactive implementation, not a claim of pixel-identical reproduction across Android screen sizes. Preserve the existing Live Lighting Preview engine exactly as-is; it remains accessible from Home → Live Lighting Preview.
