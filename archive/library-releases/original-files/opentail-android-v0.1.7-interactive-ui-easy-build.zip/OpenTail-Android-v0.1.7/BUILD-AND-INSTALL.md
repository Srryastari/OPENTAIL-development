# Install OpenTail Android v0.1.7

1. Right-click the ZIP and choose Extract All (do **not** run scripts inside compressed ZIP viewer).
2. Open `OpenTail-Android-v0.1.7` and double-click `BUILD-APK.bat`.
3. After successful build, locate `app\build\outputs\apk\debug\app-debug.apk`.
4. Install over v0.1.6 if signatures match; retain older APK/project for rollback. Do not uninstall without exporting saved designs.
5. Open Shows → Bluetooth. Check output/zone/effect selectors, live brightness/speed percentages, Start/Stop, and Customize for color/timer.
6. From Home, tap **Live Lighting Preview**: this opens the **existing preview**, without replacing its rendering engine.

The Android project bundles a redesigned offline Studio v0.19.48. Standalone `opentail.htm` and `opentail-v0.19.48.htm` are separate downloads for WLED hosting. CORE v0.1.20 requires **no reflash** for this UI-only update; its built-in hosted Studio remains on its prior version until a matching firmware update.

Build requires working JDK 17/21 and Android SDK. APK compile and physical results are pending.
