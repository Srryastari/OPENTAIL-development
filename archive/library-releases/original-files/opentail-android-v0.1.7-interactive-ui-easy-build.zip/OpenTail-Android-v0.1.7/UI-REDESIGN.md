# OpenTail UI / color / behavior redesign v0.1.7

## What was changed
- Monochrome surfaces, rounded pill selector controls, consistent state colors, focus rings and pressed feedback.
- BLE Show Modes keeps output/zone/effect selectors, brightness and speed visible like the approved in-chat example. Color and automatic stop remain in Customize. Existing event handlers and BLE commands remain unchanged.
- Fixed 5-tab Android navigation, compact connection cards and matching Home/Trigger/Layout summary surfaces. The Home screen opens the **existing** Live Lighting Preview through its advanced Dashboard; no new preview engine was created.
- Studio standalone v0.19.48 has the same dark form-control language on existing functional editor surfaces. It is independently uploadable as opentail.htm.

## Protected region
**DO NOT CHANGE** original Live Lighting Preview markup, pixel layout renderer, simulator, per-pixel state or styles. This release only adds scoped CSS and changes BLE panel DOM placement. The preview CSS and logic in `opentail.htm` remain byte-for-byte in the original source, other than added independent CSS and display version string.

## Validation boundary
Source/static and browser DOM tests here do not prove on-device haptics, BLE effects, or visual identity on a Samsung phone. Your previous hardware results remain verified on the prior versions, pending v0.1.7 hardware regression.
