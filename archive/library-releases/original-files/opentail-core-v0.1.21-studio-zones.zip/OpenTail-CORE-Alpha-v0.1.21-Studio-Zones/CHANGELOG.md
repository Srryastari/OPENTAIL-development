# CORE v0.1.21 / Studio v0.19.50

Only embedded Studio refresh and firmware-reported version update. Existing BLE, WS2815 GPIO16/GPIO17 control and saved settings remain source-identical to v0.1.20 except version strings. Studio preview now takes saved CORE output zones rather than the unrelated local WLED layout, retaining the existing Live/Synced/Simulated rendering and section strip styling. No new hardware output capability claimed.
