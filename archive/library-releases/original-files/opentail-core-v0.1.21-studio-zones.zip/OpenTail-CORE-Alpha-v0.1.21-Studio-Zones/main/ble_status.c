/* OpenTail CORE BLE v1: temporary authorized BENCH SHOW commands only.
 * This firmware has NO automotive-safe backup lighting or secure production pairing.
 * Provision a fresh 128-bit token on CORE WPA2 Wi-Fi; authorize one BLE connection.
 * No trigger / physical input / output mapping changes are exposed via BLE.
 */
#include "sdkconfig.h"
#include "esp_log.h"
#include "esp_random.h"
#include "status_led.h"
#include "ble_command.h"
#include <stdio.h>
#include <string.h>
extern bool ot_ble_apply_show(const ot_ble_show_packet_t *request);
extern void ot_ble_stop_show(void);
static uint8_t token[OT_BLE_TOKEN_BYTES];
static bool token_ready=false;
void ot_ble_session_hex(char out[33]){
    if(!out)return;
    out[0]='\0';
    if(!token_ready)return;
    for(unsigned i=0;i<OT_BLE_TOKEN_BYTES;i++)snprintf(out+i*2,3,"%02x",token[i]);
}
#if CONFIG_BT_ENABLED && CONFIG_BT_NIMBLE_ENABLED
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "host/util/util.h"
#include "os/os_mbuf.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
static const char *TAG="OT_BLE";
static uint8_t addr_type;
static uint16_t active_conn=BLE_HS_CONN_HANDLE_NONE;
static bool authorized=false;
static ot_ble_result_t last_result=OT_BLE_ERR_AUTH;
static const ble_uuid128_t ot_service_uuid=BLE_UUID128_INIT(0x21,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_info_uuid=BLE_UUID128_INIT(0x22,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_cmd_uuid=BLE_UUID128_INIT(0x23,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_reply_uuid=BLE_UUID128_INIT(0x24,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static int info_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)conn;(void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    const char *message="OpenTail CORE 0.1.21 | BLE bench show v1 | WPA2 bootstrap required";
    return os_mbuf_append(ctx->om,message,strlen(message))==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int reply_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    const char *result=conn==active_conn?ot_ble_result_string(last_result):"ERR AUTH";
    return os_mbuf_append(ctx->om,result,strlen(result))==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int command_write(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_WRITE_CHR || conn!=active_conn)return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t buf[20];uint16_t n=0;
    if(ble_hs_mbuf_to_flat(ctx->om,buf,sizeof(buf),&n)!=0){last_result=OT_BLE_ERR_WIRE;return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;}
    ot_ble_show_packet_t show={0};
    last_result=ot_ble_parse(buf,n,token,&authorized,&show);
    if(last_result==OT_BLE_OK_SHOW && !ot_ble_apply_show(&show))last_result=OT_BLE_ERR_BUSY;
    if(last_result==OT_BLE_OK_STOP)ot_ble_stop_show();
    /* Errors are returned by read-only reply characteristic; always acknowledge write. */
    return 0;
}
static const struct ble_gatt_chr_def characteristics[]={
  {.uuid=&ot_info_uuid.u,.access_cb=info_read,.flags=BLE_GATT_CHR_F_READ},
  {.uuid=&ot_cmd_uuid.u,.access_cb=command_write,.flags=BLE_GATT_CHR_F_WRITE},
  {.uuid=&ot_reply_uuid.u,.access_cb=reply_read,.flags=BLE_GATT_CHR_F_READ},
  {0}
};
static const struct ble_gatt_svc_def services[]={
  {.type=BLE_GATT_SVC_TYPE_PRIMARY,.uuid=&ot_service_uuid.u,.characteristics=characteristics},{0}
};
static int gap_event(struct ble_gap_event *ev,void *arg);
static void advertise(void){
    struct ble_hs_adv_fields fields={0};
    fields.flags=BLE_HS_ADV_F_DISC_GEN|BLE_HS_ADV_F_BREDR_UNSUP;
    const char *name=ble_svc_gap_device_name();
    fields.name=(uint8_t*)name;fields.name_len=strlen(name);fields.name_is_complete=1;
    int rc=ble_gap_adv_set_fields(&fields);
    if(rc){ESP_LOGE(TAG,"Advertising fields failed: %d",rc);return;}
    struct ble_gap_adv_params p={0};p.conn_mode=BLE_GAP_CONN_MODE_UND;p.disc_mode=BLE_GAP_DISC_MODE_GEN;
    rc=ble_gap_adv_start(addr_type,NULL,BLE_HS_FOREVER,&p,gap_event,NULL);
    if(rc)ESP_LOGE(TAG,"Advertising failed: %d",rc);
}
static int gap_event(struct ble_gap_event *ev,void *arg){
    (void)arg;
    if(ev->type==BLE_GAP_EVENT_CONNECT){
        if(ev->connect.status==0){active_conn=ev->connect.conn_handle;authorized=false;last_result=OT_BLE_ERR_AUTH;ot_st_ble_connected(true);}
        else advertise();
    }else if(ev->type==BLE_GAP_EVENT_DISCONNECT){
        active_conn=BLE_HS_CONN_HANDLE_NONE;authorized=false;last_result=OT_BLE_ERR_AUTH;
        ot_st_ble_connected(false);ot_ble_stop_show();advertise();
    }else if(ev->type==BLE_GAP_EVENT_ADV_COMPLETE)advertise();
    return 0;
}
static void on_sync(void){
    int rc=ble_hs_util_ensure_addr(0);
    if(!rc)rc=ble_hs_id_infer_auto(0,&addr_type);
    if(rc){ESP_LOGE(TAG,"BLE address error: %d",rc);return;}
    advertise();
}
static void host_task(void *arg){(void)arg;nimble_port_run();nimble_port_freertos_deinit();}
void ot_ble_start(void){
    esp_fill_random(token,sizeof(token));
    token_ready=true;
    esp_err_t err=nimble_port_init();
    if(err!=ESP_OK){token_ready=false;ESP_LOGE(TAG,"NimBLE init failed: %s",esp_err_to_name(err));return;}
    ble_svc_gap_init();ble_svc_gatt_init();
    int rc=ble_svc_gap_device_name_set("OpenTail CORE");
    if(!rc)rc=ble_gatts_count_cfg(services);
    if(!rc)rc=ble_gatts_add_svcs(services);
    if(rc){token_ready=false;ESP_LOGE(TAG,"BLE service registration failed: %d",rc);return;}
    ble_hs_cfg.sync_cb=on_sync;
    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG,"BLE bench-show control ready. Wi-Fi authorization required after every BLE connection.");
}
#else
void ot_ble_start(void){token_ready=false;}
#endif
