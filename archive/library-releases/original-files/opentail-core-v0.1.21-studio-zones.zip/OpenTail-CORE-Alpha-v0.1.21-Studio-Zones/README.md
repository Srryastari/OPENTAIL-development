# OpenTail CORE v0.1.21 / Studio v0.19.50

This is a Studio/zone-preview integration update based on the BLE-capable CORE v0.1.20 source.

- Firmware BLE command protocol, GPIO outputs, trigger logic, NVS mapping and hardware behavior are unchanged.
- `/studio` serves OpenTail Studio v0.19.50, including the same Live Lighting Preview engine and read-only CORE Output Manager zone adapter.
- The preview renders one section per saved nonzero zone on each output. This is visualization only; no SPI/RMT pixel data is inferred.
- No automotive safety/failover certification. Bench-only operation.
- **Before flashing:** preserve the existing CORE AP password with PREPARE-AND-BUILD.ps1, confirm `Project build complete`, use `idf.py -p <actual port> flash` (no erase-flash).
- **Not compiled with ESP-IDF in this environment.** Host regression tests below do not constitute hardware validation.
