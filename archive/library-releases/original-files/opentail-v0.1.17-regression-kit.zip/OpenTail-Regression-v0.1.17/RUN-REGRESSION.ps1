param(
    [string]$Project = "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.17-Universal-Bench"
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (!(Test-Path (Join-Path $Project 'main\opentail_core.c'))) {
    throw "OpenTail source folder not found: $Project"
}
python (Join-Path $here 'regression.py') $Project
if ($LASTEXITCODE -ne 0) { throw "OpenTail regression checks FAILED (exit $LASTEXITCODE)" }
Write-Host 'Host regression checks completed. No device was flashed.' -ForegroundColor Green
