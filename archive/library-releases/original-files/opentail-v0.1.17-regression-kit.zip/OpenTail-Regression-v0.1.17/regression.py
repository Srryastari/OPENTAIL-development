#!/usr/bin/env python3
"""OpenTail v0.1.17 host-only regression runner. Never touches the device."""
import argparse
import gzip
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print('PASS:', message)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('project',type=Path,help='Path to extracted OpenTail-CORE-Alpha-v0.1.17-Universal-Bench folder')
    args=parser.parse_args()
    project=args.project.resolve()
    qa=Path(__file__).resolve().parent
    firmware=(project/'main/opentail_core.c').read_text(encoding='utf-8')
    om=(project/'main/output_manager.h').read_text(encoding='utf-8')
    cpp=(project/'main/output_manager.c').read_text(encoding='utf-8')
    studio=(project/'opentail-v0.19.44.htm').read_bytes()
    checks=0
    def must(x,m):
        nonlocal checks
        check(x,m)
        checks+=1
    print('OpenTail v0.1.17 REGRESSION — HOST TESTS ONLY')
    print('Project:', project)
    must((project/'opentail.htm').read_bytes()==studio,'Standalone Studio filenames are identical')
    must(gzip.decompress((project/'main/assets/studio.htm.gz').read_bytes())==studio,'Firmware-embedded Studio matches standalone .htm')
    must(b"const OT_VERSION='0.19.44'" in studio,'Studio version matches v0.19.44')
    must(re.search(r'#define\s+OT_OM_VERSION\s+2\b',om) is not None,'CORE output API revision 2')
    must(re.search(r'#define\s+OT_OM_ZONES\s+8\b',om) is not None,'CORE supports up to 8 zones per output')
    must(re.search(r'#define\s+OT_OM_OUTPUTS\s+2\b',om) is not None,'Two physical CORE output profiles')
    must('OT_OUT_LEFT_GPIO 16' in (project/'main/board_config.h').read_text(),'GPIO16 is Pixel OUT 1')
    must('OT_OUT_RIGHT_GPIO 17' in (project/'main/board_config.h').read_text(),'GPIO17 is Pixel OUT 2')
    must('cJSON_AddNumberToObject(obj,"revision",OT_OM_VERSION)' in firmware,'GET /outputs firmware exports API revision')
    must('cJSON_AddNumberToObject(obj,"allocated_pixels_per_output",OT_CHAIN_PIXELS)' in firmware,'GET /outputs exports pixel allocation')
    must('data.revision!==2' in studio.decode() and 'data.allocated_pixels_per_output!==522' in studio.decode(),'Studio enforces matching revision and 522-pixel allocation')
    must('next.zone_count=(uint8_t)cJSON_GetArraySize(zones)' in firmware,'CORE POST parses variable zone count')
    must('return sum==o->active_pixels' in cpp and 'a->pixels' in cpp,'CORE validates zone sum against active pixel count')
    must('if(!om_save(next_all))return respond_err' in firmware,'CORE commits NVS before changing active output mappings')
    must('"profile_v2"' in firmware and 'ot_om_store_v1_t' in firmware,'CORE retains v1 migration and separate v2 configuration key')
    must('otOMSaveState=\'failed\'' in studio.decode() and 'Readback did not match saved output map' in studio.decode(),'Studio save requires confirmed readback')
    must('otOMAddZone' in studio.decode() and 'otOMRemoveZone' in studio.decode(),'Studio offers add/delete zone controls')
    must('ot_st_show_active(native_rendering)' in firmware,'Show mode status integration remains present')
    must('ot_arbitrate(combined,' in firmware,'Trigger arbitration logic is still called')

    # Run the original firmware's real C unit tests if an installed host C compiler is available.
    compiler=shutil.which('cc') or shutil.which('gcc') or shutil.which('clang')
    script=project/'tests/run-host-tests.sh'
    if compiler and shutil.which('sh') and script.is_file():
        proc=subprocess.run(['sh',str(script)],cwd=project,capture_output=True,text=True)
        print(proc.stdout, end='')
        if proc.returncode:
            print(proc.stderr, file=sys.stderr)
            raise AssertionError('CORE host C regression tests failed')
        checks+=1
        print('PASS: original CORE C unit test suite')
    else:
        print('NOT RUN: CORE C unit tests require host cc/gcc/clang and sh; ESP-IDF cross-compiler is not equivalent')
    node=shutil.which('node')
    if node:
        with tempfile.NamedTemporaryFile(suffix='.js',delete=False,mode='w',encoding='utf-8') as temp:
            # Inline script extracts; catches accidental studio syntax corruption.
            scripts=re.findall(r'<script(?:\s+[^>]*)?>(.*?)</script>',studio.decode('utf-8'),re.S|re.I)
            temp.write('\n;\n'.join(scripts))
            jsfile=temp.name
        try:
            syntax=subprocess.run([node,'--check',jsfile],capture_output=True,text=True)
            if syntax.returncode:
                print(syntax.stderr,file=sys.stderr)
                raise AssertionError('Standalone Studio JavaScript syntax test failed')
            checks+=1
            print('PASS: Studio JavaScript syntax')
        finally:
            os.unlink(jsfile)
        scenario=subprocess.run([node,str(qa/'studio-regression.mjs'),str(project)],capture_output=True,text=True)
        print(scenario.stdout,end='')
        if scenario.returncode:
            print(scenario.stderr,file=sys.stderr)
            raise AssertionError('Studio Output Manager mocked interaction tests failed')
        checks+=1
    else:
        print('NOT RUN: Studio executable tests require Node.js')
    if "CONFIG_BTDM_CTRL_MODE_BLE_ONLY=y" in (project/'sdkconfig.defaults').read_text():
        print('WARNING: ESP-IDF 5.5.5 previously reported unknown Kconfig symbol BTDM_CTRL_MODE_BLE_ONLY')
    print(f'HOST PASS: {checks} QA gates complete. Physical I/O, BLE client, NVS power-loss, and electrical failover remain unverified by these scripts.')

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('FAIL:',e,file=sys.stderr)
        sys.exit(1)
