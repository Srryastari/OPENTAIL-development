# OpenTail v0.1.17 — Regression Baseline Kit

This is a **test-only add-on** for the previously built CORE v0.1.17 / Studio v0.19.44 release. It **does not modify firmware, Studio, flash, NVS, or COM ports**.

## Windows (ESP-IDF PowerShell)

Extract this ZIP anywhere. From the extracted `OpenTail-Regression-v0.1.17` folder run:

```powershell
.\RUN-REGRESSION.ps1
```

If PowerShell policy blocks script execution, use:

```powershell
python .\regression.py "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.17-Universal-Bench"
```

It validates the embedded and downloaded Studio byte-for-byte, firmware/Studio API fields, zone-limit contract, saved-settings migration safeguards, GPIO assignments, trigger/status API integrations, and Studio syntax and mocked save/readback flows (when Node.js is present). It runs the existing C host tests if a native C compiler and `sh` are available.

`NOT RUN` is **not** a pass. The `idf.py build` check is separate and has already passed on the user's PC for v0.1.17; this kit does not build or flash firmware. Node.js may not be installed on the PC; for complete automatic Studio tests, install/run Node.js separately or rely on reports from the development environment.

**Regression distinction:** mocked HTTP readback is not real hardware persistence, and static source checks do not prove live protocol correctness. The user's previously confirmed GPIO16 522-pixel, GPIO17 30-pixel, simultaneous outputs, connection lights, rainbow status, and persistence remain the real hardware baseline. BLE control, protected automotive power, true hardware failover, and road-legal behavior are NOT verified.

Known documentation issue: `API.md` is still labeled v0.1.15 and describes the old five-zone API. Current code is v0.1.17 revision 2; update API documentation during the next combined release.
