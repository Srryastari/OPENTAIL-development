# OpenTail CORE Alpha firmware changelog

## 0.1.0-alpha — 2026-10-23

- Created independent ESP-IDF firmware project for ESP32-S3-WROOM-1-N16R8.
- Two RMT WS2815-compatible data outputs with configurable 30px-per-chain bench mode; B-R-G byte order.
- Five basic lighting functions (Park, Brake, Left/Right Turn, Reverse) on the two-channel section map.
- Eight optocoupled input channels provisioned (inputs 6–8 unassigned); basic 40ms debounce.
- Bench-only WPA2 softAP + control webpage and REST API (status, capabilities, temporary signal simulation, short RGB tests, stop).
- External level-shifter wiring and setup documentation; host pure-C tests.
- Known missing: compiled `.bin`, device flash/boot test, physical strip measurements, Bluetooth, Studio adapter, firmware effects/sequences, safety failover and production vehicle integration.
