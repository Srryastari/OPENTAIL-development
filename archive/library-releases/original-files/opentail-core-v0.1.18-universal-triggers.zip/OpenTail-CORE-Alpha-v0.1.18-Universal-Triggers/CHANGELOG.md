# OpenTail v0.1.18-alpha / Studio v0.19.45

## Added
- Independent, configurable eight-input universal trigger routing with disabled / parking / brake / left / right / reverse / auxiliary 1–3 functions.
- Trigger Manager GET/POST API v1, strict full-mapping validation, NVS persistence in a **new namespace**, and physical function mask diagnostics.
- Universal Trigger Manager card in Studio Triggers tab with read/edit/default/discard/save/reload, save conflict feedback and explicit device readback verification.
- New C host assertions and Node-based Studio mocked integration tests for trigger mapping, plus unchanged output and status regression suites.

## Preserved (software source / regression checked)
- Firmware output GPIO16 and GPIO17, 522-pixel driver allocation each, two physical outputs and independent saved Output Manager v2 settings.
- 1–8 dynamic zones, zero-length zones, color order, calibration and user-configured output names.
- Original five-function trigger defaults for IN1–IN5, brake/hazard priority and software simulation semantics.
- BLE status preview and Wi-Fi Studio; onboard amber/green/rainbow startup/status behavior and Show Modes.
- Same embedded and downloadable Studio; same WLED design editor local functionality.

## Fixed / improved
- `sdkconfig.defaults` no longer contains the obsolete ESP-IDF 5.5.5 BLE-only Kconfig symbol that previously emitted a warning.
- Source archive timestamps are normalized to a safely past date to avoid a repeat of the Ninja/CMake regeneration loop experienced with the earlier archive.
- Studio distinguishes read-only factory defaults from a mapping actually saved to NVS.

## Validation boundaries
- Host C test suites, full Studio JS syntax and mocked output/trigger API paths passed in development environment, see `REGRESSION-RESULTS.txt`.
- **ESP-IDF 5.5.5 cross-build for v0.1.18: NOT RUN here.** User must compile successfully before flashing.
- **v0.1.18 physical 12V trigger, GPIO output, NVS persistence, BLE coexistence and failover: NOT YET TESTED.** Prior v0.1.17 user tests remain the verified hardware baseline until independently repeated when hardware behavior changes.
