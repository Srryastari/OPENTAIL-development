# OpenTail CORE v0.1.18-alpha — Universal Trigger Manager

**Bench-only SOURCE RELEASE CANDIDATE, not a precompiled firmware image.** The C host tests, Studio syntax checks and mocked API interactions passed in the development environment; the full ESP-IDF 5.5.5 cross-build and user hardware tests have **not** run for this version. Build on the user's Windows ESP-IDF PC before considering a flash.

## What's new

- Physical optocoupler inputs **IN1–IN8** can be assigned to `disabled`, `park`, `brake`, `left`, `right`, `reverse`, `aux1`, `aux2`, or `aux3`.
- Defaults retain the previously bench-tested IN1 parking, IN2 brake, IN3 left, IN4 right, IN5 reverse and auxiliary IN6–IN8 assignments. Multiple physical inputs may share a function; active inputs are logically OR'ed.
- Firmware stores the new trigger mapping in a separate NVS namespace/key (`ot_trig_cfg/profile_v1`). Existing Output Manager NVS (`ot_output_cfg/profile_v2`) and earlier migration logic are **not** changed.
- `GET/POST /api/v1/triggers` with strict validation, busy conflict protection, NVS commit-before-mutation and device readback.
- Studio **v0.19.45** includes a Trigger Manager panel at **Triggers → Universal Trigger Manager**, independent of WLED's existing local trigger-animation editor.
- Standalone `opentail-v0.19.45.htm` and stable `opentail.htm` match the compressed Studio embedded in firmware.
- Removed previously reported unknown `CONFIG_BTDM_CTRL_MODE_BLE_ONLY` default for ESP-IDF 5.5.5. Other BLE status functionality is intentionally unchanged.

## Verified existing baseline (on user's v0.1.17 hardware)

- GPIO16: each main housing section, up to 522 contiguous WS2815 pixels addressed independently, low-brightness bench testing.
- GPIO17: first 30 WS2815 pixels on the second output, separate test strip.
- Both outputs illuminated simultaneously in bench test.
- Output configuration persisted across power restart, single-zone layout supported.
- Amber idle, green Studio-connected and Show Mode rainbow onboard status light.

Those **v0.1.17 hardware outcomes are not new physical measurements on v0.1.18**. Automated regression asserts unchanged base logic and source contracts; hardware verification of the new input remapping remains open.

## Currently limited to

- Two **physical** pixel outputs, GPIO16 and GPIO17 (522-pixel allocations each); the 12-output target is not implemented.
- Eight **fixed GPIO pins** (GPIO4–11) with software-configurable functions. Actual optocoupler polarity remains globally fixed in `board_config.h`, not adjustable in Studio.
- CORE native temporary effects and basic trigger colors; user-created WLED effect animations remain local Studio designs, not CORE firmware trigger programs.
- Wi-Fi Studio control with optional BLE read-only connection/status preview. Complete BLE editing remains pending.
- Automotive failover, input surge/ESD design, power distribution, failsafe road illumination and 10 switched outputs are **not** implemented. Keep OEM lighting independent; not for road use.

## Quick actions

1. Open `INSTALL-WINDOWS.md` to build safely and preserve Wi-Fi credentials/NVS.
2. On CORE v0.1.18 Wi-Fi, open `http://192.168.4.1/studio` in a fresh Private browser tab. Confirm Studio **v0.19.45**.
3. In Triggers, open Universal Trigger Manager. Load, change a function, Save to CORE, Reload device, and check it persisted. Save is blocked while a real input, simulation, demo or show is active.
4. Read `API.md` and `REGRESSION-RESULTS.txt` for precise protocol and software validation.
