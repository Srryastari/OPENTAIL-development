# Installing OpenTail CORE v0.1.18 on Windows (ESP-IDF 5.5.5)

**Do not erase flash.** You have a verified v0.1.17 controller. This v0.1.18 source is a **release candidate until it completes an ESP-IDF build on your PC**. Preserve the old project/ZIP for rollback. No source update is needed to run the automated host test kit alone.

### 1. Extract into a new project folder

Save `opentail-core-v0.1.18-universal-triggers.zip` to your Windows Desktop. In **ESP-IDF PowerShell**:

```powershell
$base = "$env:USERPROFILE\Desktop\OpenTail"
New-Item -ItemType Directory -Path $base -Force | Out-Null
Expand-Archive -LiteralPath "$env:USERPROFILE\Desktop\opentail-core-v0.1.18-universal-triggers.zip" -DestinationPath $base -Force
cd "$base\OpenTail-CORE-Alpha-v0.1.18-Universal-Triggers"
```

This is a **different project folder** from v0.1.17. Don't extract over the verified release.

### 2. Preserve the custom Wi-Fi password without revealing it

The packaged `sdkconfig.defaults` deliberately contains **no password**. Retrieve the configured line from the previously **successfully flashed** v0.1.17 source project if it exists; do not print or send it:

```powershell
$old = "$base\OpenTail-CORE-Alpha-v0.1.17-Universal-Bench\sdkconfig"
if (Test-Path $old) {
    $pw = (Select-String -Path $old -Pattern '^CONFIG_OPENTAIL_AP_PASSWORD=').Line
    if ($pw) { Add-Content -Path .\sdkconfig.defaults -Value $pw }
}
```

If that old `sdkconfig` is missing, contains the default password, or wasn't the project you actually flashed, use **`idf.py menuconfig` → OpenTail CORE Alpha → Bench-only Wi-Fi AP WPA2 password** after `set-target` to configure your existing custom password. Never paste credentials in chat.

### 3. Build first

```powershell
idf.py set-target esp32s3
idf.py build
```

Proceed **only** after `Project build complete` appears. Do not flash if there is a compile or CMake error. This ZIP was packaged with normalized **past** timestamps to avoid the previous Ninja/CMake reconfiguration loop.

### 4. Flash only after a successful build

Stop shows, disconnect external 12V LED power during flash, ensure COM9 is free (or use your actual port), and run:

```powershell
idf.py -p COM9 flash
idf.py -p COM9 monitor
```

Exit monitor with `Ctrl+]`. **Do not run `erase-flash`** or delete NVS. USB power is enough for firmware flashing; don't inject 12V into ESP32 GPIO or 5V rails.

### 5. First bench validation

1. Check boot message says `0.1.18-alpha`; Wi-Fi remains `OpenTail-CORE-Alpha` with the expected password.
2. Open `http://192.168.4.1/studio` in a new Private tab; verify Studio `v0.19.45`.
3. Confirm Layout → Universal Output Manager still has your existing per-output counts, zone names, color orders and stored calibration. Do **not** reset them.
4. Open Triggers → Universal Trigger Manager; confirm the eight **default functions** and no error. Readback should show `revision: 1`.
5. Test saving a **non-critical unused input** mapping (for example IN8 `aux3` to `disabled`) with all inputs released and effects stopped; reload and confirm. Then restore the desired default assignment and verify again. This is a *software configuration smoke test*, not a road light test.
6. If the next physical isolated 12V input test is performed, use your existing verified protected optocoupler bench setup, never 12V directly into the ESP32 pins. Verify actual function mask in `/api/v1/status`, output-zone behavior and regression against the original Brake + Hazards arbitration. Unrestricted LED current remains unsupported by your 12V 4A supply.

### Rollback

Keep `OpenTail-CORE-Alpha-v0.1.17-Universal-Bench` and its previously built binary. Flash the known working v0.1.17 **without erasing flash** if a regression occurs. Its Output Manager `profile_v2` data remains in place. The new `ot_trig_cfg` storage key is ignored by older firmware.

### Desktop Studio files

The ZIP includes both `opentail-v0.19.45.htm` and `opentail.htm`. The latter is for stable WLED `/edit` hosting (`http://10.0.0.13/opentail.htm`) when connected to WLED's network. CORE serves the same version embedded at `http://192.168.4.1/studio` on CORE Wi-Fi. Safari cache may require a new Private tab.
