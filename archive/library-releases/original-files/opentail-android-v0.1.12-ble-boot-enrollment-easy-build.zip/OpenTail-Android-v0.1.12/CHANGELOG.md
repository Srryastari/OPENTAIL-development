# OpenTail Android v0.1.12

- Added visible Pair with BOOT button for CORE v0.1.24 physical button gated bench owner enrollment.
- Android Keystore-backed AES-GCM persistent owner-key storage (hardware backing varies by phone).
- Fresh BLE challenge/response HMAC-SHA256 authorization on reconnect, no routine clear owner secret transfer.
- Legacy Wi-Fi authorization retained as optional manual fallback for prior firmware.
- Fresh installs default to BLE-first (automatic Wi-Fi disabled), existing choices preserved.
- Android versionCode 12, versionName 0.1.12 and displayed label updated.
- Core BLE output manager read/write, verified save/readback and prior UI remain.
- Warning: unauthenticated enrollment exchange is NOT production MITM-resistant.
- Static/syntax tests only here; target APK and physical BLE testing pending.
