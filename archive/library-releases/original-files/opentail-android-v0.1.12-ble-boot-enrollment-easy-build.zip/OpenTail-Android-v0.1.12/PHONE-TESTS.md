# v0.1.12 BLE-first acceptance tests (BENCH ONLY)

1. Verify CORE v0.1.24 is running; both saved outputs/zones still load via Wi-Fi Studio.
2. Keep Android phone OFF CORE Wi-Fi. Power up CORE, release BOOT, enable Bluetooth and open app Layout > Bluetooth Output Manager.
3. Find BLE > OpenTail CORE. Holding BOOT **after boot** tap Pair with BOOT. Status should become `BLE · OK AUTH`. Release BOOT.
4. Reload GPIO17. Expect its previously saved 30-pixel configuration (or current renamed saved name). Do not save during first read test.
5. Disconnect/reconnect Bluetooth without Wi-Fi; it should automatically reauthorize and reload GPIO17.
6. Optionally save a harmless GPIO17 rename, reload, power-cycle CORE, reconnect BLE, and confirm persistence; verify GPIO16 remains unchanged.
7. Verify existing Wi-Fi Studio remains reachable at 192.168.4.1/studio and all local preview triggers remain functional.
8. Negative case: without BOOT and without stored owner key on a fresh Android install, Pair should be refused; Authorize should request pairing.

Report exact messages/failed step. This is NOT vehicle/road-lighting safety validation. Initial pairing is not MITM-resistant.
