# OpenTail Studio v0.18.0 — shared web + native project

This is a **source project**, not an APK, IPA, TestFlight release, or finished Bluetooth implementation. The web UI is the v0.17.2 codebase plus a native-safe controller URL default and URL validation. It still needs hardware testing.

## Web / WLED hosted
Upload `www/opentail.htm` using WLED `/edit`, preferably rename it to `opentail-180.htm` and visit `http://4.3.2.1/opentail-180.htm`. The hosted HTML is self-contained.

## Android / iOS
1. Install Node.js 20+ and run `npm install`.
2. `npm run check`
3. Android: install Android Studio and SDK, `npm run add:android`, `npm run sync`, `npm run android`.
4. iOS: on a Mac with Xcode and CocoaPods, `npm run add:ios`, `npm run sync`, `npm run ios`. Device signing is required.
5. Native networking: WLED typically uses HTTP on a private LAN. Follow `NATIVE_PERMISSIONS.md` **after** adding each native platform. Connect your phone to the controller Wi-Fi or same LAN and use the controller's address.

## What is implemented
- Same Builder, Arrangement, Diagnostics, presets and WLED JSON/WebSocket logic as web app.
- Capacitor project scaffold with Android/iOS platform dependencies.
- Native-safe controller address fallback (`http://4.3.2.1`) and basic URL validation.

## Not yet implemented / verified
- Bluetooth controller transport (requires actual OpenTail firmware protocol, and native plugin implementation).
- Native Wi-Fi discovery and automatic controller switching.
- Secure OS-backed project storage migration; existing app still uses localStorage.
- Device-specific Android/iOS connectivity tests, APK/IPA generation, App Store/TestFlight release.
- Road-safe brake/turn/reverse control; not suitable as a safety system.

Keep existing web version and export project backups before testing.
