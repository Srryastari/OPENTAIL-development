import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.opentail.studio',
  appName: 'OpenTail Studio',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
