# Platform configuration after `npx cap add ...`

## Android
In `android/app/src/main/AndroidManifest.xml` ensure:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```
WLED on `http://4.3.2.1` requires cleartext traffic permission. Prefer a targeted network security config restricting HTTP to known controller addresses; a debug-only `android:usesCleartextTraffic="true"` is a broader fallback, not a production security setting. Confirm Android WebView allows the chosen endpoint.

## iOS
In `ios/App/App/Info.plist`, add a meaningful `NSLocalNetworkUsageDescription` explaining WLED LAN control. For HTTP WLED devices, configure a narrowly scoped App Transport Security exception for the actual controller host where supported. IP-address endpoints and local networks may require an ATS local-network exception (`NSAllowsLocalNetworking`) and device-specific validation. Avoid `NSAllowsArbitraryLoads` in production.

## Both
The phone must have a route to the WLED device (often WLED AP at 4.3.2.1); HTTP/WebSocket CORS, CSP, and platform WebView restrictions must be tested on actual devices. A web-only syntax check does not prove native connectivity. Bluetooth requires a separate implementation.
