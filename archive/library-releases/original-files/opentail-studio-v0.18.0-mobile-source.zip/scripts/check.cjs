const fs=require('node:fs');const assert=require('node:assert/strict');
const html=fs.readFileSync('www/index.html','utf8');
assert.match(html,/OpenTail Studio v0\.18\.0/);
assert.match(html,/function normalizeUrl\(/);
assert.equal((html.match(/button\('Test Trigger'/g)||[]).length,1);
assert.match(html,/function connectWled\(/);
assert.match(html,/function sendWled\(/);
assert.match(html,/function otBaseArrangementLayout\(/);
console.log('OpenTail mobile source checks passed');
