# OpenTail v0.1.6 — in-chat concept is the source of truth

The in-chat concept defines the intended layout: compact OpenTail header and Connected badge; two equal Wi-Fi/Bluetooth connection cards; single neutral Show Modes panel; Wi-Fi/Bluetooth segmented control; Output and Zone together; Effect selector; primary Start action; fixed five-tab navigation.

Details required for safety/continuity (Stop, BLE authorization, brightness, speed, runtime, status message) remain functional and accessible, but do not replace the dominant concept layout.

Palette for dark Android: neutral charcoal surfaces (#101112 / #242627), muted gray borders, green reserved for active/primary states. No green-tinted entire page. Light theme is still available.

All old CORE editor code is retained, including save/readback and physical trigger priority. The exact Android device appearance still requires phone screenshots because scaling, system bars and typography can differ.
