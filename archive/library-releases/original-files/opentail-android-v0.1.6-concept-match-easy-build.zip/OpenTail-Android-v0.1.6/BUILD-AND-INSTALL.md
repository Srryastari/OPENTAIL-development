# OpenTail Android v0.1.6 — Build and install

1. **Extract All** from the downloaded ZIP. The Windows launcher will not work when run inside the ZIP preview.
2. Open `OpenTail-Android-v0.1.6` and run `BUILD-APK.bat`.
3. The launcher locates JDK 17/21 and your Android Studio SDK, configures Gradle 8.11.1 and runs `:app:assembleDebug`.
4. On success, Explorer opens `app\build\outputs\apk\debug\app-debug.apk`.
5. Transfer to Android and install as an update. If Android refuses a signature mismatch, do not uninstall until preserving your existing projects/preferences.
6. Open OpenTail, connect Wi-Fi and BLE. Use Shows for native BLE commands, Settings for connection tools.

Build logs report errors rather than false success; upload errors if any. No CORE firmware reflash is required.
