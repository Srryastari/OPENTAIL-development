# OpenTail Android v0.1.6 — Reference-match UI pass

- Replaced green-tinted surfaces with neutral charcoal surfaces matching the approved in-chat concept more closely.
- Compact header and two equal Wi-Fi/Bluetooth cards.
- Show Modes as one card with a Settings gear, transport toggle, Output / Zone side-by-side, Effect control, and Start / Stop.
- Less top-level clutter; color, brightness, speed, and runtime remain under Customize.
- Five-item fixed bottom navigation with Android safe area.
- Home / Triggers / Layout use the same surface styles, with all Studio editors still reachable.
- Preserves native haptics, reconnection, BLE authorization, show commands, Wi-Fi Studio, saved CORE layouts and triggers.
- Firmware and standalone Studio unchanged.

This styling pass has simulated phone-size screenshots and 59 source checks, not a pixel-perfect match verified on a physical phone.
