# OpenTail Android v0.1.3 — Build and install

This is an Android Studio **source project**, not a prebuilt APK. The Android-specific inline Show Modes UI has **not** been cross-compiled against the Android SDK or tested on your phone in this environment. Previously working CORE and Android hardware behaviors remain our regression baseline.

## Quick build — Windows

1. Download the `opentail-android-v0.1.3-easy-build.zip` and select **Extract All**. Do not open `BUILD-APK.bat` inside the ZIP preview.
2. Open the extracted `OpenTail-Android-v0.1.3` directory and double-click `BUILD-APK.bat`.
3. The launcher locates JDK 17/21, Android SDK 35, and Gradle 8.11.1, builds `:app:assembleDebug`, checks that the APK exists, and opens it in Explorer.
4. Output: `app\build\outputs\apk\debug\app-debug.apk`.
5. Install over the previous OpenTail APK. Version code is incremented so it updates in place with the same signing key. If Android reports a signing conflict, export your local projects before changing or removing an installation.

## How it works

Android's WebView loads the same unmodified Studio v0.19.47 from CORE Wi-Fi, or its offline copy. Android injects `ble-show-panel.js` only on the allowlisted Studio pages, so a Wi-Fi/Bluetooth switch and inline controls appear on Show Modes without modifying firmware. The existing Wi-Fi CORE Native Effects card remains available under Wi-Fi mode. The separate native BLE Show Modes AlertDialog and toolbar button are removed. BLE command encoding, CORE authentication requirements and safety limits are unchanged from Android v0.1.2 / CORE v0.1.20.

## Validation

Run `python qa/check_release.py` and `node qa/test_ble_inline.js` in the extracted project using Python 3, Node.js, and JDK 17. The tests exercise Java syntax, scripts, source compatibility, and a mocked BLE command path. They do **not** replace Android SDK compilation or physical validation.
