# Android v0.1.3

- Replaced modal BLE Show Modes controls with an inline Studio Show Modes transport switch and BLE control panel.
- Retained native Wi-Fi controls, Bluetooth GATT command protocol, reconnect, haptics, saved settings, offline Studio, safety limits.
- No CORE firmware update required; matches CORE v0.1.20, Studio v0.19.47.
- Bundled existing Studio HTML unchanged. Added a native WebView-injected `ble-show-panel.js` specifically for Android.
- Regenerated static validation and packaging. APK build/hardware UI untested here.
