# OpenTail Android v0.1.3 — Physical acceptance checklist

**Hardware:** Use CORE v0.1.20 with your already-verified 30-LED GPIO17 test strip and a fused, appropriately powered 12 V bench supply. Leave GPIO16 and saved zone/trigger settings intact.

1. Install `app-debug.apk` as an update. Verify haptic taps still respond.
2. Connect Android Wi-Fi to `OpenTail-CORE-Alpha`; verify CORE Studio connects. Allow the preferred BLE controller to reconnect; or select **Find BLE**.
3. Open **Show Modes**. Confirm a **Wi-Fi / Bluetooth** switch appears *inside the page* and there is **no BLE Show Modes pop-up**.
4. Select **Bluetooth**, tap **Enable BLE lighting** while connected over Wi-Fi, and confirm CORE reports `OK AUTH` (authorization not automatic or permanent).
5. For the GPIO17 test strip, choose **Pixel OUT 2**, **Zone 1**, **Solid**, red, **18% slider** (maps to the existing firmware cap value 6/32), **5 seconds**; press **Start effect**. Confirm intended 30 LEDs light and other sections remain off.
6. Press **Stop** and confirm the strip stops. Try Rainbow at low brightness.
7. Switch to **Wi-Fi**. Confirm the pre-existing CORE Native Effects card returns with all of its working controls.
8. Switch back to **Bluetooth**, turn off Android Wi-Fi while keeping BLE connected and authorized; run a short effect. Confirm no Wi-Fi control is needed after authorization. Authorize again when BLE reconnects.
9. Navigate away to Layout and back to Show Modes; check controls are still inline and responsive. Confirm triggers and saved output settings still function, and no Core configuration is unexpectedly changed.
10. If the app asks you to uninstall before updating, don't uninstall until any locally saved projects are exported. Record device-specific failures separately from the host source tests.

**Bench only:** firmware brightness cap is not an electrical current limiter. Hardware trigger priority remains in CORE; vehicle failover is unverified. Do not use this feature to control road lighting.
