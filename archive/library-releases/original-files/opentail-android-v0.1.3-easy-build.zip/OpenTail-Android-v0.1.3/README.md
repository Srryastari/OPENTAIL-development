# OpenTail Android v0.1.3 — Inline Bluetooth Show Modes

Replaces the separate **BLE Show Modes** alert dialog with a mobile-friendly **Wi-Fi / Bluetooth** selector directly on the existing **Studio → Show Modes** page.

## What's changed

- Bluetooth lighting controls are now embedded in the existing Show Modes screen, including when Studio is served by CORE Wi-Fi or opened offline in Android.
- Effects: Solid, Chase, Breathe, Wipe, Rainbow; output 1, 2, or both; zone selection (1–8 or all); color picker; brightness, speed, automatic stop; Start and Stop.
- BLE authorization and controller discovery buttons live in the same Show Modes panel. No modal control window and fewer taps.
- Wi-Fi selection reveals the existing native CORE effects panel unchanged. The standard Studio UI, Wi-Fi control, BLE GATT protocol, haptic feedback, reconnection, device preferences, and saved configurations are preserved.
- BLE controls work after Wi-Fi is disabled if already authorized and connected. Initial BLE authorization still requires CORE Wi-Fi and must be repeated after BLE disconnection.
- **CORE firmware and standalone/embedded Studio HTM are unchanged**. Android injects the panel into the existing Show Modes page. Compatible with CORE v0.1.20 and Studio v0.19.47.

## Build APK — Easy Windows method

1. Right-click the downloaded ZIP and choose **Extract All**. Don't run it from inside a ZIP preview.
2. Open the extracted `OpenTail-Android-v0.1.3` folder and double-click **BUILD-APK.bat**.
3. The launcher uses JDK 17/21, Android SDK 35, and Gradle 8.11.1. With a successful build it opens the folder containing `app\build\outputs\apk\debug\app-debug.apk`.
4. Install the APK over your existing OpenTail app. If Android reports a signing conflict, don't uninstall before exporting any saved project data.

## Initial device tests

- Open Show Modes; switch between **Wi-Fi** and **Bluetooth**; no pop-up should appear.
- In Bluetooth, authorize on CORE Wi-Fi then run Solid Red on the 30-pixel GPIO17 test strip, brightness 5–10%, 5 seconds; then STOP.
- Turn off phone Wi-Fi while keeping BLE connected; run a short Rainbow show.
- Switch back to Wi-Fi; verify the original CORE Native Effects controls are available when CORE Wi-Fi is connected.
- Verify haptic taps, automatic reconnection and Studio tabs continue to function.

**Safety:** Bench-only prototype. BLE token pairing is not production-grade secure, and firmware does not provide independent road-lighting failover. Never use Bluetooth Show Modes as road-lighting controls. Firmware brightness cap is not a current limiter.

**Validation:** Static checks run offline. This release has not been compiled using the Android SDK here; an actual Android SDK build and phone UI/hardware behavior require device validation. Do not assume them passed.
