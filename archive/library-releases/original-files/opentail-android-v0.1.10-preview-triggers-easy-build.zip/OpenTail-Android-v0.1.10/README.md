# OpenTail Android v0.1.10

Approved OLED-black UI implementation and dynamic CORE zone preview. Extract All, run BUILD-APK.bat. Existing CORE firmware v0.1.20 unchanged.

See CHANGELOG.md and QA-RESULTS.txt.

Bench-only: Android APK has not been compiled or hardware-tested in this environment.

## Matching CORE Studio

When connected to CORE Wi-Fi the Android app loads Studio from the ESP32. To obtain the repaired simulated trigger preview on that screen, install matching CORE v0.1.22 (source package separately supplied). Older CORE firmware still serves the older Studio page even when the Android app itself is updated.

## Preview trigger repair
Embedded Studio v0.19.51 aligns simulated trigger colors with saved CORE zone roles. Hardware trigger tests remain independent.
