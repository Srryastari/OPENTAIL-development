# v0.1.9 visual review

Rendered 390 × 780 phone-sized browser previews under `visual-reference/`.
- `shows.png`: BLE controls, dark neutral palette, slimmer sliders/buttons
- `home.png`, `triggers.png`, `layout.png`: compact summaries
These are mocked browser renders, not Android-device screenshots. Green is intentionally limited to small connection/ready indicators. The Live Lighting Preview code was not modified.
