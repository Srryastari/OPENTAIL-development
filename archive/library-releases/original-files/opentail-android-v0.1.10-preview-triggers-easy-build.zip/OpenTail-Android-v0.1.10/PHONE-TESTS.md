# v0.1.10 phone acceptance checks

1. App installs over v0.1.8 and opens without losing controller credentials / settings.
2. Shows matches the approved OLED-black reference; output/zone/effect selectors, white pill sliders, white Start and outlined Stop work.
3. BLE authorizes and Solid and Rainbow illuminate the 30-LED GPIO17 bench strip at limited brightness; stop works.
4. Settings switches Show Modes between BLE and Wi-Fi; old native effects still available.
5. Home opens the original Live Lighting Preview. Compare its visual design to v0.1.8; it must be unchanged.
6. In CORE mode Live Lighting Preview derives rows from saved Output Manager for each physical output; rename/add/remove/reorder/resize and SAVE to CORE, reopen to verify current saved zones appear. 0-length zones not shown.
7. Test true Live/partial telemetry indicator: it MUST NOT claim CORE live pixel data (CORE doesn't expose it).
8. Haptics / Wi-Fi / BLE reconnection / Triggers / Layout / Settings regression.
9. Do not test unrestricted whole-chain brightness on the 12V 4A supply.
