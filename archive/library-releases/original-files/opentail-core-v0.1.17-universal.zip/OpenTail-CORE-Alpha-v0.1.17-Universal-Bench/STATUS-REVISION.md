# Status LED revision for v0.1.16

- Startup: single white flash (300 ms).
- Wi-Fi ready, no Studio session ever: blue pulse.
- Studio heartbeat active: green double pulse.
- Studio heartbeat absent after a prior connection (8-second timeout): blue double pulse, **not red**.
- Actual firmware fault: rapid red flash, even without Studio.
- Native show effects no longer override green/blue health and connection indication.
- Manual rainbow test is allowed at `/status-led/self-test` for 5 seconds; the simulated red fault test is removed, so normal red flashes indicate a real detected firmware fault.
- LED indicators are only diagnostics: a green LED does not prove automotive-safe lighting or physical LED data output.
- Firmware source logic and Studio diagnostics descriptions are updated together. Studio version: 0.19.43.
