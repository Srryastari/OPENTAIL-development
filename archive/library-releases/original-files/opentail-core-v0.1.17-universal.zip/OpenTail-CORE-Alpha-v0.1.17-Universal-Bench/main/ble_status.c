/* Read-only, BENCH-ONLY Bluetooth LE peripheral. Does not expose vehicle triggers or road-lighting controls.
 * Wi-Fi Studio remains primary interface; Safari on iPhone does not support Web Bluetooth.
 */
#include "sdkconfig.h"
#include "esp_log.h"
#include "status_led.h"
#if CONFIG_BT_ENABLED && CONFIG_BT_NIMBLE_ENABLED
#include <string.h>
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "host/util/util.h"
#include "os/os_mbuf.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
static const char *TAG="OT_BLE";
static uint8_t addr_type;
/* Private service + read-only characteristic. No unauthenticated show or trigger writes. */
static const ble_uuid128_t ot_service_uuid=BLE_UUID128_INIT(0x21,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_info_uuid=BLE_UUID128_INIT(0x22,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static int gatt_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)conn;(void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    const char *message="OpenTail CORE 0.1.17 | WiFi Studio | BLE status beta | bench only";
    return os_mbuf_append(ctx->om,message,strlen(message))==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static const struct ble_gatt_chr_def characteristics[]={
    {.uuid=&ot_info_uuid.u,.access_cb=gatt_read,.flags=BLE_GATT_CHR_F_READ},
    {0}
};
static const struct ble_gatt_svc_def services[]={
    {.type=BLE_GATT_SVC_TYPE_PRIMARY,.uuid=&ot_service_uuid.u,.characteristics=characteristics},
    {0}
};
static int gap_event(struct ble_gap_event *ev,void *arg);
static void advertise(void){
    struct ble_hs_adv_fields fields={0};
    fields.flags=BLE_HS_ADV_F_DISC_GEN|BLE_HS_ADV_F_BREDR_UNSUP;
    const char *name=ble_svc_gap_device_name();
    fields.name=(uint8_t*)name;fields.name_len=strlen(name);fields.name_is_complete=1;
    int rc=ble_gap_adv_set_fields(&fields);
    if(rc){ESP_LOGE(TAG,"BLE advertising fields failed: %d",rc);return;}
    struct ble_gap_adv_params params={0};
    params.conn_mode=BLE_GAP_CONN_MODE_UND;
    params.disc_mode=BLE_GAP_DISC_MODE_GEN;
    rc=ble_gap_adv_start(addr_type,NULL,BLE_HS_FOREVER,&params,gap_event,NULL);
    if(rc)ESP_LOGE(TAG,"BLE advertising start failed: %d",rc);
}
static int gap_event(struct ble_gap_event *ev,void *arg){
    (void)arg;
    switch(ev->type){
        case BLE_GAP_EVENT_CONNECT:
            if(ev->connect.status==0)ot_st_ble_connected(true);
            else advertise();
            break;
        case BLE_GAP_EVENT_DISCONNECT:
            ot_st_ble_connected(false);advertise();break;
        case BLE_GAP_EVENT_ADV_COMPLETE:advertise();break;
        default:break;
    }
    return 0;
}
static void on_sync(void){
    int rc=ble_hs_util_ensure_addr(0);
    if(!rc)rc=ble_hs_id_infer_auto(0,&addr_type);
    if(rc){ESP_LOGE(TAG,"BLE address error: %d",rc);return;}
    advertise();
}
static void host_task(void *arg){
    (void)arg;nimble_port_run();nimble_port_freertos_deinit();
}
void ot_ble_start(void){
    esp_err_t err=nimble_port_init();
    if(err!=ESP_OK){ESP_LOGE(TAG,"NimBLE init failed: %s",esp_err_to_name(err));return;}
    ble_svc_gap_init();ble_svc_gatt_init();
    int rc=ble_svc_gap_device_name_set("OpenTail CORE");
    if(!rc)rc=ble_gatts_count_cfg(services);
    if(!rc)rc=ble_gatts_add_svcs(services);
    if(rc){ESP_LOGE(TAG,"NimBLE service registration failed: %d",rc);return;}
    ble_hs_cfg.sync_cb=on_sync;
    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG,"BLE read-only status started (not an iOS Safari control transport)");
}
#else
void ot_ble_start(void){ /* Bluetooth not enabled in this build; Wi-Fi behavior unchanged. */ }
#endif
