# OpenTail CORE v0.1.17-alpha — universal bench build

**This is an uncompiled/untested-on-board source release candidate**. Do not flash until `idf.py build` reports success. Backup your existing working v0.1.16 project. Follow `INSTALL-WINDOWS.md` before flashing.

Goal: restore show-mode RGB indication, avoid the fixed-five-zone save error, speed up rendering, expose accurate FPS, preserve user-tested v1 NVS settings, add decorative RGB/white calibration, and add read-only BLE status alongside Wi-Fi.

- **Current physical outputs:** two, GPIO16 and GPIO17, 522 allocated pixels per output. These are *not* 12 outputs yet.
- **Current zones:** 1–8 editable per output; no GS400 geometry required. Optional GS400 preset is not a default.
- **Wi-Fi:** CORE AP and embedded Studio, custom password set at build using the older `sdkconfig` value.
- **Bluetooth:** read-only GATT status preview; Wi-Fi still provides all Studio commands. BLE device and concurrent radio behavior must be hardware tested.
- **Output settings:** migrated from saved v1 `profile`, new settings saved to `profile_v2` without erasing old key.
- **Color correction:** output decorative effects/demos only. Keep road-lighting trigger colors unmodified.
- **Safety:** no automotive failover, only a bench test; direct GPIO 3.3V into WS2815 remains electrically unqualified even though short test succeeded.
