# Windows install — OpenTail CORE v0.1.17 (universal + all feasible bench updates)

**Read first:** Your existing v0.1.16 build WORKS; this is a new source revision and has NOT passed ESP-IDF compilation or physical hardware verification here. Keep your existing v0.1.16 source and do not erase flash. If a build fails, DO NOT flash.

## A. Save the ZIP to Desktop
Save `opentail-core-v0.1.17-universal.zip` on your Windows Desktop. Open **ESP-IDF 5.5.5 PowerShell**, not ordinary PowerShell.

## B. Extract automatically (no manual unzip)
```powershell
$zip = "$env:USERPROFILE\Desktop\opentail-core-v0.1.17-universal.zip"
$base = "$env:USERPROFILE\Desktop\OpenTail"
if (!(Test-Path $zip)) { throw 'ZIP not on Desktop' }
New-Item -ItemType Directory -Path $base -Force | Out-Null
Expand-Archive -LiteralPath $zip -DestinationPath $base -Force
cd "$base\OpenTail-CORE-Alpha-v0.1.17-Universal-Bench"
if (!(Test-Path .\CMakeLists.txt)) { throw 'Wrong project directory' }
```

## C. Preserve your previous custom Wi-Fi password WITHOUT sharing it
Your earlier upgrade reverted the Wi-Fi password to default. This time copy ONLY the previous `CONFIG_OPENTAIL_AP_PASSWORD` line into the NEW project's defaults, so BLE defaults also remain enabled.
```powershell
$old = "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.16-522-Status\sdkconfig"
if (!(Test-Path $old)) { throw 'Old sdkconfig not found: locate the last successfully flashed project first' }
$pw = (Select-String -Path $old -Pattern '^CONFIG_OPENTAIL_AP_PASSWORD=').Line
if (!$pw) { throw 'Previous password config missing; use idf.py menuconfig instead' }
if (!(Select-String -Path .\sdkconfig.defaults -Pattern '^CONFIG_OPENTAIL_AP_PASSWORD=' -Quiet)) { Add-Content -Path .\sdkconfig.defaults -Value $pw }
```
**Do not paste the password in ChatGPT.** If that previous sdkconfig itself contained an unwanted password, replace it through `idf.py menuconfig` instead.

## D. Compile (BEFORE any flash)
```powershell
idf.py --version
idf.py set-target esp32s3
idf.py build
```
Proceed **only** if the output says `Project build complete`. An ESP-IDF error means this candidate is NOT flash-ready; send the first real error, not a fake success.

## E. Flash on COM9 only after successful compilation
Disconnect or switch off the GLEDOPTO's LED power for firmware flashing. Leave the ESP32 connected over USB. Close other monitors.
```powershell
idf.py -p COM9 flash monitor
```
Do not run `erase-flash`, `fullclean` isn't necessary, and do not select any option that erases all flash/NVS. Exit monitor using `Ctrl + ]`.

## F. Verify in order
1. Confirm boot text contains `CORE 0.1.17-alpha is BENCH-ONLY` and there are no error/reset loops.
2. Join Wi-Fi `OpenTail-CORE-Alpha` using your previous password; open `http://192.168.4.1/studio`; verify Studio v0.19.44.
3. Check the onboard status LED: 3 brief white startup strobes, amber when Studio inactive, green during Studio connection. Start a native Show Mode and look for smooth rainbow; stop it and confirm return to normal indicator.
4. Layout → Universal Output Manager → Pixel OUT 1: confirm your corrected color order is intact after NVS migration. **Do not select any preset unless you want it.**
5. For the 118 LED top-section bench test, use ONE zone named `Top` with 118 pixels and role `decorative` (show only), Output 1 active count 118, and then Save → Reload and confirm saved readback. This is a user-chosen test configuration, NOT a forced GS400 layout.
6. Test Solid Red on Output 1 at low brightness. Your existing 12V 4A adapter must not be assumed safe for unrestricted 522-pixel load. Stop if supply trips or wiring heats. Confirm actual count, no resets, proper colors, and report measured FPS.
7. Optional BLE test: find `OpenTail CORE` using a BLE scanner such as nRF Connect. Purple status when connected by BLE only, teal when both BLE link + active Studio session. This is **read-only status**, not BLE Studio control. Safari will still use Wi-Fi.
8. Test zone Add/Delete without saving unintended changes. Check that the valid configuration is saved and survives ESP32 reboot. Verify IN2+IN3+IN4 simultaneous trigger behavior with the properly isolated bench input module.

## Rollback
Your previous `OpenTail-CORE-Alpha-v0.1.16-522-Status` folder is the known user-tested baseline. Reflash that project if the new build causes regressions, **without erasing flash**. This revision stores new zone mappings in `profile_v2`, leaving the older v1 `profile` untouched for rollback. BLE/new features will be unavailable after rollback.

## Safety
Bench-only; no automotive input surge/ESD protection, backup failover, road-legal fallback or validated output-level shifting. Keep your OEM lighting independent.
