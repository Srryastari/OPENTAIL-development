# OpenTail CORE v0.1.17-alpha + Studio v0.19.44 — bench integration candidate

## Added or changed
- Output Manager v2: 1–8 user-managed zones per physical output; Add/Delete buttons and independent zone names, roles, and pixel lengths. This fixes the v0.1.16 HTTP 400 issue where zero-pixel/five-zone requests were inconsistent.
- NVS migration reads existing v1 output settings (including the user-tested color order), saving v2 to a SEPARATE `profile_v2` key and retaining `profile` for rollback. Does not erase NVS.
- Status LED: under-1-second triple white startup strobe; amber standby; saturated green Wi-Fi Studio session; purple BLE status connection; teal both; smooth rainbow for active native Show Mode; rapid red only for actual detected faults.
- Native shows now render every task iteration instead of every fifth 10 ms iteration. `/api/v1/status` reports `measured_fps` for real benchmarking; 60 FPS is NOT guaranteed, especially with 522 pixels per output.
- Per-output `rgb_gain`, `white_gain`, and optional gamma correction for decorative shows and demos ONLY. Brake/parking/turn/reverse trigger colors are deliberately left unchanged. Default calibration is neutral, gamma disabled.
- BLE read-only advertising/GATT status foundation alongside Wi-Fi. **Not yet** full Bluetooth Studio control, and iPhone Safari lacks Web Bluetooth support. BLE service/source is untested on physical hardware.
- Preserves existing two RMT channels GPIO16/17, eight isolated trigger GPIO mappings, native effects, Wi-Fi web Studio, input arbitration, and USB operation.

## Validation
- Host logic test suites and Studio JavaScript syntax checks: run in container (see REGRESSION-RESULTS.txt).
- ESP-IDF 5.5.5 compilation: **NOT RUN HERE** (SDK unavailable). This is a source project, NOT verified binary.
- Wi-Fi/BLE coexistence, output save/readback, hardware FPS, and physical 118/522 LED tests: **NOT YET VERIFIED**. Do not install as road lighting.

## Still outside current bench scope
- 12 physical parallel pixel outputs (current two), ~6,000 pixels, 10 switched 12V outputs, automatic backup-controller takeover, automotive protection/qualification.
- Full BLE commands/native iPhone application, advanced WLED effects and full sequences on CORE firmware.
