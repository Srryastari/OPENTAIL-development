# OpenTail CORE universal section-layout requirements

- **Purpose:** support different vehicles without compiling or hardcoding a specific lamp arrangement.
- **Bench firmware v0.1.16:** two physical data channels GPIO16 and GPIO17, 522 allocated physical pixels per channel, independently saved output name, active pixel count, color order and up to five editable zone slots. Unused slots may have 0 pixels.
- **Default:** no GS400 preset is applied automatically. Existing Output Manager NVS settings survive normal flash if not erased.
- **Optional demonstration:** GS400 left main housing = Top 118, Turn 109, Reverse 42, Bottom 253, absent trunk 0; only if explicitly selected by user.
- **Future universal target (NOT IMPLEMENTED):** 12 configurable pixel data outputs, ~6000 initial aggregate pixels subject to validation, genuinely variable zone counts per output (add/remove/reorder), adjustable trigger rules/overrides, 8 vehicle triggers and 10 switched outputs, fallback and automotive qualification.
- **Important:** `12` physical outputs and unrestricted zone counts must not be represented as supported in this bench firmware. The 522 pixel allocation is not an actual power/current rating.
