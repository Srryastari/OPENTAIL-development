# OpenTail CORE Alpha 0.1.13 / Studio 0.19.40

- Adds live eight-channel vehicle input monitor in CORE Diagnostics (physical, simulated, combined mask).
- Status polling every ~400 ms while Diagnostics is visible; ~1.8 s elsewhere; no overlapping polls.
- Displays physical inputs separately from software simulation, with explicit stale/offline states and last successful read time.
- Firmware GPIO inputs and native show logic UNCHANGED from user-verified 0.1.12; the HTTP UI asset and firmware version string are the only changed files.
- Preserves WLED mode, black/white themes, shows and the existing read-only status LED card.
- Bench only; not evidence of automotive transient protection or lighting failover.
