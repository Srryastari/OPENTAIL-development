# OpenTail CORE Alpha v0.1.12 — native bench effect API

Same host and HTTP API as v0.1.11. Base URL is `http://192.168.4.1` on CORE Wi-Fi. WPA2 AP access is the only request gate; this is **not production authorization**.

### GET /api/v1/capabilities
New keys: `native_show_engine:true`, `native_effects:["solid","chase","breathe","wipe","rainbow"]`. `firmware_sequences:false` remains.

### GET /api/v1/show
JSON keys: `active`, `effect`, `remaining_ms`, `brightness`, `speed`, `r`, `g`, `b`, `chain_mask`, `section_mask`, `bench_only`, `outputs_ready`. `active` means the show timer is running, **not** that input overrides are absent.

### POST /api/v1/show/start
JSON example:
```json
{"effect":"rainbow","r":255,"g":0,"b":0,"speed":50,"brightness":24,"chain":"both","section_mask":31,"ttl_ms":15000}
```

- `effect`: one of `solid`, `chase`, `breathe`, `wipe`, `rainbow` (required).
- `speed`: integer 0–100 (default 50).
- `brightness`: integer 0–32 (default 24); this is 8-bit channel output scale, **not** a current limiter.
- `r`, `g`, `b`: 0–255, used for Solid/Chase/Breathe/Wipe; Rainbow ignores provided color.
- `chain`: `both` (default), `left`, or `right`.
- `section_mask`: bits [Top 1, Turn 2, Reverse 4, Bottom 8, Trunk 16]; default 31, options 1–31.
- `ttl_ms`: integer, clamped 1000–60000 (default 15000).
- Response success: `{ "ok":true, "active":true, "bench_only":true }`. If output init failed, HTTP 409. Invalid request HTTP 400.

This is **volatile**. No NVS settings are altered. After the timeout or reboot, effects stop. Input trigger activity overrides the show across *both* chains. Old temporary demo API preempts native effects. All LED strip `set_pixel/refresh` calls stay in the single 50ms frame task.

### POST /api/v1/show/stop
Empty body `{}`; immediately clears show state. Stops do **not** disable physical triggers.

### POST /api/v1/stop
Existing global stop now also clears native shows (in addition to temporary demos and simulated inputs).

### GET /api/v1/status
Includes `native_show_active` (timer), in addition to existing status fields; the onboard status LED `mode:"show_mode"` is an independent indicator of show *rendering* rather than just being scheduled.

### /api/v1/status-led/self-test and /status-self-test
Still available separately for the 5-second onboard RGB-only rainbow and fault tests.

**No claim of physical output validation, safety failover or road-use suitability.**

### Live input monitor (Studio 0.19.40)
No new firmware API endpoints. Studio polls `GET /api/v1/status` approximately every 400 ms while CORE Diagnostics is foreground-visible. Existing fields `input_mask`, `simulated_mask`, `effective_mask` are decoded as 8-bit masks for GPIO4–GPIO11. Values are read-only; green denotes real isolated 12V input detection, SIM indicates firmware simulation, and offline/stale data is not shown as current.
