# OpenTail Studio v0.10 — Built-in Diagnostics

## Install
1. Back up any important WLED configuration/presets.
2. In WLED `/edit`, upload `opentail.htm`, replacing the prior app.
3. Open `http://4.3.2.1/opentail.htm?v=10` (substitute the controller IP).
4. Connect, open **Connect**, and tap **Capture controller snapshot**.
5. Reproduce a broken app action, then tap **Export diagnostic JSON** and upload the file to ChatGPT.

## Captured
- WLED JSON API requests: paths, methods, command payloads, status, latency and a condensed state response when available.
- JavaScript errors and unhandled promise rejections.
- Read-only `/json` snapshot: WLED version, LED count, output metadata excluding sensitive keys, segment positions, brightness, effect IDs.
- App-side section offsets and lengths for comparison.

No background polling and no external telemetry service. Reports remain local until exported. Network/Wi-Fi credentials are not intentionally included. Review files before sharing.

## Limitations
- This update does not fix broken lighting features in v0.9; it instruments them.
- A successful HTTP response is not proof that the intended LEDs physically changed.
- No physical GLEDOPTO validation performed.
