OpenTail Studio v0.15.1 — UI PROTOTYPE ONLY

Open index.html in a web browser to review the design.
The same interface is also provided as opentail.htm for optional browser viewing from WLED's file manager.

IMPORTANT: This prototype does NOT control WLED hardware and must not replace your working v0.14 controller app.
To test the UI without affecting your working controller app, use index.html locally.

For a fully working controller-connected revision, the UI must be integrated with the v0.14 WLED logic.
