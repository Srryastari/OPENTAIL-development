## v0.1.4 — Black UI theme asset (bench only)
- Embeds OpenTail Studio v0.19.32 with pure black background and neutral charcoal panels.
- Green retained only as an accent for active, connected and primary states.
- All existing navigation, UI behaviors, controller logic and API preserved from v0.1.3.
- Source not compiled or flashed to physical hardware here.

## v0.1.4 — Unified Studio UI asset (source release, bench only)
- Embeds OpenTail Studio v0.19.32 with polished, shared chat-preview-inspired design.
- Same six-tab editor for WLED and CORE connection modes; CORE execution limitations remain explicit.
- Firmware logic, GPIO assignments, API, LED outputs and safety behavior unchanged from v0.1.2.
- Source not compiled or hardware-flashed in this environment.

# OpenTail CORE Alpha Changelog

## v0.1.2 — Restore existing OpenTail Studio workspace in CORE mode (source release)
- Embedded OpenTail Studio v0.19.30; established Dashboard, Show Modes, Triggers, Layout, Connect and Diagnostics visible in CORE mode.
- Universal Effect Editor modal available for local authoring in CORE mode.
- On-screen separation of local project editing from live CORE bench commands.
- WLED-only REST requests blocked in CORE mode; no fake CORE animation support.
- Firmware network and LED control logic unchanged from the user-flashed v0.1.1 except version metadata and embedded Studio asset.
- Requires compilation/flash on physical ESP32-S3; not hardware tested.

# OpenTail CORE Alpha Changelog

## v0.1.1 — Studio bridge (source release)
- Embed OpenTail Studio v0.19.29 as gzip HTML on GET `/studio`, retaining the previous minimal homepage on `/`.
- Add Studio CORE API adapter; same-origin capability discovery, status, temporary demos/input tests, stop, automatic refresh.
- Use DMA for first LED channel, standard RMT for second, reflecting the successful v0.1.0 user hardware fix.
- Preserve previous 8-input / 2-output / bench-only firmware API and all existing safety limitations.
- NOT yet ESP-IDF compiled or hardware flashed/tested; source/static/host tests only.

## v0.1.0 — Initial source release
- Two WS2815 LED outputs; simulated/physical vehicle inputs; temporary demo HTTP API and stand-alone AP test page.
- First Windows ESP-IDF build and real ESP32-S3 boot confirmed by user; the initial DMA allocation caused a reboot loop until adjusted.
