# OpenTail CORE Alpha v0.1.14 · Trigger Priority and Arbitration

- Extracted shared, portable `arbitration_logic.[ch]` model so external pixel renderer and status reporting follow the same priority rules.
- Vehicle signals preempt temporary demos and native shows; brake beats parking on tail zones; both turns coexist on separate sections; reverse overlays via its own section.
- Reserved IN6–IN8 are detectable inputs without automatically overriding lighting effects.
- `/api/v1/status` exposes the current selected source and six section decisions; `/api/v1/capabilities` announces support.
- Embedded OpenTail Studio v0.19.41 Diagnostics adds responsive, read-only Trigger arbitration card, updated on existing live polling and cleared on stale/offline.
- Added portable host assertions for priority, coexistence, simulated input masks, effects and section targeting.
- No new GPIO wiring required. No new persistent configuration. No safety fallback or road-lighting certification.
- Firmware ESP-IDF build and real board visual verification remain to be completed by user.
