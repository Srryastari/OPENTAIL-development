# OpenTail CORE Alpha v0.1.14 (bench only)

Working from v0.1.13 with Studio v0.19.41 embedded. **Do not connect this prototype as the only functional road-lighting system.** There is no independent hardware lighting fallback, backup-controller selector, automotive transient protection, or validated 12V LED output. The current physical outputs are two 30-pixel channels on GPIO16/GPIO17, awaiting level-shifter bench validation. GPIO4–11 are 8 active-low 3.3V-safe inputs via the tested optocoupler.

## Flash (ESP-IDF 5.5.x on Windows)

Extract ZIP into `%USERPROFILE%\Desktop\OpenTail` (creates `OpenTail-CORE-Alpha-v0.1.14`). In **ESP-IDF PowerShell**:

```powershell
cd "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.14"
Copy-Item "..\OpenTail-CORE-Alpha-v0.1.13\sdkconfig" ".\sdkconfig" -Force
idf.py build
if ($LASTEXITCODE -eq 0) { idf.py -p COM9 flash }
```

Only flash if `Project build complete` appears; close all serial monitors to free COM9. Firmware source ZIP has normalized file timestamps to mitigate prior Windows CMake repeat-generation issue.

## Try the arbitration bench test

Connect to `OpenTail-CORE-Alpha` Wi-Fi and open `http://192.168.4.1/studio` → **Diagnostics**. Use the 12V-isolated optocoupler connections you've already verified. IN1+IN2 yields input_mask=3: both tails should report Brake (rather than Parking); IN3+IN4 yields mask=12: Hazards Yes and both turns selected. Start a 30-second native Rainbow Show, then apply IN2: show should read Overridden, tail behavior Brake; remove IN2 while the timer is still active: show should return to Rendering. This is **diagnostics-model validation**, not proof of actual external pixel illumination.

No `sdkconfig` is included in the source archive, preserving your existing Wi-Fi credentials when you copy the previous config.
