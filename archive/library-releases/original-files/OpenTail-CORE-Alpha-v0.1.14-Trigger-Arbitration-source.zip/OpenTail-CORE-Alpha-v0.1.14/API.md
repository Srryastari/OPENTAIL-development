# OpenTail CORE Alpha v0.1.14 · Bench trigger arbitration

All endpoints and request payloads from v0.1.13 are preserved. **No automotive safety guarantee.**

## GET /api/v1/status

New read-only `arbitration` object, calculated from the **effective mask** (physical OR simulated), temporary demo timer and native Show Mode timer. Schema example for physically active IN3 + IN4 (input_mask=12):

```json
"arbitration": {
  "mode":"vehicle", "hazards":true, "brake_over_parking":false,
  "show_requested":false, "show_suppressed":false, "show_rendering":false,
  "demo_requested":false, "demo_suppressed":false,
  "left":{"tail":"off","turn":"left_turn","reverse":"off"},
  "right":{"tail":"off","turn":"right_turn","reverse":"off"}
}
```

- `mode`: `idle`, `vehicle`, `demo`, or `native_show`.
- Arbitration priority: recognized vehicle signals (IN1–IN5) > temporary color demo > native show > idle.
- Brake outranks parking **only** for top/bottom/trunk tail zones. Turn signals select each side's turn section; reverse selects both reverse zones simultaneously. Multiple vehicle functions coexist in their different sections.
- Both left+right inputs select `hazards:true`; firmware **does not synthesize turn blinking**. Its 30-pixel bench section follows each input level.
- Reserved auxiliary input bits 6–8 still appear in the effective mask, but do not suppress effects or select a lighting behavior.
- `show_requested` means show timer active; `show_rendering` means the native show currently wins arbitration. The onboard status LED's rainbow follows the rendered show.
- `left`/`right` here describe the current **two-chain 30-pixel bench example**, not a locked universal output mapping. `tail` covers the top/bottom/trunk sections which share the same priority in this firmware.
- Read-only; arbitration commands, programmable zone routing, synchronized turn animations, and fail-safe hardware are **not** implemented.

## GET /api/v1/capabilities

`trigger_arbitration_v1:true` indicates the nested arbitration object is available.

## Studio v0.19.41

A read-only Trigger arbitration card follows the Live Vehicle Inputs card in Diagnostics. It updates during existing 400ms polling, shows the selected source, hazards, whether native shows are overridden, and tail/turn/reverse decisions for the two bench output chains. Shows offline/stale and older firmware gracefully without stale values.
