OpenTail Studio v0.14
Upload opentail.htm to WLED via /edit, then open http://CONTROLLER-IP/opentail.htm?v=14
Changes: Dashboard, Show Modes, Builder trigger editor, standalone Diagnostics, Connect cleanup, dark/green UI, selected/running WLED effect states.
Bench use only; not an automotive safety controller. Test on physical hardware; no physical verification performed.
