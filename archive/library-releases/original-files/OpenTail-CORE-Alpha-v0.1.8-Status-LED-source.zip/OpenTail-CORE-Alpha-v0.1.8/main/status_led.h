#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "status_logic.h"
typedef struct {
    bool available,enabled,wifi_ready,show_active,ever_connected;
    uint8_t brightness;
    ot_st_mode_t mode;
} ot_st_snapshot_t;
void ot_st_init(void);
void ot_st_wifi_ready(void);
void ot_st_set_fault(const char *reason);
void ot_st_show_active(bool on); // reserved until native Show Modes exist
void ot_st_session(bool active); // Studio heartbeat or explicit disconnect
void ot_st_snapshot(ot_st_snapshot_t *out);
bool ot_st_configure(bool change_enabled,bool enabled,bool change_brightness,uint8_t brightness);
void ot_st_format_json(char *buf,size_t size);
