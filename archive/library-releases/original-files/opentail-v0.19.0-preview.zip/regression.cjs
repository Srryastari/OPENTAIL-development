const assert=require('node:assert/strict');
function deviceSegments(d){return (d.seg||[]).map((s,i)=>({...s,id:s.id??i})).filter(s=>Number(s.stop)>Number(s.start))}
function otBaselineSpecs(before){return deviceSegments(before).map(s=>({id:s.id,on:s.on!==false,bri:s.bri,fx:s.fx,sx:s.sx,ix:s.ix,pal:s.pal,col:s.col,rev:s.rev===true,frz:s.frz??false}));}
function otColorMatches(a,b){
 if(!Array.isArray(a)||!Array.isArray(b))return true; // Older WLED versions may omit colors on readback.
 return b.every((color,i)=>!Array.isArray(color)||!Array.isArray(a[i])||color.slice(0,3).every((v,j)=>Math.abs(Number(v)-Number(a[i][j]))<=1));
}
function otBaselineMismatch(expected,actual){
 return expected.filter(x=>{const s=actual.find(v=>Number(v.id)===Number(x.id));if(!s)return true;
  if(Boolean(s.on)!==Boolean(x.on)||Boolean(s.rev)!==Boolean(x.rev))return true;
  for(const k of ['fx','bri','sx','ix','pal'])if(x[k]!==undefined&&s[k]!==undefined&&Math.abs(Number(s[k])-Number(x[k]))>1)return true;
  return !otColorMatches(s.col,x.col);
 });
}

const expected=otBaselineSpecs({seg:[{id:0,start:0,stop:118,on:true,fx:0,bri:120,sx:100,ix:80,pal:0,rev:false,col:[[255,0,0],[0,0,0]]}]});
assert.equal(otBaselineMismatch(expected,deviceSegments({seg:[{id:0,start:0,stop:118,on:true,fx:0,bri:120,sx:100,ix:80,pal:0,rev:false,col:[[255,0,0,0],[0,0,0,0]]}]})).length,0,'RGBW readback compatible');
assert.equal(otBaselineMismatch(expected,deviceSegments({seg:[{id:0,start:0,stop:118,on:false,fx:0,bri:120,rev:false}]})).length,1,'wrong power rejected');
assert.equal(otBaselineMismatch(expected,deviceSegments({seg:[{id:0,start:0,stop:118,on:true,fx:3,bri:120,rev:false}]})).length,1,'wrong effect rejected');
assert.equal(otBaselineMismatch(expected,[]).length,1,'missing segment rejected');
assert.equal(otBaselineMismatch(expected,deviceSegments({seg:[{id:0,start:0,stop:118,on:true,fx:0,bri:121,sx:100,ix:80,pal:0,rev:false,col:[[255,0,0],[0,0,0]]}]})).length,0,'one-step quantization tolerated');
console.log('5 baseline restoration regression assertions passed');
