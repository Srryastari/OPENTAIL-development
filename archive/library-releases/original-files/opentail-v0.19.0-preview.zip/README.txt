OpenTail Studio v0.19.0 PREVIEW — not hardware verified.
Fixes WLED baseline RGB/RGBW comparison and tolerates one-step readback quantization; clearer recovery warnings. Does not yet validate end-to-end Test/Stop cycles on hardware or simulate the full application. Keep old build backed up. Run node regression.cjs.
