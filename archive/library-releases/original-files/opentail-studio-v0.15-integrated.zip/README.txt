OpenTail Studio v0.15 integrated
Upload ONLY opentail.htm via http://4.3.2.1/edit; keep a backup of the old version. Open http://4.3.2.1/opentail.htm?v=150
This is a bench/show editor, NOT an automotive safety controller.
New preview is simulated, not physical per-pixel readback. Sequence playback and per-section trigger effects are not yet implemented. Hardware profile selection does not write WLED LED Preferences.
