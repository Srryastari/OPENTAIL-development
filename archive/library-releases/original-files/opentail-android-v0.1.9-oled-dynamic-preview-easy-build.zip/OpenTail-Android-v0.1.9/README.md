# OpenTail Android v0.1.9

Approved OLED-black UI implementation and dynamic CORE zone preview. Extract All, run BUILD-APK.bat. Existing CORE firmware v0.1.20 unchanged.

See CHANGELOG.md and QA-RESULTS.txt.

Bench-only: Android APK has not been compiled or hardware-tested in this environment.

## Matching CORE Studio

When connected to CORE Wi-Fi the Android app loads Studio from the ESP32. To obtain dynamic saved-zone preview on that screen, install matching CORE v0.1.21 (source package separately supplied). Without that update, Android v0.1.9 styling works but the older CORE-served Studio still uses older preview data.
