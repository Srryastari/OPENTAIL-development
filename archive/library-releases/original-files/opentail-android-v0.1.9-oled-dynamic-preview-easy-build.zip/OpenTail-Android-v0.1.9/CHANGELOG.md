# OpenTail Android v0.1.9 / Studio v0.19.50

- Approved OLED-black Shows visual design: streamlined header, outlined pill selectors, thin tracks with white pill thumbs, white Start and outlined Stop.
- Existing BLE authorization, effect protocol, reconnection, haptics and Wi-Fi Studio path retained.
- Shows connection mode remains available from Settings; original Wi-Fi Show Mode controls retained.
- CORE Live Lighting Preview's original render/animation and Live/Synced/Simulated controls preserved. In CORE mode read-only preview sections now derive from the *confirmed saved* Output Manager configuration, across both pixel outputs. Zero-length zones are hidden; names and counts are displayed. No arbitrary default vehicle sections.
- No firmware changes. Device pixel telemetry is not invented; simulated pixel colors are explicitly labeled.
- This source was not compiled into an Android APK in this environment; use BUILD-APK.bat on Windows. No hardware tests claimed.
