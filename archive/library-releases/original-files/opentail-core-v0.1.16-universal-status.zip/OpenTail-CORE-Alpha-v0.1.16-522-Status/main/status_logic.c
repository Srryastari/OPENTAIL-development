#include "status_logic.h"

const char *ot_st_mode_name(ot_st_mode_t mode) {
    switch(mode) {
        case OT_ST_STARTUP:return "startup";
        case OT_ST_WIFI:return "wifi_ready";
        case OT_ST_CONNECTED:return "connected";
        case OT_ST_DISCONNECTED:return "disconnected";
        case OT_ST_SHOW:return "show_mode";
        case OT_ST_FAULT:return "fault";
        default:return "off";
    }
}
static ot_st_rgb_t rgb(uint8_t r,uint8_t g,uint8_t b,uint8_t pct){
    return (ot_st_rgb_t){(uint8_t)(r*pct/100u),(uint8_t)(g*pct/100u),(uint8_t)(b*pct/100u)};
}
static uint8_t portion(uint32_t phase,uint32_t peak,uint32_t end){
    if(phase>=end)return 0;
    if(phase<=peak)return (uint8_t)(phase*100u/(peak?peak:1u));
    return (uint8_t)((end-phase)*100u/(end-peak));
}
ot_st_rgb_t ot_st_render(ot_st_mode_t mode,uint32_t t,uint8_t brightness,bool enabled){
    if(brightness>100)brightness=100;
    /* Fault remains visible even if users disabled ordinary status LEDs. */
    if(!enabled && mode!=OT_ST_FAULT)return (ot_st_rgb_t){0,0,0};
    switch(mode){
        case OT_ST_STARTUP: return t<300u?rgb(255,255,255,brightness):rgb(0,0,0,0);
        case OT_ST_WIFI: { // saturated pure-blue pulse, exactly once per 1000 ms
            uint8_t wave=portion(t%1000u,150u,400u);
            return rgb(0,0,255,(uint8_t)(brightness*wave/100u));
        }
        case OT_ST_CONNECTED: case OT_ST_DISCONNECTED: {
            uint32_t phase=t%2200u;
            uint8_t on=(phase<120u || (phase>=240u && phase<360u))?brightness:0;
            return mode==OT_ST_CONNECTED?rgb(0,255,0,on):rgb(0,0,255,on);
        }
        case OT_ST_SHOW: { // linear six-stop fully saturated wheel, full cycle every 1400ms
            static const uint8_t wheel[7][3]={{255,0,0},{255,255,0},{0,255,0},{0,255,255},{0,0,255},{255,0,255},{255,0,0}};
            uint32_t phase=t%1400u;
            uint32_t scaled=phase*6u;
            uint32_t idx=scaled/1400u, frac=scaled%1400u;
            uint8_t c[3];
            for(unsigned i=0;i<3;i++) c[i]=(uint8_t)((wheel[idx][i]*(1400u-frac)+wheel[idx+1][i]*frac)/1400u);
            return rgb(c[0],c[1],c[2],brightness);
        }
        case OT_ST_FAULT: // continuous 90ms ON, 90ms OFF, without long rests
            return (t%180u)<90u?rgb(255,0,0,brightness<30u?30u:brightness):rgb(0,0,0,0);
        default:return (ot_st_rgb_t){0,0,0};
    }
}

bool ot_st_test_window_active(ot_st_mode_t mode,uint32_t now_ms,uint32_t deadline_ms){
    uint32_t remain=deadline_ms-now_ms;
    return (mode==OT_ST_SHOW || mode==OT_ST_FAULT) && remain!=0u && remain<0x80000000u;
}
