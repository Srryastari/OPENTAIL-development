/* OpenTail CORE Alpha 0.1.16 — 522-pixel + status semantics, NOT vehicle lighting firmware.
 * ESP-IDF 5.5.x, ESP32-S3, 2x WS2815-compatible 800kHz RMT outputs.
 * No watchdog, fail-safe, independent backup or OEM-bulb fallback. Do not drive on road.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "cJSON.h"
#include "led_strip.h"
#include "led_strip_rmt.h"
#include "board_config.h"
#include "status_led.h"
#include "show_logic.h"
#include "arbitration_logic.h"
#include "output_manager.h"
#include "nvs.h"
#include "esp_timer.h"

#define OT_FW "0.1.16-alpha"
#define OT_AP_SSID "OpenTail-CORE-Alpha"
static const char *TAG="OPENTAIL";
static const gpio_num_t input_pin[OT_IN_COUNT]=OT_INPUT_GPIO_LIST;
static const gpio_num_t out_pin[OT_CHAIN_COUNT]={OT_OUT_LEFT_GPIO,OT_OUT_RIGHT_GPIO};
static led_strip_handle_t strip[OT_CHAIN_COUNT]={0};
static const ot_layout_t layout={OT_LAYOUT_SECTIONS,OT_CHAIN_PIXELS,OT_MAX_BRIGHTNESS};
static ot_inputs_t inputs={0};

static portMUX_TYPE state_lock=portMUX_INITIALIZER_UNLOCKED;
static uint8_t live_input_mask=0;
static uint8_t sim_mask=0;
static TickType_t sim_deadline=0;
static ot_demo_t demo={OT_DEMO_OFF,{0,0,0},0};
static TickType_t demo_deadline=0;
static uint32_t frame_index=0;
/* Single render-task owner of physical outputs; HTTP handlers only modify copied state. */
static ot_show_t native_show={0};
static TickType_t native_show_deadline=0;
static uint32_t native_show_started_ms=0;
static bool native_outputs_ready=false;
static ot_om_output_t om_outputs[OT_OM_OUTPUTS];
static bool om_persistent=false;
#define OT_OM_STORAGE_MAGIC 0x4f543135u
typedef struct {
    uint32_t magic;
    uint32_t version;
    ot_om_output_t outputs[OT_OM_OUTPUTS];
} ot_om_store_t;
static void om_load(void){
    ot_om_defaults(om_outputs);
    nvs_handle_t h;
    if(nvs_open("ot_output_cfg",NVS_READONLY,&h)!=ESP_OK){om_persistent=false;return;}
    ot_om_store_t stored={0};size_t n=sizeof(stored);
    esp_err_t e=nvs_get_blob(h,"profile",&stored,&n);nvs_close(h);
    if(e==ESP_ERR_NVS_NOT_FOUND){om_persistent=false;return;}
    if(e==ESP_OK && n==sizeof(stored)&&stored.magic==OT_OM_STORAGE_MAGIC&&stored.version==OT_OM_VERSION&&
       ot_om_valid(&stored.outputs[0])&&ot_om_valid(&stored.outputs[1])){
        memcpy(om_outputs,stored.outputs,sizeof(om_outputs));om_persistent=true;
    }else{ESP_LOGW(TAG,"Output configuration unavailable or invalid; using safe bench defaults");om_persistent=false;}
}
static bool om_save(const ot_om_output_t items[OT_OM_OUTPUTS]){
    ot_om_store_t stored={.magic=OT_OM_STORAGE_MAGIC,.version=OT_OM_VERSION};
    memcpy(stored.outputs,items,sizeof(stored.outputs));
    nvs_handle_t h;
    if(nvs_open("ot_output_cfg",NVS_READWRITE,&h)!=ESP_OK)return false;
    esp_err_t e=nvs_set_blob(h,"profile",&stored,sizeof(stored));
    if(e==ESP_OK)e=nvs_commit(h);
    nvs_close(h);
    return e==ESP_OK;
}

#define OT_SHOW_MAX_MS 60000u


static bool before_deadline(TickType_t now,TickType_t deadline) {
    return (int32_t)(deadline-now)>0;
}
static unsigned bounded_int(const cJSON *o,const char *key,int def,int low,int high) {
    cJSON *value=cJSON_GetObjectItemCaseSensitive((cJSON *)o,key);
    if(!cJSON_IsNumber(value)) return (unsigned)def;
    int n=value->valueint;
    return (unsigned)(n<low?low:n>high?high:n);
}
static int recv_json(httpd_req_t *req,cJSON **result) {
    if(req->content_len<2 || req->content_len>2048) return 400;
    char *buf=malloc((size_t)req->content_len+1u);
    if(!buf)return 400;
    int len=0;
    while(len<req->content_len) {
        int n=httpd_req_recv(req,buf+len,req->content_len-len);
        if(n<=0){free(buf);return 408;}
        len+=n;
    }
    buf[len]=0;
    *result=cJSON_ParseWithLength(buf,(size_t)len);
    free(buf);
    return cJSON_IsObject(*result)?200:400;
}
static esp_err_t send_json(httpd_req_t *r,const char *body) {
    httpd_resp_set_type(r,"application/json; charset=utf-8");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_sendstr(r,body);
}
static esp_err_t respond_err(httpd_req_t *r,int status,const char *reason) {
    httpd_resp_set_status(r,status==500?"500 Internal Server Error":status==409?"409 Conflict":status==408?"408 Request Timeout":"400 Bad Request");
    char buf[120];snprintf(buf,sizeof(buf),"{\"error\":\"%s\"}",reason);
    return send_json(r,buf);
}
static uint8_t signal_mask_of(const char *name) {
    if(!strcmp(name,"park")) return OT_SIG_PARK;
    if(!strcmp(name,"brake")) return OT_SIG_BRAKE;
    if(!strcmp(name,"left")) return OT_SIG_LEFT;
    if(!strcmp(name,"right")) return OT_SIG_RIGHT;
    if(!strcmp(name,"reverse")) return OT_SIG_REVERSE;
    return 0;
}
static bool show_window(TickType_t now){
    return native_show.mode!=OT_SHOW_OFF && before_deadline(now,native_show_deadline);
}
static bool om_number(const cJSON *obj,const char *key,unsigned *dest,unsigned low,unsigned high){
    const cJSON *v=cJSON_GetObjectItemCaseSensitive((cJSON *)obj,key);
    if(!cJSON_IsNumber(v)||v->valuedouble!=v->valueint||v->valueint<(int)low||v->valueint>(int)high)return false;
    *dest=(unsigned)v->valueint;return true;
}
static bool om_string(const cJSON *obj,const char *key,char dst[OT_OM_NAME_LEN]){
    const cJSON *v=cJSON_GetObjectItemCaseSensitive((cJSON *)obj,key);
    if(!cJSON_IsString(v)||!v->valuestring)return false;
    size_t n=strlen(v->valuestring);
    if(n<1||n>=OT_OM_NAME_LEN)return false;
    memcpy(dst,v->valuestring,n+1);
    return true;
}
static cJSON *om_json_output(const ot_om_output_t *o,int id,uint8_t mask){
    cJSON *item=cJSON_CreateObject();if(!item)return NULL;
    cJSON_AddNumberToObject(item,"index",id);
    cJSON_AddNumberToObject(item,"pin",(int)out_pin[id]);
    cJSON_AddStringToObject(item,"name",o->name);
    cJSON_AddNumberToObject(item,"pixels",o->active_pixels);
    cJSON_AddStringToObject(item,"color_order",ot_om_order_name(o->color_order));
    cJSON *zones=cJSON_AddArrayToObject(item,"zones");
    for(int i=0;i<OT_OM_ZONES;i++){
        const ot_om_zone_t *z=&o->zones[i];
        cJSON *entry=cJSON_CreateObject();
        cJSON_AddStringToObject(entry,"name",z->name);
        cJSON_AddNumberToObject(entry,"pixels",z->pixels);
        cJSON_AddStringToObject(entry,"role",ot_om_role_name(z->role));
        ot_rgb_t color=ot_om_trigger_color(z->role,mask,OT_MAX_BRIGHTNESS);
        cJSON_AddBoolToObject(entry,"trigger_active",(color.r|color.g|color.b)!=0);
        cJSON_AddItemToArray(zones,entry);
    }
    return item;
}
static esp_err_t om_get(httpd_req_t *r){
    ot_om_output_t copy[OT_OM_OUTPUTS];bool persistent;uint8_t mask;TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    memcpy(copy,om_outputs,sizeof(copy));persistent=om_persistent;
    mask=live_input_mask|(before_deadline(now,sim_deadline)?sim_mask:0);
    portEXIT_CRITICAL(&state_lock);
    cJSON *obj=cJSON_CreateObject();
    if(!obj)return respond_err(r,500,"out of memory");
    cJSON_AddNumberToObject(obj,"revision",OT_OM_VERSION);
    cJSON_AddBoolToObject(obj,"saved_on_device",persistent);
    cJSON_AddBoolToObject(obj,"bench_only",true);
    cJSON_AddNumberToObject(obj,"physical_outputs",2);
    cJSON_AddNumberToObject(obj,"future_outputs_target",12);
    cJSON_AddNumberToObject(obj,"allocated_pixels_per_output",OT_CHAIN_PIXELS);
    cJSON_AddNumberToObject(obj,"max_zones_per_output",OT_OM_ZONES);
    cJSON_AddNumberToObject(obj,"effective_mask",mask);
    cJSON *outputs=cJSON_AddArrayToObject(obj,"outputs");
    for(int i=0;i<OT_OM_OUTPUTS;i++)cJSON_AddItemToArray(outputs,om_json_output(&copy[i],i,mask));
    char *payload=cJSON_PrintUnformatted(obj);
    cJSON_Delete(obj);
    if(!payload)return respond_err(r,500,"out of memory");
    esp_err_t result=send_json(r,payload);free(payload);return result;
}
static esp_err_t om_post(httpd_req_t *r){
    cJSON *obj=NULL;int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    unsigned index=0,pixels=0;
    const cJSON *v=cJSON_GetObjectItemCaseSensitive(obj,"color_order");
    const char *order=cJSON_IsString(v)?v->valuestring:NULL;
    int order_id=ot_om_order_from_name(order);
    cJSON *zones=cJSON_GetObjectItemCaseSensitive(obj,"zones");
    ot_om_output_t next={0};
    bool valid=om_number(obj,"index",&index,0,OT_OM_OUTPUTS-1)&&
      om_number(obj,"pixels",&pixels,OT_OM_ZONES,OT_CHAIN_PIXELS)&&
      om_string(obj,"name",next.name)&&order_id>=0&&cJSON_IsArray(zones)&&
      cJSON_GetArraySize(zones)==OT_OM_ZONES;
    if(valid){
        next.active_pixels=(uint16_t)pixels;next.color_order=(uint8_t)order_id;
        for(int i=0;i<OT_OM_ZONES;i++){
            const cJSON *item=cJSON_GetArrayItem(zones,i);
            unsigned n=0;v=cJSON_GetObjectItemCaseSensitive((cJSON*)item,"role");
            int role=ot_om_role_from_name(cJSON_IsString(v)?v->valuestring:NULL);
            if(!cJSON_IsObject(item)||!om_string(item,"name",next.zones[i].name)||
                !om_number(item,"pixels",&n,0,OT_CHAIN_PIXELS)||role<0){valid=false;break;}
            next.zones[i].pixels=(uint16_t)n;next.zones[i].role=(uint8_t)role;
        }
    }
    if(valid)valid=ot_om_valid(&next);
    cJSON_Delete(obj);
    if(!valid)return respond_err(r,400,"invalid output configuration; five zone lengths must sum to active count (5..522); zero-length zones allowed");
    TickType_t now=xTaskGetTickCount();
    ot_om_output_t next_all[OT_OM_OUTPUTS];
    portENTER_CRITICAL(&state_lock);
    bool busy=live_input_mask || (before_deadline(now,sim_deadline)&&sim_mask) ||
        (before_deadline(now,demo_deadline)&&demo.mode!=OT_DEMO_OFF) || show_window(now);
    memcpy(next_all,om_outputs,sizeof(next_all));
    portEXIT_CRITICAL(&state_lock);
    if(busy)return respond_err(r,409,"stop shows and release all 12V triggers before saving output mapping");
    next_all[index]=next;
    /* No in-memory mutation if NVS commit fails. */
    if(!om_save(next_all))return respond_err(r,500,"failed to save output mapping in flash");
    portENTER_CRITICAL(&state_lock);
    memcpy(om_outputs,next_all,sizeof(om_outputs));om_persistent=true;
    portEXIT_CRITICAL(&state_lock);
    return om_get(r);
}
static esp_err_t show_get(httpd_req_t *r){
    TickType_t now=xTaskGetTickCount();
    ot_show_t cfg;bool active;uint32_t remaining;bool ready;
    portENTER_CRITICAL(&state_lock);
    cfg=native_show;active=show_window(now);
    remaining=active?(uint32_t)((uint32_t)(native_show_deadline-now)*portTICK_PERIOD_MS):0;
    ready=native_outputs_ready;
    portEXIT_CRITICAL(&state_lock);
    char buf[390];
    snprintf(buf,sizeof(buf),"{\"active\":%s,\"effect\":\"%s\",\"remaining_ms\":%lu,\"brightness\":%u,\"speed\":%u,\"r\":%u,\"g\":%u,\"b\":%u,\"chain_mask\":%u,\"section_mask\":%u,\"bench_only\":true,\"outputs_ready\":%s}",
      active?"true":"false",active?ot_show_name(cfg.mode):"off",(unsigned long)remaining,
      cfg.brightness,cfg.speed,cfg.color.r,cfg.color.g,cfg.color.b,cfg.chain_mask,cfg.section_mask,ready?"true":"false");
    return send_json(r,buf);
}
static esp_err_t show_start(httpd_req_t *r){
    cJSON *obj=NULL;int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    cJSON *field=cJSON_GetObjectItemCaseSensitive(obj,"effect");
    const char *effect=cJSON_IsString(field)?field->valuestring:"";
    ot_show_mode_t mode=OT_SHOW_OFF;
    for(int i=OT_SHOW_SOLID;i<=OT_SHOW_RAINBOW;++i){
        if(!strcmp(effect,ot_show_name((ot_show_mode_t)i))){mode=(ot_show_mode_t)i;break;}
    }
    if(mode==OT_SHOW_OFF){cJSON_Delete(obj);return respond_err(r,400,"unknown native effect");}
    ot_show_t cfg={.mode=mode,.color={255,0,0},.brightness=24,.speed=50,
       .chain_mask=3,.section_mask=31};
    const char *channels="both";
    field=cJSON_GetObjectItemCaseSensitive(obj,"chain");
    if(field){if(!cJSON_IsString(field)){cJSON_Delete(obj);return respond_err(r,400,"chain must be a string");}channels=field->valuestring;}
    if(!strcmp(channels,"left"))cfg.chain_mask=1;
    else if(!strcmp(channels,"right"))cfg.chain_mask=2;
    else if(strcmp(channels,"both")){cJSON_Delete(obj);return respond_err(r,400,"chain must be left, right or both");}
    field=cJSON_GetObjectItemCaseSensitive(obj,"section_mask");
    if(field){if(!cJSON_IsNumber(field) || field->valuedouble!=field->valueint || field->valueint<1||field->valueint>31){cJSON_Delete(obj);return respond_err(r,400,"section_mask must be 1..31");}cfg.section_mask=(uint8_t)field->valueint;}
    const char *keys[]={"r","g","b","brightness","speed","ttl_ms"};
    for(int i=0;i<6;++i){field=cJSON_GetObjectItemCaseSensitive(obj,keys[i]);
      if(field && (!cJSON_IsNumber(field) || field->valuedouble!=field->valueint)){
          cJSON_Delete(obj);return respond_err(r,400,"integer parameters required");}
    }
    unsigned ttl=bounded_int(obj,"ttl_ms",15000,1000,OT_SHOW_MAX_MS);
    cfg.color=(ot_rgb_t){bounded_int(obj,"r",255,0,255),bounded_int(obj,"g",0,0,255),bounded_int(obj,"b",0,0,255)};
    cfg.brightness=bounded_int(obj,"brightness",24,0,OT_MAX_BRIGHTNESS);
    cfg.speed=bounded_int(obj,"speed",50,0,100);
    if(!ot_show_valid(&cfg,&layout)){cJSON_Delete(obj);return respond_err(r,400,"invalid show settings");}
    cJSON_Delete(obj);
    TickType_t now=xTaskGetTickCount();
    uint32_t start_ms=(uint32_t)(esp_timer_get_time()/1000LL);
    portENTER_CRITICAL(&state_lock);
    bool ready=native_outputs_ready;
    if(ready){native_show=cfg;native_show_deadline=now+pdMS_TO_TICKS(ttl);
      native_show_started_ms=start_ms;}
    portEXIT_CRITICAL(&state_lock);
    if(!ready)return respond_err(r,409,"pixel outputs not initialized");
    return send_json(r,"{\"ok\":true,\"active\":true,\"bench_only\":true,\"message\":\"native effect started on configured bench outputs; real trigger inputs always override\"}");
}
static esp_err_t show_stop(httpd_req_t *r){
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    native_show.mode=OT_SHOW_OFF;native_show_deadline=now;
    portEXIT_CRITICAL(&state_lock);
    ot_st_show_active(false);
    return send_json(r,"{\"ok\":true,\"active\":false}");
}
static esp_err_t status_get(httpd_req_t *r) {
    TickType_t now=xTaskGetTickCount();
    uint8_t physical,sim;bool sim_active,demo_active,show_active;ot_demo_mode_t mode;uint32_t frames;ot_show_t show_cfg;
    portENTER_CRITICAL(&state_lock);
    physical=live_input_mask;
    sim_active=before_deadline(now,sim_deadline);
    sim=sim_active?sim_mask:0;
    demo_active=before_deadline(now,demo_deadline);
    mode=demo_active?demo.mode:OT_DEMO_OFF;
    frames=frame_index;
    show_active=show_window(now);
    show_cfg=native_show;
    portEXIT_CRITICAL(&state_lock);
    const uint8_t effective=(uint8_t)(physical|sim);
    const ot_arbitration_t arb=ot_arbitrate(effective,mode!=OT_DEMO_OFF,show_active);
    char arb_json[600];
    snprintf(arb_json,sizeof(arb_json),
      "{\"mode\":\"%s\",\"mapping\":\"legacy_example\",\"hazards\":%s,\"brake_over_parking\":%s,\"show_requested\":%s,\"show_suppressed\":%s,\"show_rendering\":%s,\"demo_requested\":%s,\"demo_suppressed\":%s,"
      "\"left\":{\"tail\":\"%s\",\"turn\":\"%s\",\"reverse\":\"%s\"},"
      "\"right\":{\"tail\":\"%s\",\"turn\":\"%s\",\"reverse\":\"%s\"}}",
      ot_arb_mode_name(arb.mode),arb.hazards?"true":"false",arb.brake_over_parking?"true":"false",
      arb.show_requested?"true":"false",arb.show_suppressed?"true":"false",arb.mode==OT_ARB_SHOW?"true":"false",
      arb.demo_requested?"true":"false",arb.demo_suppressed?"true":"false",
      ot_zone_mode_name(ot_arb_zone(&arb,0,OT_TOP,show_cfg.chain_mask,show_cfg.section_mask)),
      ot_zone_mode_name(ot_arb_zone(&arb,0,OT_TURN,show_cfg.chain_mask,show_cfg.section_mask)),
      ot_zone_mode_name(ot_arb_zone(&arb,0,OT_REVERSE,show_cfg.chain_mask,show_cfg.section_mask)),
      ot_zone_mode_name(ot_arb_zone(&arb,1,OT_TOP,show_cfg.chain_mask,show_cfg.section_mask)),
      ot_zone_mode_name(ot_arb_zone(&arb,1,OT_TURN,show_cfg.chain_mask,show_cfg.section_mask)),
      ot_zone_mode_name(ot_arb_zone(&arb,1,OT_REVERSE,show_cfg.chain_mask,show_cfg.section_mask)));
    char buf[1600];char led_json[384];ot_st_format_json(led_json,sizeof(led_json));
    snprintf(buf,sizeof(buf),"{\"name\":\"OpenTail CORE Alpha\",\"version\":\"%s\",\"bench_only\":true,\"hardware_failover\":false,\"mode\":\"%s\",\"input_mask\":%u,\"simulated_mask\":%u,\"effective_mask\":%u,\"demo_active\":%s,\"native_show_active\":%s,\"frames\":%lu,\"leds_per_chain\":%u,\"brightness_cap\":%u,\"status_led\":%s,\"arbitration\":%s}",
       OT_FW,OT_SMALL_BENCH_LAYOUT?"30-pixel-bench":"universal-522-bench",
       (unsigned)physical,(unsigned)sim,(unsigned)(physical|sim),mode==OT_DEMO_OFF?"false":"true",show_active?"true":"false",
       (unsigned long)frames,(unsigned)layout.chain_pixels,(unsigned)layout.brightness_cap,led_json,arb_json);
    return send_json(r,buf);
}
static esp_err_t caps_get(httpd_req_t *r) {
    return send_json(r,"{\"protocol\":\"opentail-core-alpha-v1\",\"bench_only\":true,\"pixel_protocol\":\"WS2815-compatible RMT 800kHz\",\"color_order\":\"BRG\",\"outputs\":2,\"physical_inputs\":8,\"active_functions\":[\"park\",\"brake\",\"left\",\"right\",\"reverse\"],\"reserved_inputs\":[6,7,8],\"wifi\":\"WPA2 Access Point\",\"bluetooth\":false,\"firmware_sequences\":false,\"native_show_engine\":true,\"native_effects\":[\"solid\",\"chase\",\"breathe\",\"wipe\",\"rainbow\"],\"studio_wled_api_compatible\":false,\"hardware_failover\":false,\"trigger_arbitration_v1\":true,\"output_manager_v1\":true,\"output_manager_nvs\":true,\"status_led\":true,\"status_led_control\":false}");
}
static esp_err_t status_led_get(httpd_req_t *r){
    char buf[384];ot_st_format_json(buf,sizeof(buf));return send_json(r,buf);
}
/* Fixed-duration, strictly onboard RGB self-test; never touches external WS2815 outputs. */
static esp_err_t status_self_test_post(httpd_req_t *r){
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    const cJSON *v=cJSON_GetObjectItemCaseSensitive(obj,"mode");
    const char *mode=cJSON_IsString(v)?v->valuestring:"";
    ot_st_mode_t test=OT_ST_OFF;
    if(!strcmp(mode,"rainbow"))test=OT_ST_SHOW;
    else if(strcmp(mode,"stop")){cJSON_Delete(obj);return respond_err(r,400,"mode must be rainbow or stop (red reserved for actual faults)");}
    cJSON_Delete(obj);
    if(!ot_st_self_test(test))return respond_err(r,409,"self test unavailable or real fault active");
    return send_json(r,test==OT_ST_OFF?
        "{\"ok\":true,\"self_test_active\":false,\"message\":\"normal status restored\"}":
        "{\"ok\":true,\"self_test_active\":true,\"duration_ms\":5000,\"message\":\"onboard RGB only; no real fault or show started\"}");
}
static const char status_self_test_page[]=
"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>OpenTail RGB Self-Test</title><style>body{background:#000;color:#fff;font:15px system-ui,sans-serif;max-width:560px;margin:auto;padding:24px}"
".card{border:1px solid #2b2b2b;border-radius:20px;padding:22px}h1{font-size:22px;margin:0 0 8px}p{color:#aaa;line-height:1.6}"
"button{background:#161616;border:1px solid #363636;color:white;border-radius:13px;padding:13px 17px;margin:5px 5px 5px 0;min-height:48px;cursor:pointer}"
"button:disabled{opacity:.5}a{color:#aaa}#info{font-size:13px;color:#ddd;background:#0a0a0a;border-radius:12px;padding:14px;white-space:pre-wrap}</style></head>"
"<body><div class='card'><h1>CORE RGB Self-Test</h1><p>BENCH ONLY. Tests affect only the onboard RGB chip for 5 seconds."
"No physical fault, Show Mode, or external LED output is activated.</p>"
"<button onclick=\"run('rainbow')\">Rainbow · 5s</button>"
"<button onclick=\"run('stop')\">Stop / Restore</button>"
"<p id='info' role='status' aria-live='polite'>Reading status…</p>"
"<p><a href='/studio'>Back to Studio</a></p></div><script>"
"async function run(mode){try{const res=await fetch('/api/v1/status-led/self-test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode})});"
"const j=await res.json();if(!res.ok)throw Error(j.error||'Request failed');await update()}catch(e){document.getElementById('info').textContent='Error: '+e.message}}"
"async function update(){try{const s=await(await fetch('/api/v1/status-led',{cache:'no-store'})).json();"
"document.getElementById('info').textContent=s.self_test_active?('TEST: '+s.self_test_mode+' · '+(s.self_test_remaining_ms/1000).toFixed(1)+'s remaining')"
":('NORMAL STATUS: '+s.mode+(s.available?'':' (RGB unavailable)'))}catch(e){document.getElementById('info').textContent='Status error: '+e.message}}"
"setInterval(update,300);update()</script></body></html>";
static esp_err_t status_self_test_get(httpd_req_t *r){
    httpd_resp_set_type(r,"text/html; charset=utf-8");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_sendstr(r,status_self_test_page);
}
static esp_err_t status_session_post(httpd_req_t *r){
    cJSON *obj=NULL;int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    const cJSON *active=cJSON_GetObjectItemCaseSensitive(obj,"connected");
    if(!cJSON_IsBool(active)){cJSON_Delete(obj);return respond_err(r,400,"connected must be boolean");}
    ot_st_session(cJSON_IsTrue(active));cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true}");
}
static esp_err_t demo_post(httpd_req_t *r) {
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    cJSON *mode_json=cJSON_GetObjectItemCaseSensitive(obj,"mode");
    const char *str=cJSON_IsString(mode_json)?mode_json->valuestring:"";
    ot_demo_mode_t mode=OT_DEMO_OFF;
    if(!strcmp(str,"solid")) mode=OT_DEMO_SOLID;
    else if(!strcmp(str,"chase")) mode=OT_DEMO_CHASE;
    else if(strcmp(str,"off")){cJSON_Delete(obj);return respond_err(r,400,"mode must be solid, chase or off");}
    unsigned rcol=bounded_int(obj,"r",0,0,255),gcol=bounded_int(obj,"g",0,0,255),bcol=bounded_int(obj,"b",0,0,255);
    unsigned brightness=bounded_int(obj,"brightness",32,0,OT_MAX_BRIGHTNESS);
    unsigned ttl=bounded_int(obj,"ttl_ms",3000,100,OT_DEMO_MAX_MS);
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    demo=(ot_demo_t){mode,{rcol,gcol,bcol},brightness};
    demo_deadline=mode==OT_DEMO_OFF?now:now+pdMS_TO_TICKS(ttl);
    portEXIT_CRITICAL(&state_lock);
    cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true,\"message\":\"temporary demo scheduled; real trigger inputs have priority\"}");
}
static esp_err_t simulate_post(httpd_req_t *r) {
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    cJSON *arr=cJSON_GetObjectItemCaseSensitive(obj,"signals");
    if(!cJSON_IsArray(arr)){cJSON_Delete(obj);return respond_err(r,400,"signals must be an array");}
    uint8_t mask=0;
    cJSON *v=NULL;
    cJSON_ArrayForEach(v,arr){
       if(!cJSON_IsString(v)||!signal_mask_of(v->valuestring)){
          cJSON_Delete(obj);return respond_err(r,400,"unrecognized signal");
       }
       mask|=signal_mask_of(v->valuestring);
    }
    unsigned ttl=bounded_int(obj,"ttl_ms",2000,100,OT_DEMO_MAX_MS);
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    sim_mask=mask;
    sim_deadline=mask?now+pdMS_TO_TICKS(ttl):now;
    portEXIT_CRITICAL(&state_lock);
    cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true,\"message\":\"temporary isolated bench input simulation scheduled\"}");
}
static esp_err_t stop_post(httpd_req_t *r) {
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    demo.mode=OT_DEMO_OFF;demo_deadline=now;
    sim_mask=0;sim_deadline=now;
    native_show.mode=OT_SHOW_OFF;native_show_deadline=now;
    portEXIT_CRITICAL(&state_lock);
    ot_st_show_active(false);
    return send_json(r,"{\"ok\":true,\"message\":\"show, demo and simulation stopped; physical inputs still take precedence\"}");
}
static const char page[]=
"<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
"<title>OpenTail CORE Alpha</title><style>body{background:#0b0f0d;color:#f3fff4;font:16px system-ui;max-width:620px;margin:auto;padding:18px}"
"button{background:#193924;border:1px solid #39ff70;border-radius:12px;color:white;padding:12px;margin:5px;min-height:45px}"
"pre{white-space:pre-wrap;background:#171c19;padding:14px;border-radius:12px}h1{color:#39ff70}small{color:#afb9b1}</style></head><body>"
"<h1>OpenTail CORE Alpha</h1><p>BENCH ONLY - no road lighting or failover</p>"
"<p><a style=\"color:#39ff70;font-weight:bold\" href=\"/studio\">Open OpenTail Studio v0.19.43 →</a></p>"
"<p><a style=\"color:#aaa\" href=\"/status-self-test\">Onboard RGB self-test (bench only) →</a></p>"
"<h3>Inputs (2 second test)</h3><div id=signals></div>"
"<h3>Color demos (3 second test)</h3><div id=colors></div>"
"<p><button onclick=post('/api/v1/stop',{})>STOP DEMO</button></p>"
"<h3>Controller Status</h3><pre id=status>Connecting...</pre><small>OpenTail Alpha uses its own API. Current Studio WLED connection mode is not compatible.</small>"
"<script>async function post(p,b){try{const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});"
"if(!r.ok)alert(await r.text());await refresh()}catch(e){alert(e.message)}}"
"async function refresh(){try{document.getElementById('status').textContent=JSON.stringify(await(await fetch('/api/v1/status')).json(),null,2)}catch(e){document.getElementById('status').textContent=e.message}}"
"for(const n of ['park','brake','left','right','reverse']){let b=document.createElement('button');b.textContent=n;b.onclick=()=>post('/api/v1/simulate',{signals:[n],ttl_ms:2000});document.getElementById('signals').append(b)}"
"for(const [n,c] of Object.entries({Red:[255,0,0],Green:[0,255,0],Blue:[0,0,255],White:[255,255,255]})){let b=document.createElement('button');b.textContent=n;b.onclick=()=>post('/api/v1/demo',{mode:'solid',r:c[0],g:c[1],b:c[2],brightness:24,ttl_ms:3000});document.getElementById('colors').append(b)}"
"setInterval(refresh,1000);refresh()</script></body></html>";
/* OpenTail Studio v0.19.43 is served locally from the CORE access point.
 * Gzip is embedded into the application at compile time; no filesystem or WLED needed.
 * Browser uses same-origin /api/v1/... and does not require broad CORS access. */
extern const uint8_t studio_gz_start[] asm("_binary_studio_htm_gz_start");
extern const uint8_t studio_gz_end[] asm("_binary_studio_htm_gz_end");
static esp_err_t studio_get(httpd_req_t *r) {
    httpd_resp_set_type(r,"text/html; charset=utf-8");
    httpd_resp_set_hdr(r,"Content-Encoding","gzip");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_send(r,(const char *)studio_gz_start,(ssize_t)(studio_gz_end-studio_gz_start));
}
static esp_err_t root_get(httpd_req_t *r) {httpd_resp_set_type(r,"text/html; charset=utf-8");return httpd_resp_sendstr(r,page);}
static void http_start(void) {
    httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();cfg.max_uri_handlers=20;cfg.stack_size=8192;
    httpd_handle_t server=NULL;
    ESP_ERROR_CHECK(httpd_start(&server,&cfg));
    const httpd_uri_t routes[]={
        {.uri="/",.method=HTTP_GET,.handler=root_get},
        {.uri="/studio",.method=HTTP_GET,.handler=studio_get},
        {.uri="/api/v1/status",.method=HTTP_GET,.handler=status_get},
        {.uri="/api/v1/status-led",.method=HTTP_GET,.handler=status_led_get},
        {.uri="/status-self-test",.method=HTTP_GET,.handler=status_self_test_get},
        {.uri="/api/v1/status-led/self-test",.method=HTTP_POST,.handler=status_self_test_post},
        {.uri="/api/v1/status-led/session",.method=HTTP_POST,.handler=status_session_post},
        {.uri="/api/v1/capabilities",.method=HTTP_GET,.handler=caps_get},
        {.uri="/api/v1/demo",.method=HTTP_POST,.handler=demo_post},
        {.uri="/api/v1/simulate",.method=HTTP_POST,.handler=simulate_post},
        {.uri="/api/v1/stop",.method=HTTP_POST,.handler=stop_post},
        {.uri="/api/v1/show",.method=HTTP_GET,.handler=show_get},
        {.uri="/api/v1/show/start",.method=HTTP_POST,.handler=show_start},
        {.uri="/api/v1/show/stop",.method=HTTP_POST,.handler=show_stop},
        {.uri="/api/v1/outputs",.method=HTTP_GET,.handler=om_get},
        {.uri="/api/v1/outputs",.method=HTTP_POST,.handler=om_post}
    };
    for(size_t i=0;i<sizeof(routes)/sizeof(routes[0]);++i) ESP_ERROR_CHECK(httpd_register_uri_handler(server,&routes[i]));
}
static void wifi_ap_init(void) {
    const char *psk=CONFIG_OPENTAIL_AP_PASSWORD;
    size_t n=strlen(psk);
    if(n<8||n>63){ESP_LOGE(TAG,"AP password must be 8-63 characters");abort();}
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_ap();
    wifi_init_config_t init=WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    wifi_config_t conf={0};
    strncpy((char*)conf.ap.ssid,OT_AP_SSID,sizeof(conf.ap.ssid)-1);
    conf.ap.ssid_len=strlen(OT_AP_SSID);
    strncpy((char*)conf.ap.password,psk,sizeof(conf.ap.password)-1);
    conf.ap.channel=1;
    conf.ap.max_connection=2;
    conf.ap.authmode=WIFI_AUTH_WPA2_PSK;
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP,&conf));
    ESP_ERROR_CHECK(esp_wifi_start());
    ot_st_wifi_ready();
    ESP_LOGW(TAG,"BENCH ONLY: connect to Wi-Fi %s; browse http://192.168.4.1/",OT_AP_SSID);
}
static void input_init(void) {
    for(int i=0;i<OT_IN_COUNT;++i){
        gpio_config_t cfg={.pin_bit_mask=1ULL<<input_pin[i],.mode=GPIO_MODE_INPUT,
                           .pull_up_en=GPIO_PULLUP_ENABLE,.pull_down_en=GPIO_PULLDOWN_DISABLE,
                           .intr_type=GPIO_INTR_DISABLE};
        ESP_ERROR_CHECK(gpio_config(&cfg));
    }
}
static bool strip_init(void) {
    for(int ch=0;ch<OT_CHAIN_COUNT;++ch){
        const led_strip_config_t cfg={
            .strip_gpio_num=out_pin[ch],.max_leds=OT_CHAIN_PIXELS,
            .led_model=LED_MODEL_WS2812, // WS2815 uses compatible nominal 800kHz data; scope verification required.
            .color_component_format={.format={.r_pos=1,.g_pos=2,.b_pos=0,.w_pos=3,.num_components=3}}, // B-R-G
            .flags={.invert_out=false}
        };
        const led_strip_rmt_config_t rmt={
            .clk_src=RMT_CLK_SRC_DEFAULT,.resolution_hz=10000000,.mem_block_symbols=64,
            .flags={.with_dma=(ch==0)}
        };
        esp_err_t e=led_strip_new_rmt_device(&cfg,&rmt,&strip[ch]);
        if(e==ESP_OK)e=led_strip_clear(strip[ch]);
        if(e!=ESP_OK){ESP_LOGE(TAG,"RMT output %d failed: %s",ch,esp_err_to_name(e));
            ot_st_set_fault("external pixel RMT initialization failed");return false;}
    }
    return true;
}
static void led_task(void *p) {
    (void)p;
    unsigned tenth=0;
    while(1){
       bool levels[OT_IN_COUNT];
       for(int i=0;i<OT_IN_COUNT;++i) {
           int pin=gpio_get_level(input_pin[i]);
           levels[i]=OT_INPUT_ACTIVE_LOW?(pin==0):(pin!=0);
       }
       uint8_t physical=ot_debounce(&inputs,levels,OT_DEBOUNCE_TICKS);
       TickType_t now=xTaskGetTickCount();
       ot_demo_t local_demo={0};ot_show_t local_show={0};uint32_t show_started=0;uint8_t combined=0;
       ot_om_output_t local_outputs[OT_OM_OUTPUTS];
       portENTER_CRITICAL(&state_lock);
       live_input_mask=physical;
       memcpy(local_outputs,om_outputs,sizeof(local_outputs));
       combined=physical;
       if(before_deadline(now,sim_deadline)) combined|=sim_mask;
       if(before_deadline(now,demo_deadline)) local_demo=demo;
       if(show_window(now)){local_show=native_show;show_started=native_show_started_ms;}
       else native_show.mode=OT_SHOW_OFF;
       portEXIT_CRITICAL(&state_lock);
       const ot_arbitration_t decision=ot_arbitrate(combined,local_demo.mode!=OT_DEMO_OFF,local_show.mode!=OT_SHOW_OFF);
       bool native_rendering=decision.mode==OT_ARB_SHOW;
       ot_st_show_active(native_rendering);
       if((tenth++%5)==0){
           uint32_t elapsed=(uint32_t)((uint32_t)(esp_timer_get_time()/1000LL)-show_started);
           for(int ch=0;ch<OT_CHAIN_COUNT;++ch){
               const ot_om_output_t *output=&local_outputs[ch];
               ot_layout_t zone_layout;
               if(!ot_om_layout(output,&zone_layout)){
                   ot_st_set_fault("invalid output mapping");break;
               }
               for(unsigned px=0;px<layout.chain_pixels;++px){
                   ot_rgb_t c={0,0,0};
                   int zone=ot_om_section(output,px);
                   if(zone>=0 && output->zones[zone].role!=OT_OM_OFF){
                       if(combined){
                           c=ot_om_trigger_color(output->zones[zone].role,combined,OT_MAX_BRIGHTNESS);
                       }else if(native_rendering){
                           c=ot_show_pixel(&local_show,&zone_layout,ch,px,elapsed);
                       }else if(local_demo.mode!=OT_DEMO_OFF){
                           c=ot_pixel_color(&zone_layout,ch,px,0,&local_demo,frame_index);
                       }
                   }
                   c=ot_om_swizzle(c,output->color_order);
                   ESP_ERROR_CHECK(led_strip_set_pixel(strip[ch],px,c.r,c.g,c.b));
               }
               // Driver reserves 522 pixels per channel; unused pixels remain black.
               ESP_ERROR_CHECK(led_strip_refresh(strip[ch]));
           }
           portENTER_CRITICAL(&state_lock); frame_index++; portEXIT_CRITICAL(&state_lock);
       }
       vTaskDelay(pdMS_TO_TICKS(10));
    }
}
void app_main(void) {
    ESP_LOGW(TAG,"CORE %s is BENCH-ONLY. No hardware failover. Do not install as road lights.",OT_FW);
    ESP_ERROR_CHECK(nvs_flash_init());
    om_load();
    if(!ot_layout_valid(&layout)){ESP_LOGE(TAG,"Invalid LED layout");abort();}
    ot_st_init();
    input_init();
    bool outputs_ready=strip_init();
    portENTER_CRITICAL(&state_lock);native_outputs_ready=outputs_ready;portEXIT_CRITICAL(&state_lock);
    wifi_ap_init();
    http_start();
    if(outputs_ready){
        BaseType_t created=xTaskCreate(led_task,"ot_led",8192,NULL,8,NULL);
        if(created!=pdPASS){portENTER_CRITICAL(&state_lock);native_outputs_ready=false;portEXIT_CRITICAL(&state_lock);ot_st_set_fault("render task could not start");}
    }else ESP_LOGE(TAG,"Pixel task intentionally disabled; CORE is in BENCH FAULT state");
}
