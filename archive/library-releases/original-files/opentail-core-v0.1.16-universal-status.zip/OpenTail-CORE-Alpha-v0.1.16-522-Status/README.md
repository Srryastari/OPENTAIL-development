# OpenTail CORE Alpha v0.1.16 — 522-pixel bench upgrade + status revision

Start with **INSTALL-WINDOWS.md** for the complete flashing procedure. See **README-522-TEST.md** for the pixel-count upgrade and **STATUS-REVISION.md** for the new onboard RGB states.

This is BENCH-ONLY development software. Pixel outputs GPIO16/17; 522-pixel maximum per output; eight optically isolated trigger GPIOs 4–11. It does **not** provide 12 independent physical outputs or automotive failover. It does not make the GS400 suitable for road use without independent factory lighting.

The earlier v0.1.15 project tested up to 30 direct GPIO16 pixels and user-reported correct colors and persistent configuration. This revision has NOT been flashed or bench-tested on the user's hardware. A successful build/host test is not proof of physical pixel output.

For full release context, the older README content is archived as **README-PREVIOUS-v0.1.15.md**.

## Universal configuration clarification
The 522 number is the **bench allocation per physical output**, not a GS400 layout requirement or production pixel ceiling. CORE initializes with generic/example Output Manager settings and **retains previously saved NVS configuration**. GS400 main housing is a **manual, optional Studio preset** only. Output names, active pixel counts, zone labels, sizes, roles, and color orders can be saved independently for both current physical outputs. Alpha v1 presently has **five zone slots per output** (unused slots may be zero pixels). The target universal release requires user-controlled variable zone counts and 12 physical outputs; neither is implemented here.

Backend output-save validation now permits zero-pixel zone slots, consistent with the existing Studio editor and output-manager model.
