# OpenTail CORE Alpha v0.1.12 — ESP32-S3 bench firmware

**Status: SOURCE RELEASE — v0.1.12 has not yet been compiled or flashed. User has reported seeing the v0.1.9 onboard LED pulse. Not road-safe.**

A dedicated ESP-IDF firmware prototype for your hiBCTR ESP32-S3-WROOM-1-N16R8 (16 MB flash / 8 MB PSRAM) dev board, two 12V WS2815 data chains, and 8 isolated 3.3-V logic inputs. **Keep the production car lights on the OEM circuit while testing.** This firmware does **not** implement hardware failover, backup controller supervision, protected automotive power supply, guaranteed road-compliant output, or shutdown animations.

## What is actually implemented

- ESP32-S3 stand-alone firmware (ESP-IDF project; no WLED runtime)
- Two independent 800 kHz RMT channels, 5-V-shifted externally via Adafruit Pixel Shifter #6066 (DAT/D5 and CLK/C5).
- BRG byte order as established by your GS400 bench build; GPIO outputs stay at the ESP32's 3.3 V logic level until translated by the shifter.
- Eight configurable *wiring* inputs with 40 ms software debounce, normally interpreted as **active-low** at the GPIO, using internal pullups. Inputs 1–5 represent Park/Brake/Left/Right/Reverse, 6–8 reserved/unmapped.
- Simple, independent section logic on two sides with brake priority over parking within red sections; turn and reverse sections remain separate.
- Bench Wi-Fi access point (WPA2), status and capabilities REST endpoints, 10-second-maximum temporary effect demos and simulated trigger tests, plus embedded phone/desktop-friendly browser controls.
- One LED task exclusively owns pixel writes; physical inputs override all simulated/demo lighting.
- Cold boot clears LED outputs. Temporary demos expire and default to OFF.

**Not implemented:** Execution of WLED Studio effects and sequences on CORE firmware (the Studio UI connects through CORE Alpha v1 API but its WLED effects require an additional firmware engine), Bluetooth LE pairing, full WLED effects / palettes / sequences, custom palette storage, generic variable-size universal zone registry, trigger animation sweeps, ignition detection, automatic startup/shutdown, CAN, OTA, dual-board failover, watchdog/output selector, diagnostics log storage, automotive fault tolerance.

## Source structure

- `main/opentail_core.c` — network, HTTP, GPIO, RMT outputs and main loop
- `main/core_logic.c` / `core_logic.h` — pure-C layout, priority, color and input debounce logic
- `main/board_config.h` — provisional pins, small-strip profile, segment lengths, output brightness limit
- `main/Kconfig.projbuild` — compile-time WPA2 AP password (change it!)
- `main/idf_component.yml` — pinned Espressif `led_strip==3.0.3` dependency
- `tests/` — desktop GCC assertions, no attached hardware
- `API.md` — HTTP protocol and example commands

## Proposed GPIO assignments — verify against your physical dev-board silkscreen

| Signal | ESP32-S3 GPIO | Connection |
|---|---:|---|
| Left WS2815 data | 16 | Pixel Shifter **DAT** input; **D5** output to left **DI** |
| Right WS2815 data | 17 | Pixel Shifter **CLK** input; **C5** output to right **DI** |
| Input 1: Park | 4 | 3.3 V-safe **isolated module output** 1 |
| Input 2: Brake | 5 | isolated output 2 |
| Input 3: Left turn | 6 | isolated output 3 |
| Input 4: Right turn | 7 | isolated output 4 |
| Input 5: Reverse | 8 | isolated output 5 |
| Input 6: spare | 9 | isolated output 6 |
| Input 7: spare | 10 | isolated output 7 |
| Input 8: spare | 11 | isolated output 8 |
| GND | GND | Common LED power / shifter / ESP GND on the logic side |
| Shifter V | **3V3** | Connect to ESP **3V3**, *not* LED 12 V; board generates its own 5-V shifted output |
| WS2815 +12 V | — | Separately fused **12 V** LED supply; **not to ESP32 GPIO/VIN/3V3** |
| ESP32 power | USB-C | USB from a computer or suitable regulated USB supply during bench tests |

The Adafruit #6066 labels one shifter path as `CLK/C5` because it is intended for clocked LEDs. Electrically, it is an independent non-inverting shifter and can act as the second data path for independently clockless WS2815 chains. The inverted `!D5` output is **not used**. Do not equate D5/C5 with the WS2815 redundant **BI** backup pin; BI wiring depends on your specific strip connector/pad geometry and should be separately verified against its diagram.

**Optocoupler safety:** Do not connect 12 V to any ESP32 GPIO. Verify your exact optocoupler board's pin labels, isolated-side 3.3-V output level, output polarity and isolation arrangement with a meter before connection. If applying 12 V makes the isolated output go HIGH rather than LOW, change `OT_INPUT_ACTIVE_LOW` to `0` before rebuilding. Some modules need a pullup on the isolated side, or have common grounds that compromise isolation; inspect yours first.

## Default LED layout is deliberately small

The default is **30 pixels per chain (60 total)** and five 6-pixel sections per side (`Top → Turn → Reverse → Bottom → Trunk`); this is strictly for short detached test strips. Full GS400 example lengths are included in `board_config.h`, but **disabled** by default:

| Section | Left | Right |
|---|---:|---:|
| Top (park/brake) | 118 | 118 |
| Turn | 109 | 109 |
| Reverse | 42 | 42 |
| Bottom (park/brake) | 253 | 253 |
| Trunk (park/brake) | 101 | 101 |
| **Total** | **623** | **623** |

Set `OT_SMALL_BENCH_LAYOUT 0` for 623 LEDs per chain only **after** separate power and output timing validation. The default `OT_MAX_BRIGHTNESS 32` is **a pixel-channel cap**, *not* a PSU current limit. A 48 W 12 V power supply is only 4 A; it is not adequate by assumption for your 1,246-pixel array. Use a short test strip, appropriate fusing, power wiring and injection before expanding.

## Windows build and flash (requires ESP-IDF)

1. Install Espressif's official **ESP-IDF 5.5.x** development environment on Windows (ESP-IDF tools / ESP-IDF VS Code extension). Use the supplied ESP-IDF command prompt.
2. Extract this ZIP; in the ESP-IDF command prompt, `cd` into the `OpenTail-CORE-Alpha-v0.1.12` directory.
3. Run `idf.py set-target esp32s3`.
4. Run `idf.py menuconfig` → **OpenTail CORE Alpha** → **Wi-Fi AP password**. Change the demo password. Save, then exit.
5. Run `idf.py build`. Dependencies are downloaded by ESP-IDF component manager.
6. Plug a **data-capable** USB-C cable into the ESP32-S3 board. Find its COM port in Windows Device Manager.
7. Run `idf.py -p COM9 flash monitor` (replace `COM9` if your port has changed). If it does not enter the bootloader, hold BOOT, tap RESET, release BOOT, retry.
8. Connect your phone/PC to Wi-Fi `OpenTail-CORE-Alpha` using the password you configured. Open **http://192.168.4.1/**.
9. Start with **only the board powered by USB**. Verify `/api/v1/status`, then connect one correctly level-shifted short test strip, a fused 12 V supply and common GND. Use the temporary Red/Green/Blue test, checking against the intended BRG order. Connect the second chain only after first-chain success.
10. Connect isolated trigger channels **only after** testing their 3.3-V GPIO-side levels and polarity separately. Keep your vehicle OEM lamps intact and working.

If the build rejects memory-layout or flash settings, review `sdkconfig.defaults`, the ESP-IDF target and your actual module; don't force-flash a mismatched binary. `idf.py` builds a .bin **on your computer**, not in this ZIP. This package intentionally does not contain an unverified firmware binary.

## Host logic checks

On Linux/macOS with `cc`: `sh tests/run-host-tests.sh`

On Windows with GCC / MSYS2, the same script can be used from the MSYS2 shell. Host checks do **not** prove ESP-IDF compilation, board pin compatibility, LED signaling, electrically safe input isolation or in-car reliability.

## Current safe acceptance gate

1. ESP-IDF `idf.py build` completes successfully for `esp32s3`.
2. Board boots without crashes, phone connects to AP, `GET /api/v1/status` reports `bench_only:true`.
3. A short WS2815 strip cycles red/green/blue correctly on D5, then independently on C5.
4. With an isolated 3.3-V output, each input 1–5 produces its corresponding lighting on the correct section; Left/Right remain independent.
5. Removing the trigger signal returns only that function's lighting to OFF; Brake takes precedence over Park in shared red sections.
6. A demo is automatically cleared on timeout; a physical Brake input preempts it; POST Stop clears tests without disabling real inputs.
7. No sustained excessive heat, flicker, voltage sag or reset at tested load.

**Do not install on the road.** The final OpenTail requirement (hardware safety fallback / redundant controller / output selector / automotive-grade power conditioning) is not part of Alpha v0.1.12.

## References

- ESP-IDF GPIO restrictions: https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/peripherals/gpio.html
- Espressif led_strip component 3.0.3: https://components.espressif.com/components/espressif/led_strip/versions/3.0.3
- Adafruit #6066 pinout: https://learn.adafruit.com/adafruit-pixel-shifter/pinouts
- Espressif installation: https://docs.espressif.com/projects/esp-idf/en/v5.5.2/esp32s3/get-started/

## Studio-to-CORE bridge (new in 0.1.1)

- Studio v0.19.39 is compiled into firmware as a **gzip-compressed HTML page** served from `http://192.168.4.1/studio` when joined to the OpenTail-CORE-Alpha AP.
- `http://192.168.4.1/` remains the minimal firmware test console.
- Studio's Connect screen lets you choose **WLED** or **OpenTail CORE**. CORE mode connects to `/api/v1/capabilities` and `/api/v1/status`, then offers low-brightness temporary `/api/v1/demo` and `/api/v1/simulate` controls, `/api/v1/stop`, and live status refresh.
- Firmware v0.1.12 **does not** implement WLED's full effect engine, arbitrary colors across sequences, saved palettes, production-grade stored shows, automatic startup/shutdown, or failover. It does include the first five bench-only native effects described below.
- Requests from a WLED-hosted page may fail when the iPhone/PC is connected to the separate CORE Wi-Fi; open `/studio` directly instead. No broad browser CORS exemption is configured.
- CORE Alpha boot uses the first RMT channel with DMA and the second without DMA. This mirrors the user's successfully flashed v0.1.0 hardware adjustment. Both physical outputs remain unverified.
- After flashing, check the serial log for `CORE 0.1.12-alpha` and visit the local `/studio` page. Firmware version has changed, but the CORE Alpha v1 HTTP protocol remains the same.

### Reusing your prior Wi-Fi configuration

If upgrading from an existing, locally built v0.1.0 project, copy its **private** `sdkconfig` file to the v0.1.12 root before the first build, using PowerShell. That retains your own configured AP password. Do **not** upload or distribute `sdkconfig` with your actual password.

```powershell
# Run from the v0.1.12 project directory; adjust old path if your directory differs
Copy-Item "..\OpenTail-CORE-Alpha-v0.1.0\OpenTail-CORE-Alpha-v0.1.0\sdkconfig" ".\sdkconfig"
idf.py build
idf.py -p COM9 flash monitor
```

If `idf.py set-target` resets your local configuration, use `idf.py menuconfig` and re-enter the AP password before building.

## Onboard RGB status LED (introduced in v0.1.8)

The onboard programmable WS2812/NeoPixel (provisional GPIO48 on this ESP32-S3 board, GRB order) is driven from SPI2 via `led_strip_spi` and does not allocate an additional RMT channel. Verify your particular board revision and the RGB solder jumper before assuming the diode will illuminate. The existing tiny power/TX/RX indicator LEDs are unchanged.

- Startup: one white flash, 300 ms.
- Wi-Fi ready: one smoothly pulsing blue flash every 1.0 s.
- Studio connected: two green pulses, 120 ms each, repeat every 2.2 s. Requires a heartbeat from the updated Studio app, not just Wi-Fi association.
- Studio disconnected: two red pulses, 120 ms each, repeat every 2.2 s. Only after a previously established session is lost; heartbeat timeout is 8 s.
- Show Mode: fluid rainbow, 1.4 s per cycle. As of v0.1.12, the onboard status indicator enters this mode while the five-effect native bench show engine is actively rendering; full production Show Modes are not implemented.
- Controller fault: red flashing continuously 90 ms ON / 90 ms OFF, without grouped pauses. This status is currently wired to external RMT output initialization/render-task-startup errors; it is **not a comprehensive automotive diagnostic or a safety device**.

The onboard status LED runs automatically at a fixed 65% firmware brightness. Studio Diagnostics shows the current state, without a brightness slider, enable/disable switch, or animation tester. Prior v0.1.8 NVS status-light preferences are intentionally ignored. An unpowered or disconnected LED cannot signal faults.

`/api/v1/status` contains the `status_led` object. The same information is returned from `GET /api/v1/status-led`. `POST /api/v1/status-led` has been removed; the status-light settings are fixed. `POST /api/v1/status-led/session` accepts Studio's `{"connected":true}` heartbeat or `{"connected":false}` for explicit disconnect. The status-light configuration POST route was removed in v0.1.12; other Alpha v1 commands are retained.

**No automotive protection, backup MCU, or independent lighting fail-safe has been added. Keep this prototype USB-powered and on a bench.** The current board integration has host timing/UI tests, but no local ESP-IDF cross-compiler or hardware was available for compiling or verifying this update in this environment.

### v0.1.12 fixed-status-light UI

Studio v0.19.39 displays a read-only status card in CORE Diagnostics. The onboard WS2812 is always enabled and uses a compile-time 65% brightness value. To change it requires a new firmware build, not a Studio setting. Previous experimental enabled/brightness preferences in NVS are ignored. The status light is not a substitute for independent safety lighting.

### v0.1.12 color-only refinement

- Wi-Fi-ready status is now **saturated blue RGB (0,0,255)**. Connected uses pure green (0,255,0), disconnected/fault use pure red (255,0,0). Rainbow uses fully saturated hue stops. The previous mixed-channel values caused pastel-looking hues.
- Wi-Fi pulse timing **unchanged**: one smooth pulse each 1.0 second. Other status animations, priority, status APIs and hardware wiring are unchanged.
- Studio v0.19.39 changes the current-state labels to **Blue pulse**, with no interface redesign.
- This change is source-tested but not yet cross-compiled or hardware-verified.

### Status LED saturation correction (v0.1.12)

The status RGB defaults use full-saturation primaries at the same **fixed firmware brightness (65%)**. If a primary still looks pale or wrong on the physical onboard LED, confirm the fitted pixel type and test `LED_STRIP_COLOR_COMPONENT_FMT_GRB` channel order on the specific PCB revision. This release does not include a physical channel-order verification or adjust the three independent indicator LEDs. All status timing and safety priorities are unchanged.

## Temporary onboard RGB indicator test — v0.1.12

The last two unverified RGB animations (Show Mode rainbow and controller-fault flashing) can now be visually inspected **without asserting a real fault or running a show**. On the USB-powered, isolated bench ESP32-S3, connect to the CORE Wi-Fi access point and browse `http://192.168.4.1/status-self-test`. Tap **Rainbow · 5s** or **Fault flashes · 5s**. The onboard RGB returns to the normal blue/green/red state automatically after 5 seconds; **Stop / Restore** ends it early. No external WS2815 output, input, light profile, or actual system fault state is changed. An actual controller fault overrides tests. This special test page is separate from Studio Diagnostics and intended to remain a developer/service feature only.

Status self-test assumes the onboard RGB is wired to the provisional GPIO48 and that the SPI driver initializes. Existing Studio v0.19.39 is unchanged. Unit/host tests do not replace `idf.py build`, hardware flashing, or on-board validation.

## v0.1.12 — first native Show Modes bench engine

This revision adds **five** independently rendered CORE effects: `solid`, `chase`, `breathe`, `wipe` and `rainbow`. They are implemented in portable `main/show_logic.c`; the existing RMT task remains the **only** owner of external pixel output. The onboard RGB status LED automatically shows its verified rainbow when the native show actually renders. The board continues functioning during brief Studio disconnections for the requested timeout, up to 60 seconds; it **does not** store the show or start shows on boot.

In Studio v0.19.39, choose **Show Modes → CORE Native Effects**. The existing local WLED-effect editor and LED-strip preview remain, but neither can be treated as a true readback of CORE pixels. Start/Stop/Refresh on the native panel send distinct CORE API commands. No new device wiring is required to test the onboard rainbow status indication.

**Critical safety:** the default layout stays at 30 pixels per chain, 2 provisional 800kHz outputs (GPIO16/17). Output brightness cannot exceed 32/255 in firmware. All real or simulated vehicle inputs preempt a native show *on both chains*. Temporary `/demo` commands also preempt a show; pressing global Stop clears demos, show and simulations. Actual external WS2815 output **still requires a verified 5V data level shifter**, fused independent 12V pixel power and common reference ground. Never connect 12V lighting signals directly to ESP32 GPIO. This Alpha does not have backup controllers, hardware failover, power protection, or road-lighting validation. Keep installed OEM road lights unchanged.

The 5 effects and controller APIs are a first bench milestone, **not** the full WLED effect library, full universal OpenTail feature set, customizable saved sequences, or production safety logic. Physical frame timing and visible colors on strips still require hardware testing.

### Initial isolated validation

1. Use ESP-IDF v5.5.5 to compile the v0.1.12 source; reuse your private local `sdkconfig` for AP password (do not share that file).
2. Flash by `idf.py -p COM9 flash monitor` if Device Manager still shows COM9.
3. With *only USB connected*, open `http://192.168.4.1/studio` → Show Modes → CORE Native Effects. Start Rainbow for 15 seconds and check the **onboard status LED** enters rainbow; Stop should return to connected green or blue Wi-Fi status. (Without an external LED strip, pixel output remains unverified.)
4. Confirm `GET /api/v1/show` reports timeout and status. Test a simulated Brake; Show Mode should be suppressed while Brake is active and restored if time remains.
5. Only after validating your level shifter and safe power supply, test one short WS2815 chain for actual external output.

**Build/test disclosure:** portable host tests and simulated Studio controls are not proof of ESP-IDF compilation or real physical WS2815 behavior. Flash and bench verify the new source before treating it as operational.
