# OpenTail CORE Alpha 0.1.12 / Studio 0.19.39

- Adds first non-persistent native CORE lighting engine (`main/show_logic.c`).
- New native bench effects: Solid, Chase, Breathe, Wipe, Rainbow.
- Runtime selection: left/right/both outputs and one of several bench zone masks.
- Runtime speed (0–100%), capped brightness (0–32/255), effect color and up-to-60-second timeout.
- Existing trigger priority overrides full Show Mode.
- Starts onboard RGB rainbow when native show is actively rendering; restores normal indicator when inactive.
- `GET /api/v1/show`, `POST /api/v1/show/start`, `POST /api/v1/show/stop`.
- Existing global Stop also clears native show. No stored shows, boot playback or sequences.
- Studio v0.19.39 adds CORE Native Effects panel under existing Show Modes tab; WLED UI unchanged.
- Uses approved OLED-black/white theme; default glowing pill LEDs and simulation/live labels are unchanged.
- Bench-only. No verified vehicle safety fallback, output electrical validation, or production readiness.
