# OpenTail Android v0.1.0 — first native preview

**Status: Android Studio source project, NOT a tested APK.** Native Android build and physical phone testing have not been run in this environment. Target: Android 8.0+ (API 26+); build uses Android Gradle Plugin 8.9.2, Gradle 8.11.1, JDK 17, and compile SDK 35. Install Android Studio and SDK 35 to compile it.

## What actually exists

- Native Android Activity with Wi-Fi setup, verified CORE connectivity, embedded web controls and BLE scanner.
- **Live Wi-Fi Studio** uses the exact HTML served by firmware v0.1.18 at `http://192.168.4.1/studio`. This preserves the working CORE/WLED editor and same-origin CORE API requests. It does **not** use a different, untested API client.
- **Offline Studio** is bundled `opentail-v0.19.45.htm`, usable for local UI/project work, but **cannot send commands or save settings to CORE** while in offline mode. The CORE-hosted page and the offline page use separate browser origins and separate local storage. Use **Export Project / Import Project** to transfer local drafts between modes. Android document pickers handle `.json` project import/export.
- **Bluetooth LE** scans for advertised name `OpenTail CORE`, connects using Android BLE GATT, and reads the existing read-only info characteristic (`55a56022-4915-7a92-cf44-b8b7102eaf22`). The service is `55a56022-4915-7a92-cf44-b8b7102eaf21`. The firmware may not have Bluetooth enabled in a given build; success still requires a physical test.
- The native BLE screen **cannot change LEDs, effects, triggers or settings**. There is no writable/authenticated BLE control API in CORE v0.1.18.
- Scoped network permission: HTTP only to the CORE AP address. Navigation to public websites is blocked.
- **Bench only.** CORE v0.1.18 is not automotive-safety hardware; do not use it as the only road lighting controller.

## Open and build on Windows

1. Install [Android Studio](https://developer.android.com/studio). Install **Android SDK 35** and choose **JDK 17** in Gradle settings.
2. Extract `OpenTail-Android-v0.1.0.zip` (do **not** overwrite your CORE firmware project).
3. Android Studio → **Open** → select the extracted `OpenTail-Android-v0.1.0` folder containing `settings.gradle`.
4. Let Gradle sync and download AGP/AndroidX dependencies. The included `gradle/wrapper/gradle-wrapper.properties` pins Gradle 8.11.1. A CLI Gradle wrapper executable/JAR is **not** bundled; use Android Studio's build tooling, or generate a wrapper with an installed Gradle before building via command line.
5. Android Studio → **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Install/debug on a physical Android phone (BLE validation requires a Bluetooth LE-capable device). This source has **not** been compiled here; if Android Studio reports errors, retain the log rather than assuming the APK is correct.

## Connection and tests

1. On the phone, select **Wi-Fi settings**; join `OpenTail-CORE-Alpha` with **your existing saved password**. Don't put that password in the app's source.
2. Return to OpenTail and tap **Connect CORE**. The app binds to the Wi-Fi transport and checks `/api/v1/capabilities` for `opentail-core-alpha-v1` and `bench_only=true`, then opens `/studio`.
3. Confirm Studio **v0.19.45** and read the saved Output Manager/Trigger Manager settings. Don't modify them until readback succeeds. Preserve your verified 522-pixel GPIO16 and 30-pixel GPIO17 profiles.
4. Tap **Find BLE** and grant Nearby Devices (Android 12+) or location permission (Android 8–11). The advertised `OpenTail CORE` should appear only if NimBLE actually initialized on the ESP32. Tap it to connect and read info. Expect the onboard LED purple for BLE alone or teal with Studio active, if those status behaviors remain enabled.
5. Use **Offline Studio** when disconnected. The embedded copy cannot connect to the HTTP CORE API from its secure offline origin; never infer that local edits are saved on the ESP32.

## Regression/protection policy

- This package **does not modify CORE firmware, Studio `.htm`, or controller NVS**. It includes an identical copy of v0.19.45 HTML as an asset.
- No Arduino/ESP-IDF reflashing is needed to build the Android app.
- Wi-Fi control stays on the device's existing proven HTTP routes. No invented BLE write commands or route changes.
- `qa/check_release.py` performs static/package checks. It **cannot** establish Android build success or phone/BLE hardware behavior.
- Until proven with a device, this is an **early source preview**, not a full production Android app.

## Planned next stages

1. Android Studio compile + install on a phone; fix any errors; confirm Wi-Fi/Studio project readback and export/import.
2. Verify read-only BLE GATT on v0.1.18 and troubleshoot NimBLE configuration if no advertisement appears.
3. Define authenticated BLE control protocol in CORE, with validation, version negotiation, backpressure and safety boundaries; expand Android native BLE commands once firmware exists.
4. Add controller discovery, connection recovery, and packaged APK release with reproducible CI build and regression reporting.
