# OpenTail Android v0.1.0 — Build and install (bench test)

**No verified APK is included.** The original v0.1.0 app source is unchanged. Build and phone testing are outstanding; do not confuse the 16 static checks with a real Android build.

## Option A — Windows Android Studio (recommended)

1. Install Android Studio from https://developer.android.com/studio, including Android SDK Platform 35 (Android 15), Android SDK Build-Tools 35.x, and JDK 17 (the bundled Android Studio JDK generally works).
2. Extract this ZIP and open the **OpenTail-Android-v0.1.0-Phone-Test** folder in Android Studio. The folder containing `settings.gradle` is the project root.
3. Let Gradle Sync finish. This project pins Android Gradle Plugin 8.9.2 and Gradle 8.11.1. It contains `gradle/wrapper/gradle-wrapper.properties` but **does not include wrapper JAR/scripts**; if Android Studio can't run the wrapper, select an installed Gradle 8.11.1 distribution or generate the wrapper using Gradle 8.11.1, e.g. `gradle wrapper --gradle-version 8.11.1`. Do not run these commands from the ESP-IDF directory.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Confirm `app/build/outputs/apk/debug/app-debug.apk` exists; Android Studio may offer **Locate**.
6. Transfer that APK to a compatible Android phone and install it (Android may ask you to allow this install source). Install only the APK *you built* and retain the source. This is a debug build, not a published production release.

## Option B — GitHub Actions cloud build

1. Create a private repository and upload the **contents** of this project folder to the repository root (`settings.gradle` must be in the root). No credentials or Wi-Fi password are required or should be committed.
2. Ensure the default branch is `main`, or manually run the workflow from GitHub Actions if supported on your branch.
3. Open **Actions > Build OpenTail Android debug APK > Run workflow**. The workflow sets up JDK 17, Android SDK 35 and Gradle 8.11.1 and invokes `:app:assembleDebug`.
4. If the job completes, find the **opentail-android-v0.1.0-debug-apk** artifact in that workflow run. Download and extract it; install its `app-debug.apk` on your Android phone.
5. If it fails, save the **first Gradle error** and share it for correction. This workflow is *prepared*, not verified to have run in this environment.

## Phone validation — run on bench only

1. Keep CORE v0.1.18 (or compatible version) powered by USB/bench supply. Your verified v0.1.17 hardware test is the rollback baseline.
2. Connect Android to Wi-Fi `OpenTail-CORE-Alpha` with your **existing password**, never hardcode or send it to me. If Android warns that Wi-Fi has no Internet, choose to remain connected.
3. Open OpenTail Android and tap **Connect CORE**. Success means `/api/v1/capabilities` was validated and firmware-hosted Studio `/studio` loads (v0.19.45 for CORE v0.1.18).
4. In Output Manager, check that GPIO16 retains its 522-pixel profile and GPIO17 retains the test-strip profile. **Read only** at first—avoid unnecessary saves.
5. Open Universal Trigger Manager and confirm its defaults load. Do not connect any 12V signal without the optocoupler interface.
6. Tap **Offline Studio** and confirm it displays local Studio. Offline drafts cannot directly configure the controller; use project export/import to transfer them.
7. Tap **Find BLE** and grant Nearby Devices. If CORE advertises, select `OpenTail CORE`, read its information, and check purple/teal status as appropriate. If no advertisement appears, log the result; absence does not prove the Android scanner is defective because CORE's NimBLE availability is hardware/build dependent.
8. BLE **lighting control is not implemented**. Do not expect a Bluetooth effects/trigger UI yet.

### Evidence to record

- Android phone model and Android version (non-identifying technical detail)
- Build success or exact **first** build error
- Wi-Fi Studio page load, API readback, offline editor, project export/import
- BLE advertisement found / not found, connection, information read, and status LED color

Known minor firmware issue to track: The BLE information characteristic in the supplied CORE v0.1.18 source still labels itself `0.1.17`. This is a firmware metadata string, not proof the firmware image is old. Do not alter or flash firmware just to address it.

The app is an early Android preview for bench testing. It is not safe to rely on as sole vehicle road-lighting control.
