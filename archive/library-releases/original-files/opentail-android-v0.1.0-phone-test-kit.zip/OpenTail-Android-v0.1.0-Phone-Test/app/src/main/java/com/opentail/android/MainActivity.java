package com.opentail.android;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native OpenTail Android shell. Wi-Fi controls use the device's unchanged Studio web app. */
public final class MainActivity extends Activity {
    private static final int PICK_PROJECT = 201;
    private static final int SAVE_PROJECT = 202;
    private static final String OFFLINE_URL = "https://appassets.androidplatform.net/assets/opentail.htm";
    private static final int MAX_EXPORT_CHARS = 2_000_000;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WebView web;
    private WebViewAssetLoader assets;
    private TextView connectionLabel;
    private TextView bleLabel;
    private ValueCallback<Uri[]> uploadCallback;
    private String pendingExport;
    private BleDiscovery ble;
    private boolean coreMode = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 19, 16));
        root.setPadding(dp(10), dp(8), dp(10), 0);

        TextView title = new TextView(this);
        title.setText("OPENTAIL  /  ANDROID  v0.1.0");
        title.setTextSize(17);
        title.setTextColor(Color.rgb(100, 227, 139));
        title.setTypeface(null, 1);
        root.addView(title);

        connectionLabel = label("Offline Studio · Device not connected");
        root.addView(connectionLabel);
        bleLabel = label("BLE · Not connected (read-only preview)");
        root.addView(bleLabel);

        LinearLayout row1 = row();
        addButton(row1, "Wi-Fi settings", this::openWifiSettings);
        addButton(row1, "Connect CORE", this::connectCore);
        root.addView(row1);

        LinearLayout row2 = row();
        addButton(row2, "Offline Studio", this::openOffline);
        addButton(row2, "Find BLE", () -> ble.scan());
        root.addView(row2);

        TextView warning = label("BENCH ONLY · Not a vehicle safety controller · BLE control pending");
        warning.setTextSize(11);
        warning.setTextColor(Color.rgb(201, 175, 112));
        root.addView(warning);

        assets = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12, 19, 16));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);  // Android document picker import.
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new ProjectExportBridge(), "OpenTailApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (OFFLINE_URL.equals(url.toString())) return assets.shouldInterceptRequest(url);
                if ("192.168.4.1".equals(url.getHost()) && "http".equals(url.getScheme())) return null;
                // No external scripts, sites, analytics or CDN assets are needed by Studio.
                return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (allowedPage(request.getUrl().toString())) return false;
                show("External navigation blocked. Only local OpenTail Studio and CORE are allowed.");
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (OFFLINE_URL.equals(url) && coreMode) {
                    coreMode = false;
                    CoreConnection.releaseWifi(MainActivity.this);
                    connectionLabel.setText("Offline Studio v0.19.45 · Local design only, no device sync");
                }
                if (allowedPage(url)) {
                    // Intercept Studio's project export to use Android's user-chosen document picker.
                    view.evaluateJavascript("window.download=function(name,text){window.OpenTailApp.exportJson(String(name),String(text));};", null);
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) connectionLabel.setText("Page unavailable · Check controller Wi-Fi and reconnect");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.setType("application/json");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, PICK_PROJECT);
                    return true;
                } catch (Exception ex) {
                    uploadCallback = null;
                    show("File picker unavailable: " + ex.getMessage());
                    return false;
                }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        ble = new BleDiscovery(this, message -> bleLabel.setText("BLE · " + message));
        openOffline();
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(12);
        v.setTextColor(Color.rgb(200, 211, 204));
        v.setPadding(0, dp(4), 0, dp(4));
        return v;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private void addButton(LinearLayout row, String title, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title);
        button.setTextSize(12);
        button.setTextColor(Color.rgb(229, 250, 233));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(26, 69, 43)));
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(48), 1);
        params.setMargins(dp(2), 0, dp(2), dp(2));
        row.addView(button, params);
    }

    private void openWifiSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_WIFI));
            else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception ex) { show("Open Android Wi-Fi settings and join OpenTail-CORE-Alpha"); }
    }

    private void connectCore() {
        connectionLabel.setText("Checking OpenTail CORE on 192.168.4.1…");
        io.execute(() -> {
            boolean bound = CoreConnection.bindToWifi(this);
            try {
                if (!bound) throw new Exception("Wi-Fi is not connected; join OpenTail-CORE-Alpha first");
                CoreConnection.verify();
                runOnUiThread(() -> {
                    coreMode = true;
                    connectionLabel.setText("CORE verified · Wi-Fi Studio · 192.168.4.1");
                    web.loadUrl(CoreConnection.STUDIO);
                });
            } catch (Exception ex) {
                CoreConnection.releaseWifi(this);
                runOnUiThread(() -> {
                    coreMode = false;
                    connectionLabel.setText("CORE not reachable · Check Wi-Fi settings");
                    show(ex.getMessage());
                });
            }
        });
    }

    private void openOffline() {
        coreMode = false;
        CoreConnection.releaseWifi(this);
        connectionLabel.setText("Offline Studio v0.19.45 · Local design only, no device sync");
        web.loadUrl(OFFLINE_URL);
    }

    private static boolean allowedPage(String url) {
        return OFFLINE_URL.equals(url)
                || CoreConnection.STUDIO.equals(url)
                || (CoreConnection.ORIGIN + "/").equals(url)
                || "about:blank".equals(url);
    }

    /** Export bridge is only enabled on the two allowlisted Studio origins. */
    private final class ProjectExportBridge {
        @JavascriptInterface public void exportJson(String proposedName, String json) {
            runOnUiThread(() -> {
                if (web == null || !allowedPage(web.getUrl())) return;
                if (json == null || json.length() > MAX_EXPORT_CHARS) {
                    show("Project too large to export");
                    return;
                }
                pendingExport = json;
                String safe = proposedName == null ? "opentail-project.json"
                        : proposedName.replaceAll("[^A-Za-z0-9_.-]", "_");
                if (!safe.endsWith(".json")) safe += ".json";
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.setType("application/json");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_TITLE, safe);
                try { startActivityForResult(intent, SAVE_PROJECT); }
                catch (Exception ex) { show("Save picker unavailable"); pendingExport = null; }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PROJECT) {
            ValueCallback<Uri[]> callback = uploadCallback;
            uploadCallback = null;
            if (callback != null) callback.onReceiveValue(resultCode == RESULT_OK && data != null && data.getData() != null
                    ? new Uri[]{data.getData()} : null);
        } else if (requestCode == SAVE_PROJECT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new Exception("Destination not writable");
                    out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    show("Project exported to your chosen location");
                } catch (Exception ex) { show("Export failed: " + ex.getMessage()); }
            }
            pendingExport = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (ble != null) ble.handlePermissions(requestCode, results);
    }

    @Override protected void onStop() {
        super.onStop();
        if (ble != null) ble.stopScan();
    }

    @Override protected void onDestroy() {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        if (ble != null) ble.shutdown();
        io.shutdownNow();
        CoreConnection.releaseWifi(this);
        if (web != null) { web.removeJavascriptInterface("OpenTailApp"); web.destroy(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void show(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private int dp(int px) { return Math.round(px * getResources().getDisplayMetrics().density); }
}
