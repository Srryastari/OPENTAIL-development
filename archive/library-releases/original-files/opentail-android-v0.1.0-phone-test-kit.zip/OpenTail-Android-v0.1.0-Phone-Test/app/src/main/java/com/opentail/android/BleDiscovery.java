package com.opentail.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** BLE discovery and read-only information; DOES NOT implement lighting/trigger commands. */
final class BleDiscovery {
    interface StatusListener { void onStatus(String message); }
    // ESP-IDF NimBLE BLE_UUID128_INIT uses little-endian byte order.
    private static final UUID SERVICE_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf21");
    private static final UUID INFO_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf22");
    private static final int REQUEST_NEARBY = 137;
    private static final long SCAN_DURATION_MS = 10000L;

    private final Activity activity;
    private final StatusListener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final ArrayList<String> labels = new ArrayList<>();
    private final ArrayAdapter<String> entries;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private AlertDialog scanDialog;
    private boolean scanning;
    private boolean stopped;

    BleDiscovery(Activity activity, StatusListener listener) {
        this.activity = activity;
        this.listener = listener;
        entries = new ArrayAdapter<>(activity, android.R.layout.simple_list_item_1, labels);
    }

    boolean handlePermissions(int requestCode, int[] results) {
        if (requestCode != REQUEST_NEARBY) return false;
        for (int status : results) {
            if (status != PackageManager.PERMISSION_GRANTED) {
                notifyStatus("Bluetooth permission denied; Wi-Fi Studio still works");
                return true;
            }
        }
        beginScan();
        return true;
    }

    void scan() {
        if (Build.VERSION.SDK_INT >= 31) {
            if (activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                    || activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[] {
                        Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
                }, REQUEST_NEARBY);
                return;
            }
        } else if (activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_NEARBY);
            return;
        }
        beginScan();
    }

    @SuppressWarnings("MissingPermission")
    private void beginScan() {
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Activity.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            notifyStatus("Bluetooth LE is unavailable on this phone");
            return;
        }
        if (!adapter.isEnabled()) {
            notifyStatus("Enable Bluetooth in Android settings, then scan again");
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            notifyStatus("Bluetooth LE scanner unavailable");
            return;
        }
        stopScan();
        found.clear();
        labels.clear();
        entries.notifyDataSetChanged();
        scanDialog = new AlertDialog.Builder(activity)
                .setTitle("Find OpenTail CORE")
                .setAdapter(entries, (dialog, position) -> {
                    String address = new ArrayList<>(found.keySet()).get(position);
                    stopScan();
                    BluetoothDevice device = found.get(address);
                    if (device != null) connectReadOnly(device);
                })
                .setNegativeButton("Close", (dialog, which) -> stopScan())
                .create();
        scanDialog.setOnDismissListener(dialog -> stopScan());
        scanDialog.show();
        try {
            scanning = true;
            scanner.startScan(scanCallback);
            notifyStatus("Scanning for OpenTail CORE (10 seconds)…");
            ui.postDelayed(() -> {
                if (!scanning) return;
                stopScan();
                notifyStatus(found.isEmpty() ? "No OpenTail BLE advertisement detected" : "Scan complete; tap OpenTail CORE to connect");
            }, SCAN_DURATION_MS);
        } catch (SecurityException | IllegalStateException ex) {
            stopScan();
            notifyStatus("BLE scan couldn't start: " + ex.getMessage());
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            final String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
            if (name == null || !name.startsWith("OpenTail CORE")) return;
            ui.post(() -> {
                String address = result.getDevice().getAddress();
                if (!found.containsKey(address)) {
                    found.put(address, result.getDevice());
                    labels.add(name + "  •  " + address);
                    entries.notifyDataSetChanged();
                }
            });
        }
        @Override public void onScanFailed(int errorCode) {
            ui.post(() -> { stopScan(); notifyStatus("BLE scan error " + errorCode); });
        }
    };

    @SuppressWarnings("MissingPermission")
    private void connectReadOnly(BluetoothDevice device) {
        if (Build.VERSION.SDK_INT >= 31
                && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            notifyStatus("Nearby-device permission required");
            return;
        }
        if (gatt != null) { gatt.close(); gatt = null; }
        notifyStatus("Connecting to OpenTail BLE (read-only)…");
        try { gatt = device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE); }
        catch (SecurityException ex) { notifyStatus("BLE connection permission denied"); }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @SuppressWarnings("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt connection, int status, int newState) {
            if (stopped) { connection.close(); return; }
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                notifyStatus("BLE connected · reading status…");
                connection.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                notifyStatus("BLE disconnected (GATT status " + status + ")");
                connection.close();
                if (gatt == connection) gatt = null;
            }
        }

        @SuppressWarnings("MissingPermission")
        @Override public void onServicesDiscovered(BluetoothGatt connection, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                notifyStatus("BLE service discovery failed: " + status);
                return;
            }
            BluetoothGattService service = connection.getService(SERVICE_UUID);
            BluetoothGattCharacteristic info = service == null ? null : service.getCharacteristic(INFO_UUID);
            if (info == null) {
                notifyStatus("BLE connected; no supported OpenTail info characteristic");
                return;
            }
            connection.readCharacteristic(info);
        }

        @Override public void onCharacteristicRead(BluetoothGatt connection, BluetoothGattCharacteristic characteristic,
                                                    byte[] value, int status) {
            if (INFO_UUID.equals(characteristic.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
                notifyStatus("BLE read-only · " + new String(value, StandardCharsets.UTF_8));
            } else {
                notifyStatus("BLE connected; information read failed: " + status);
            }
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicRead(BluetoothGatt connection, BluetoothGattCharacteristic characteristic,
                                                    int status) {
            if (Build.VERSION.SDK_INT < 33) {
                if (INFO_UUID.equals(characteristic.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
                    byte[] value = characteristic.getValue();
                    notifyStatus("BLE read-only · " + new String(value == null ? new byte[0] : value, StandardCharsets.UTF_8));
                } else notifyStatus("BLE connected; information read failed: " + status);
            }
        }
    };

    @SuppressWarnings("MissingPermission")
    void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCallback); }
        catch (SecurityException | IllegalStateException ignored) { }
    }

    @SuppressWarnings("MissingPermission")
    void shutdown() {
        stopped = true;
        stopScan();
        if (scanDialog != null) { scanDialog.dismiss(); scanDialog = null; }
        if (gatt != null) { gatt.disconnect(); gatt.close(); gatt = null; }
    }

    private void notifyStatus(String message) {
        ui.post(() -> {
            if (!stopped) listener.onStatus(message);
        });
    }
}
