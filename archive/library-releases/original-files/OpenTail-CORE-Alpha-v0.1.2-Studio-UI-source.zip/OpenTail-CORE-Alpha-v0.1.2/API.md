# OpenTail CORE Alpha HTTP API v1 — prototype only

This is **not WLED's `/json/state`** API. It is a small **local bench-only** REST interface to the ESP32-S3's own WPA2 Wi-Fi AP at `http://192.168.4.1`. All output changes are temporary, cannot disable real vehicle signals, and cap brightness in firmware. HTTPS/authenticated per-client sessions are not implemented. Do **not** expose this device to a vehicle network or the public internet.

| Method | Path | Action |
|---|---|---|
| GET | `/` | Basic onboard test UI |
| GET | `/studio` | Full OpenTail Studio v0.19.29 served from CORE AP (gzip) |
| GET | `/api/v1/status` | Firmware/inputs/effective signals/demo/frame count |
| GET | `/api/v1/capabilities` | Available functions, color order, feature flags |
| POST | `/api/v1/simulate` | Temporarily OR synthetic signals into the real input mask (max 10 s) |
| POST | `/api/v1/demo` | Temporary RGB solid/chase demo, physical/simulated triggers override |
| POST | `/api/v1/stop` | Clear simulation/demo immediately (does not bypass physical inputs) |

## Examples (PowerShell)

```powershell
Invoke-RestMethod http://192.168.4.1/api/v1/status
Invoke-RestMethod http://192.168.4.1/api/v1/capabilities

# Simulated left-turn input for 2 seconds
Invoke-RestMethod -Uri http://192.168.4.1/api/v1/simulate -Method Post -ContentType 'application/json' -Body '{"signals":["left"],"ttl_ms":2000}'

# Temporary low-brightness red test for 3 seconds
Invoke-RestMethod -Uri http://192.168.4.1/api/v1/demo -Method Post -ContentType 'application/json' -Body '{"mode":"solid","r":255,"g":0,"b":0,"brightness":20,"ttl_ms":3000}'

# Stop temporary tests
Invoke-RestMethod -Uri http://192.168.4.1/api/v1/stop -Method Post -ContentType 'application/json' -Body '{}'
```

## `GET /api/v1/status` example

```json
{
  "name": "OpenTail CORE Alpha",
  "version": "0.1.0-alpha",
  "bench_only": true,
  "hardware_failover": false,
  "mode": "30-pixel-bench",
  "input_mask": 0,
  "simulated_mask": 0,
  "effective_mask": 0,
  "demo_active": false,
  "frames": 160,
  "leds_per_chain": 30,
  "brightness_cap": 32
}
```

Bits 0..4 of the mask are `park, brake, left, right, reverse`. Bits 5..7 are unassigned spare inputs, exposed only for diagnostics. Don't send a `mask` integer: `/api/v1/simulate` validates signal names.

## Planned versioned schema

The final cross-platform OpenTail editor format should contain `schema_version`, `zones`, `triggers`, `effects`, `parameters`, `colors`, `palettes`, `sequences`, and `events`. This first firmware **does not yet parse or execute that schema**. Studio integration should use a dedicated CORE adapter in a subsequent release, not silently pretend it is WLED.
