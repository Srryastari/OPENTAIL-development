OpenTail Studio v0.17.2 — Stability fixes
Upload opentail.htm to WLED /edit, preferably under a unique name such as opentail-172.htm to avoid cached copies.
Do NOT upload the ZIP directly to WLED.

Changes:
- Archived zone assignments are preserved and visibly flagged; tests reject partial playback.
- Read-only WLED physical segment mapping diagnostic.
- Failed/unverified bench writes block further tests until recovery is confirmed.
- Controller- and geometry-checked saved baseline recovery.
- Project v3 backup includes sequences, hardware profile, and effect favorites.
- Builder retains a single Test Trigger button plus Stop Trigger / Stop All.

Tests: 19 base regressions + 17 extended regressions passed; JS syntax passed; mobile Chromium UI smoke passed.
Not tested against physical GLEDOPTO. Bench/show only, not a road-lighting safety controller.
