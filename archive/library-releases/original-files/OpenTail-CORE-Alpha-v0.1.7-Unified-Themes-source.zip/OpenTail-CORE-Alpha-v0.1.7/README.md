# OpenTail CORE Alpha v0.1.7 — ESP32-S3 bench firmware

**Status: SOURCE RELEASE — v0.1.7 has not yet been compiled or flashed. User confirmed v0.1.1 booted and served Studio. Not road-safe.**

A dedicated ESP-IDF firmware prototype for your hiBCTR ESP32-S3-WROOM-1-N16R8 (16 MB flash / 8 MB PSRAM) dev board, two 12V WS2815 data chains, and 8 isolated 3.3-V logic inputs. **Keep the production car lights on the OEM circuit while testing.** This firmware does **not** implement hardware failover, backup controller supervision, protected automotive power supply, guaranteed road-compliant output, or shutdown animations.

## What is actually implemented

- ESP32-S3 stand-alone firmware (ESP-IDF project; no WLED runtime)
- Two independent 800 kHz RMT channels, 5-V-shifted externally via Adafruit Pixel Shifter #6066 (DAT/D5 and CLK/C5).
- BRG byte order as established by your GS400 bench build; GPIO outputs stay at the ESP32's 3.3 V logic level until translated by the shifter.
- Eight configurable *wiring* inputs with 40 ms software debounce, normally interpreted as **active-low** at the GPIO, using internal pullups. Inputs 1–5 represent Park/Brake/Left/Right/Reverse, 6–8 reserved/unmapped.
- Simple, independent section logic on two sides with brake priority over parking within red sections; turn and reverse sections remain separate.
- Bench Wi-Fi access point (WPA2), status and capabilities REST endpoints, 10-second-maximum temporary effect demos and simulated trigger tests, plus embedded phone/desktop-friendly browser controls.
- One LED task exclusively owns pixel writes; physical inputs override all simulated/demo lighting.
- Cold boot clears LED outputs. Temporary demos expire and default to OFF.

**Not implemented:** Execution of WLED Studio effects and sequences on CORE firmware (the Studio UI connects through CORE Alpha v1 API but its WLED effects require an additional firmware engine), Bluetooth LE pairing, full WLED effects / palettes / sequences, custom palette storage, generic variable-size universal zone registry, trigger animation sweeps, ignition detection, automatic startup/shutdown, CAN, OTA, dual-board failover, watchdog/output selector, diagnostics log storage, automotive fault tolerance.

## Source structure

- `main/opentail_core.c` — network, HTTP, GPIO, RMT outputs and main loop
- `main/core_logic.c` / `core_logic.h` — pure-C layout, priority, color and input debounce logic
- `main/board_config.h` — provisional pins, small-strip profile, segment lengths, output brightness limit
- `main/Kconfig.projbuild` — compile-time WPA2 AP password (change it!)
- `main/idf_component.yml` — pinned Espressif `led_strip==3.0.3` dependency
- `tests/` — desktop GCC assertions, no attached hardware
- `API.md` — HTTP protocol and example commands

## Proposed GPIO assignments — verify against your physical dev-board silkscreen

| Signal | ESP32-S3 GPIO | Connection |
|---|---:|---|
| Left WS2815 data | 16 | Pixel Shifter **DAT** input; **D5** output to left **DI** |
| Right WS2815 data | 17 | Pixel Shifter **CLK** input; **C5** output to right **DI** |
| Input 1: Park | 4 | 3.3 V-safe **isolated module output** 1 |
| Input 2: Brake | 5 | isolated output 2 |
| Input 3: Left turn | 6 | isolated output 3 |
| Input 4: Right turn | 7 | isolated output 4 |
| Input 5: Reverse | 8 | isolated output 5 |
| Input 6: spare | 9 | isolated output 6 |
| Input 7: spare | 10 | isolated output 7 |
| Input 8: spare | 11 | isolated output 8 |
| GND | GND | Common LED power / shifter / ESP GND on the logic side |
| Shifter V | **3V3** | Connect to ESP **3V3**, *not* LED 12 V; board generates its own 5-V shifted output |
| WS2815 +12 V | — | Separately fused **12 V** LED supply; **not to ESP32 GPIO/VIN/3V3** |
| ESP32 power | USB-C | USB from a computer or suitable regulated USB supply during bench tests |

The Adafruit #6066 labels one shifter path as `CLK/C5` because it is intended for clocked LEDs. Electrically, it is an independent non-inverting shifter and can act as the second data path for independently clockless WS2815 chains. The inverted `!D5` output is **not used**. Do not equate D5/C5 with the WS2815 redundant **BI** backup pin; BI wiring depends on your specific strip connector/pad geometry and should be separately verified against its diagram.

**Optocoupler safety:** Do not connect 12 V to any ESP32 GPIO. Verify your exact optocoupler board's pin labels, isolated-side 3.3-V output level, output polarity and isolation arrangement with a meter before connection. If applying 12 V makes the isolated output go HIGH rather than LOW, change `OT_INPUT_ACTIVE_LOW` to `0` before rebuilding. Some modules need a pullup on the isolated side, or have common grounds that compromise isolation; inspect yours first.

## Default LED layout is deliberately small

The default is **30 pixels per chain (60 total)** and five 6-pixel sections per side (`Top → Turn → Reverse → Bottom → Trunk`); this is strictly for short detached test strips. Full GS400 example lengths are included in `board_config.h`, but **disabled** by default:

| Section | Left | Right |
|---|---:|---:|
| Top (park/brake) | 118 | 118 |
| Turn | 109 | 109 |
| Reverse | 42 | 42 |
| Bottom (park/brake) | 253 | 253 |
| Trunk (park/brake) | 101 | 101 |
| **Total** | **623** | **623** |

Set `OT_SMALL_BENCH_LAYOUT 0` for 623 LEDs per chain only **after** separate power and output timing validation. The default `OT_MAX_BRIGHTNESS 32` is **a pixel-channel cap**, *not* a PSU current limit. A 48 W 12 V power supply is only 4 A; it is not adequate by assumption for your 1,246-pixel array. Use a short test strip, appropriate fusing, power wiring and injection before expanding.

## Windows build and flash (requires ESP-IDF)

1. Install Espressif's official **ESP-IDF 5.5.x** development environment on Windows (ESP-IDF tools / ESP-IDF VS Code extension). Use the supplied ESP-IDF command prompt.
2. Extract this ZIP; in the ESP-IDF command prompt, `cd` into the `OpenTail-CORE-Alpha-v0.1.7` directory.
3. Run `idf.py set-target esp32s3`.
4. Run `idf.py menuconfig` → **OpenTail CORE Alpha** → **Wi-Fi AP password**. Change the demo password. Save, then exit.
5. Run `idf.py build`. Dependencies are downloaded by ESP-IDF component manager.
6. Plug a **data-capable** USB-C cable into the ESP32-S3 board. Find its COM port in Windows Device Manager.
7. Run `idf.py -p COM9 flash monitor` (replace `COM9` if your port has changed). If it does not enter the bootloader, hold BOOT, tap RESET, release BOOT, retry.
8. Connect your phone/PC to Wi-Fi `OpenTail-CORE-Alpha` using the password you configured. Open **http://192.168.4.1/**.
9. Start with **only the board powered by USB**. Verify `/api/v1/status`, then connect one correctly level-shifted short test strip, a fused 12 V supply and common GND. Use the temporary Red/Green/Blue test, checking against the intended BRG order. Connect the second chain only after first-chain success.
10. Connect isolated trigger channels **only after** testing their 3.3-V GPIO-side levels and polarity separately. Keep your vehicle OEM lamps intact and working.

If the build rejects memory-layout or flash settings, review `sdkconfig.defaults`, the ESP-IDF target and your actual module; don't force-flash a mismatched binary. `idf.py` builds a .bin **on your computer**, not in this ZIP. This package intentionally does not contain an unverified firmware binary.

## Host logic checks

On Linux/macOS with `cc`: `sh tests/run-host-tests.sh`

On Windows with GCC / MSYS2, the same script can be used from the MSYS2 shell. Host checks do **not** prove ESP-IDF compilation, board pin compatibility, LED signaling, electrically safe input isolation or in-car reliability.

## Current safe acceptance gate

1. ESP-IDF `idf.py build` completes successfully for `esp32s3`.
2. Board boots without crashes, phone connects to AP, `GET /api/v1/status` reports `bench_only:true`.
3. A short WS2815 strip cycles red/green/blue correctly on D5, then independently on C5.
4. With an isolated 3.3-V output, each input 1–5 produces its corresponding lighting on the correct section; Left/Right remain independent.
5. Removing the trigger signal returns only that function's lighting to OFF; Brake takes precedence over Park in shared red sections.
6. A demo is automatically cleared on timeout; a physical Brake input preempts it; POST Stop clears tests without disabling real inputs.
7. No sustained excessive heat, flicker, voltage sag or reset at tested load.

**Do not install on the road.** The final OpenTail requirement (hardware safety fallback / redundant controller / output selector / automotive-grade power conditioning) is not part of Alpha v0.1.7.

## References

- ESP-IDF GPIO restrictions: https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/peripherals/gpio.html
- Espressif led_strip component 3.0.3: https://components.espressif.com/components/espressif/led_strip/versions/3.0.3
- Adafruit #6066 pinout: https://learn.adafruit.com/adafruit-pixel-shifter/pinouts
- Espressif installation: https://docs.espressif.com/projects/esp-idf/en/v5.5.2/esp32s3/get-started/

## Studio-to-CORE bridge (new in 0.1.1)

- Studio v0.19.35 is compiled into firmware as a **gzip-compressed HTML page** served from `http://192.168.4.1/studio` when joined to the OpenTail-CORE-Alpha AP.
- `http://192.168.4.1/` remains the minimal firmware test console.
- Studio's Connect screen lets you choose **WLED** or **OpenTail CORE**. CORE mode connects to `/api/v1/capabilities` and `/api/v1/status`, then offers low-brightness temporary `/api/v1/demo` and `/api/v1/simulate` controls, `/api/v1/stop`, and live status refresh.
- Firmware v0.1.7 **does not** implement WLED's effect engine, arbitrary colors across sequences, native palettes, firmware-wide show modes, automatic startup/shutdown, or failover.
- Requests from a WLED-hosted page may fail when the iPhone/PC is connected to the separate CORE Wi-Fi; open `/studio` directly instead. No broad browser CORS exemption is configured.
- CORE Alpha boot uses the first RMT channel with DMA and the second without DMA. This mirrors the user's successfully flashed v0.1.0 hardware adjustment. Both physical outputs remain unverified.
- After flashing, check the serial log for `CORE 0.1.7-alpha` and visit the local `/studio` page. Firmware version has changed, but the CORE Alpha v1 HTTP protocol remains the same.

### Reusing your prior Wi-Fi configuration

If upgrading from an existing, locally built v0.1.0 project, copy its **private** `sdkconfig` file to the v0.1.7 root before the first build, using PowerShell. That retains your own configured AP password. Do **not** upload or distribute `sdkconfig` with your actual password.

```powershell
# Run from the v0.1.7 project directory; adjust old path if your directory differs
Copy-Item "..\OpenTail-CORE-Alpha-v0.1.0\OpenTail-CORE-Alpha-v0.1.0\sdkconfig" ".\sdkconfig"
idf.py build
idf.py -p COM9 flash monitor
```

If `idf.py set-target` resets your local configuration, use `idf.py menuconfig` and re-enter the AP password before building.
