OpenTail Studio v0.15.5 audited patch
Corrects final render override repaint, freeze snapshot, stale status updates and validates frame RGB byte lengths.
WebSocket Peek remains unverified on actual GLEDOPTO hardware. Exact means all configured RGB positions received, not physical sensor confirmation.
Upload opentail.htm via WLED /edit. Bench/show only.
