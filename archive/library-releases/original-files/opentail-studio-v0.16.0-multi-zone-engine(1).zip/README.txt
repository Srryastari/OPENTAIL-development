OpenTail Studio v0.16.0 — Multi-Zone Animation Engine

Install: Upload opentail.htm to your WLED /edit file manager, then visit /opentail.htm?v=160.

Changes:
- Per-section animation settings for every trigger, with independent effect/color/speed/intensity/brightness.
- Deterministic trigger priority: Show < Startup < Shutdown < Park < Lock < Unlock < Left Turn < Right Turn < Hazards < Brake < F1 Brake < Reverse.
- Priority conflicts shown in Builder; unrelated sections remain independently controlled.
- Restores pre-test segment state on Stop All; released sections restore their baseline while other triggers remain active.
- Rejects missing segments and unsupported effects instead of silently playing a different animation.
- Checks controller effect IDs after applying bench animations.

Limits:
- Browser-operated bench tests only; NOT suitable for safety-critical automotive signaling.
- Physical GLEDOPTO testing not performed. Controller must have exact WLED segments for each assigned section.
- The Trunk section requires its own WLED segment (522–623) before it can run independently.
- Trigger test activation may persist until manually stopped or browser closes; physical WLED may keep last lighting state.
- Exact live RGB depends on WLED Peek support and frame completeness.
- Segment brightness support varies by firmware.
