# OpenTail Android v0.1.1 — native refinement

**Source project, not a tested APK.** v0.1.0 was successfully built, installed, and tested on the user's Android phone for Wi-Fi Studio and read-only BLE connectivity. **This new v0.1.1 revision has NOT yet been compiled in Android Studio or tested on a device.**

## Changes

- Native haptics enabled by default at light strength. Taps, toggles and optional slider release use Android vibration; verified CORE saves or failed saves provide distinct feedback. The verified-save haptic requires the Studio UI to explicitly report successful device readback; no vibration is emitted merely because the user pressed Save.
- Settings button adds On/Off, Light/Medium/Strong and slider haptic preferences. Android `VIBRATE` permission added.
- Remembers a chosen BLE device **after discovering the existing OpenTail GATT info characteristic**, and performs one bounded scan to reconnect it. Permission failures and unavailable advertising do not interrupt Wi-Fi Studio. BLE remains **read-only**.
- When the user returns to the app, re-checks the CORE capabilities on the current Wi-Fi connection and reloads the page if a previous page load failed. It does not silently join a different Wi-Fi network or override an explicit Offline selection.
- Bundles unchanged OpenTail Studio functionality with version `0.19.46`, matching the companion firmware release (Studio UI version-only bump).

## Existing functionality preserved

- Native app opens; Connect CORE uses the actual `/api/v1/capabilities` handshake on `192.168.4.1`, then loads CORE-served Studio on `/studio`.
- Offline Studio and project import/export remain available.
- Read-only BLE scanning and GATT info reading remain available; no Bluetooth lighting commands are claimed.
- Original GPIO16/GPIO17 output settings, physical trigger inputs and CORE firmware NVS are not modified by an Android APK update.

## Build/install

1. Extract `opentail-android-v0.1.1-source.zip` under your Desktop\OpenTail folder and open the `OpenTail-Android-v0.1.1` folder in Android Studio.
2. In **File → Settings → Build Tools → Gradle**, use **JDK 17** (not JVM 27). Project requires Gradle 8.11.1, AGP 8.9.2 and Android SDK 35.
3. Run **Build → Generate APK(s)** or Gradle task `:app:assembleDebug`. On success look for `app\build\outputs\apk\debug\app-debug.apk` inside the new project folder.
4. Install the APK over the previous app from the same debug signing key to retain app data. If Android reports a signing mismatch, do not uninstall until project/export backups are secured.
5. First release test: connect CORE over Wi-Fi, open Output Manager without changing settings, open Settings and tap a button, set haptic level, manually connect the preferred BLE device once (the v0.1.0 app did not save this preference), then return to the app to test reconnection.

**Limits**: auto reconnect can only use the CORE Wi-Fi if Android is already joined to that network. BLE devices using rotating addresses or not advertising may require manual scanning. Haptic strength depends on phone vibration motor. The app remains bench-only; not for automotive safety operation.

## QA

Run `python qa/check_release.py` with Python 3, Node.js and Java/JDK 17 available. Regression results are source/static/host tests, not an APK build. Previously verified v0.1.0 behavior remains a hardware baseline, but v0.1.1 needs device confirmation.

**No Gradle-wrapper JAR or executable is included**; open through Android Studio as you did for v0.1.0, or use an installed Gradle distribution.
