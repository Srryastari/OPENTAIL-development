# v0.1.1

- Added native Android haptic engine with user settings (light default; slider feedback opt-in).
- Added haptic events to allowlisted Studio pages with readback-gated Save confirmation.
- Added Wi-Fi session recovery on app resume, without automatic joining or changes to CORE AP credentials.
- Added remembered preferred BLE address, bounded BLE scan and reconnection without write permissions.
- Preserved native Studio, offline project work, JSON import/export and read-only BLE.
- Bundled Studio v0.19.46; no LED effect/trigger command changes.

Host QA: 24/24 static checks passed. Android SDK compilation and new-revision phone tests pending.
