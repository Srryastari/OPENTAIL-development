#!/usr/bin/env python3
"""Offline static checks only. Not a substitute for Android SDK compilation or BLE hardware tests."""
from pathlib import Path
import hashlib
import subprocess
import xml.etree.ElementTree as ET
import re
import sys
import tempfile
from html.parser import HTMLParser

root = Path(__file__).resolve().parents[1]
main = root / 'app/src/main'
read = lambda rel: (root / rel).read_text(encoding='utf-8')
passes = 0

def check(name, condition):
    global passes
    if not condition:
        print(f'FAIL: {name}')
        raise SystemExit(1)
    passes += 1
    print(f'PASS: {name}')

studio = (main / 'assets/opentail.htm').read_bytes()
main_java = read('app/src/main/java/com/opentail/android/MainActivity.java')
core_java = read('app/src/main/java/com/opentail/android/CoreConnection.java')
ble_java = read('app/src/main/java/com/opentail/android/BleDiscovery.java')
xml_path = 'app/src/main/AndroidManifest.xml'
manifest = ET.parse(root / xml_path).getroot()
net = ET.parse(main / 'res/xml/network_security_config.xml').getroot()
ET.parse(main / 'res/drawable/ic_opentail.xml')
ET.parse(main / 'res/values/strings.xml')
ET.parse(main / 'res/values/styles.xml')

check('Android XML parses correctly', manifest.tag == 'manifest')
check('Studio v0.19.46 bundled, pinned checksum', hashlib.sha256(studio).hexdigest() == read('qa/studio-sha256.txt').strip())
check('CORE endpoint fixed to known AP', 'http://192.168.4.1' in core_java and '/api/v1/capabilities' in core_java)
check('CORE protocol validated before opening web controls', 'opentail-core-alpha-v1' in core_java and 'CoreConnection.verify()' in main_java)
check('Untrusted URLs blocked', 'shouldOverrideUrlLoading' in main_java and 'External navigation blocked' in main_java)
check('Offline Studio asset loader, with safe file defaults', 'WebViewAssetLoader' in main_java and 'setAllowFileAccess(false)' in main_java and 'setAllowUniversalAccessFromFileURLs(false)' in main_java)
check('Android JSON import/export uses system document pickers', 'ACTION_CREATE_DOCUMENT' in main_java and 'ACTION_OPEN_DOCUMENT' in main_java)
check('BLE service/characteristic UUIDs consistent with firmware', '55a56022-4915-7a92-cf44-b8b7102eaf21' in ble_java and '55a56022-4915-7a92-cf44-b8b7102eaf22' in ble_java)
check('BLE read-only, no characteristic write operations', 'readCharacteristic(info)' in ble_java and '.writeCharacteristic(' not in ble_java)
check('Android 12+ BLE permissions included', all(f'android.permission.{p}' in read(xml_path) for p in ('BLUETOOTH_SCAN','BLUETOOTH_CONNECT')))
check('Only CORE AP HTTP exception', len(net.findall('./domain-config/domain')) == 1 and net.findtext('./domain-config/domain') == '192.168.4.1' and net.find('./base-config').attrib.get('cleartextTrafficPermitted') == 'false')
check('Release/build versions pinned', all(v in read('app/build.gradle') for v in ('compileSdk 35','minSdk 26','targetSdk 35','versionName \'0.1.1\'')) and 'gradle-8.11.1-bin.zip' in read('gradle/wrapper/gradle-wrapper.properties'))
check('Bundled Studio output & trigger editors retained', b'Universal Output Manager' in studio and b'Universal Trigger Manager' in studio)
check('BLE bench-only limitation explicitly documented', 'read-only' in ble_java and 'not a tested apk' in read('README.md').lower())
# Android v0.1.1 feature regressions: these are structural/source checks, not physical assertions.
haptic_java = read('app/src/main/java/com/opentail/android/HapticController.java')
check('Native haptics use user preferences and Android vibration API',
      all(token in haptic_java for token in ('haptics_enabled','haptics_strength','haptics_slider','VibrationEffect','SharedPreferences')))
check('Haptic permission declared', 'android.permission.VIBRATE' in read(xml_path))
check('WebView tap bridge is restricted to allowlisted pages',
      'STUDIO_HAPTIC_JS' in main_java and 'allowedPage(web.getUrl())' in main_java and 'OpenTailHaptics' in main_java)
check('No haptic success before verified CORE save response',
      'Saved to CORE and verified by device readback.' in main_java and 'Saved and verified by CORE readback.' in main_java)
check('Auto Wi-Fi reconnect requires verified CORE capabilities',
      'onResume()' in main_java and 'connectCore(true)' in main_java and 'CoreConnection.verify()' in main_java)
check('Preferred BLE address stored only after validating expected OpenTail service',
      'preferred_ble_address' in main_java and 'getService(SERVICE_UUID)' in ble_java and 'getCharacteristic(INFO_UUID)' in ble_java and
      ble_java.index('getCharacteristic(INFO_UUID)') < ble_java.index('preferredListener.accept'))
check('BLE reconnection is a bounded scan without writes or repeated reconnect timers',
      'RECONNECT_DELAY_MS' in ble_java and 'beginScan(true)' in ble_java and '.writeCharacteristic(' not in ble_java)

# Decode the injected Java string and syntax-check the exact JavaScript shipped in MainActivity.
import json
m = re.search(r'private static final String STUDIO_HAPTIC_JS = (.*?);\n', main_java, re.S)
if m is None: raise SystemExit('FAIL: Embedded haptic JavaScript not found')
parts = re.findall(r'"(?:[^"\\]|\\.)*"', m.group(1))
injected_js = ''.join(json.loads(part) for part in parts)
js_syntax = subprocess.run(['node','--check'],input=injected_js, text=True,capture_output=True)
check('Native haptics injected JavaScript parses', js_syntax.returncode == 0)


class Scripts(HTMLParser):
    def __init__(self): super().__init__(); self.in_script = False; self.scripts = []; self.buf = []
    def handle_starttag(self, tag, attrs):
        if tag == 'script': self.in_script = True; self.buf = []
    def handle_data(self, data):
        if self.in_script: self.buf.append(data)
    def handle_endtag(self, tag):
        if tag == 'script' and self.in_script:
            self.scripts.append(''.join(self.buf)); self.in_script = False

parser = Scripts(); parser.feed(studio.decode('utf-8'))
for idx, js in enumerate(parser.scripts):
    result = subprocess.run(['node','--check'], input=js, text=True, capture_output=True)
    if result.returncode:
        print(f'FAIL: Studio inline script {idx}: {result.stderr[:500]}')
        sys.exit(1)
check('All bundled Studio inline JavaScript parses', len(parser.scripts) > 0)
with tempfile.TemporaryDirectory() as output_dir:
    runner = root / 'qa/ParseJava.java'
    javac = subprocess.run(['javac', '-d', output_dir, str(runner)], capture_output=True, text=True)
    if javac.returncode:
        print(javac.stderr[:800]); raise SystemExit(1)
    sources = list((main / 'java').rglob('*.java'))
    java_result = subprocess.run(['java', '-cp', output_dir, 'ParseJava', *map(str,sources)], capture_output=True, text=True)
    if java_result.returncode: print(java_result.stderr[:1000]); raise SystemExit(1)
    check('All Android Java sources parse (syntax only)', len(sources) >= 3)
print(f'\n{passes}/{passes} static checks passed. Android SDK compile/device/BLE tests NOT run.')
