# v0.1.1 physical acceptance checklist (not yet performed)

1. Build debug APK (`:app:assembleDebug`), install over existing v0.1.0 and launch.
2. Open Settings: disable haptics -> no vibration; enable -> Light, then Medium/Strong; confirm slider feedback only on release when enabled.
3. Open CORE Wi-Fi Studio: button and toggle taps vibrate once; modify an **unused bench-only** zone draft (do not change road lighting), ensure failed save does not signal success; restore draft, confirm saved indicator only follows CORE readback. Do not manipulate active physical triggers.
4. Force close app, relaunch while Android remains connected to OpenTail-CORE-Alpha: previously used Wi-Fi Studio reconnects automatically.
5. Open Offline Studio deliberately; confirm it stays offline on resume and never claims device save.
6. First time in v0.1.1: tap Find BLE, select OpenTail CORE, verify read-only info. Leave and resume: preferred BLE device reconnects when advertising; Wi-Fi UI remains working if BLE missing.
7. Confirm amber, green, purple, teal and Show Mode rainbow status behavior remains under existing firmware; color tuning is a **separate firmware package** and needs physical evaluation.
8. No BLE write or lighting control should be possible through the native BLE screen.

**Do not mark these passed based on static checks alone.**
