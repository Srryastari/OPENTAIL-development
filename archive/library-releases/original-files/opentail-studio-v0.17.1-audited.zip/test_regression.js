'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/opentail.htm','utf8');
const js=html.split('<script>')[1].split('</script>')[0];
const saved=new Map();
const orig={on:true,bri:143,seg:[[0,118],[118,227],[227,269],[269,522],[522,623]].map(([start,stop],id)=>({id,start,stop,on:true,bri:148,fx:0,sx:100,ix:99,pal:0,col:[[80,80,80],[0,0,0]],frz:false}))};
let live=structuredClone(orig);let sent=[];let forcedFail=false;
const effects=['Solid','Strobe','Chase','Rainbow','Breathe','Color Wipe'];
function response(value,status=200){return {ok:status>=200&&status<300,status,async json(){return structuredClone(value)},clone(){return response(value,status)}}}
async function mockFetch(u,opts={}){
 const path=String(u).replace(/^https?:\/\/[^/]+/,'');
 if(opts.method==='POST'&&path==='/json/state'){
  if(forcedFail)throw Error('simulated transport failure');
  const p=JSON.parse(opts.body);sent.push(p);if('on'in p)live.on=p.on;if('bri'in p)live.bri=p.bri;
  for(const update of p.seg||[]){const seg=live.seg.find(s=>s.id===update.id);if(!seg)continue;for(const [k,v] of Object.entries(update)){if(k!=='id')seg[k]=structuredClone(v)}}
  return response({success:true});
 }
 if(path==='/json/state')return response(live);
 if(path==='/json')return response({info:{leds:{count:623,maxseg:16}},state:live});
 if(path==='/json/eff')return response(effects);
 if(path==='/json/pal')return response(['Default']);
 if(path==='/json/fxdata')return response([]);
 return response({},404)
}
const document={hidden:false,body:{appendChild(){}},getElementById(id){if(id==='app')return this.app;return null},querySelectorAll(){return []},addEventListener(){},app:{innerHTML:''},createElement(){return {style:{},setAttribute(){},click(){},remove(){}}}};
const storage={getItem(k){return saved.has(k)?saved.get(k):null},setItem(k,v){saved.set(k,v)},removeItem(k){saved.delete(k)}};
const location={protocol:'http:',hostname:'127.0.0.1',origin:'http://127.0.0.1:8899',pathname:'/opentail-171.htm',href:'http://127.0.0.1:8899/opentail-171.htm'};
const context={window:{fetch:mockFetch,addEventListener(){}},fetch:mockFetch,document,localStorage:storage,location,console,structuredClone,JSON,URL,Blob,Math,Date,Number,String,Set,Map,Promise,performance:{now:()=>0},navigator:{userAgent:'test'},AbortSignal:{timeout:()=>null},setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},alert(){},confirm:()=>true,WebSocket:class{}};
context.window.window=context.window;vm.createContext(context);
// Legacy v0.16.8 layout with a custom animation/pixel paint saved.
const oldLayout=[['topL','Top · Left',0,118],['turnL','Turn · Left',118,109],['reverseL','Reverse · Left',227,42],['bottomL','Bottom · Left',269,253],['trunkL','Trunk · Left',522,101]].map(([id,name,start,length])=>({id,name,start,length,kind:'strip'}));
const f1={name:'F1 Brake',kind:'automotive',pattern:'strobe',color:'#ff0000',secondary:'#000000',brightness:80,speed:60,intensity:70,zones:['topL','bottomL'],sectionAnimations:{topL:{pattern:'strobe',color:'#ff0000',secondary:'#000000'},bottomL:{pattern:'chase',color:'#0000ff',secondary:'#000000'}}};
const profiles={Show:{name:'Show',zones:['topL'],pattern:'solid'},Brake:{name:'Brake',zones:['topL','bottomL','trunkL'],pattern:'solid',color:'#ff0000',secondary:'#000000',brightness:80,speed:60,intensity:70},'F1 Brake':f1};
saved.set('opentail-v1',JSON.stringify({layout:oldLayout,profiles,selectedPixels:{topL:{0:'#ffffff'}},sectionStyles:{bottomL:{color:'#ff00ff'}}}));
vm.runInContext(js,context);
async function run(){
 let n=0;const ok=msg=>{n++;console.log('PASS',msg)};
 let s=vm.runInContext('state',context);
 assert.equal(s.zoneRegistryVersion,1);assert.equal(s.layout.length,5);assert(s.layout.every(z=>z.id.startsWith('zone_')));
 assert(s.profiles['F1 Brake'].zones.every(id=>s.layout.some(z=>z.id===id)));
 assert.equal(s.profiles['F1 Brake'].sectionAnimations[s.layout[0].id].pattern,'strobe');
 assert.equal(s.profiles['F1 Brake'].sectionAnimations[s.layout[3].id].color,'#0000ff');
 assert.equal(s.selectedPixels[s.layout[0].id][0],'#ffffff');
 assert.equal(s.sectionStyles[s.layout[3].id].color,'#ff00ff');ok('Legacy zone IDs, animations, paints and styles migrate');
 const ids=s.layout.map(z=>z.id);vm.runInContext('otMigrateZoneRegistry()',context);
 assert.deepStrictEqual(s.layout.map(z=>z.id),ids);ok('Migration is idempotent');
 const ui=vm.runInContext('builder()',context);
 assert.equal((ui.match(/>Test Trigger<\/button>/g)||[]).length,1);
 assert.equal((ui.match(/>Stop Trigger<\/button>/g)||[]).length,1);
 assert(!ui.includes('Test assigned sections'));ok('Builder has a single Test Trigger and Stop Trigger');
 s.connected=false;
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),false);
 assert.strictEqual(s.benchSignals['F1 Brake'],undefined);ok('Disconnected testing cannot set ACTIVE');
 s.connected=true;s.wledEffects=effects.slice();s.wledInfo={leds:{count:623,maxseg:16}};
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),true);
 assert.equal(live.seg[0].fx,1);assert.equal(live.seg[3].fx,2);assert.deepStrictEqual(live.seg[0].col[0],[255,0,0]);assert.deepStrictEqual(live.seg[3].col[0],[0,0,255]);
 assert.equal(live.seg[1].fx,0);assert.equal(live.seg[2].fx,0);assert.equal(live.seg[4].fx,0);
 assert.equal(s.triggerOwners[0].zoneId,s.layout[0].id);ok('F1 Brake: 2 independent animations, no unrelated segment changes');
 assert.strictEqual(await vm.runInContext("otStopSelectedTrigger('F1 Brake')",context),true);
 assert.deepStrictEqual(live,orig);assert(!s.benchSignals['F1 Brake']);ok('Stopping F1 restores original WLED state confirmed by readback');
 assert.strictEqual(await vm.runInContext("testTrigger('Brake')",context),true);
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),true);
 assert.equal(s.triggerOwners.find(x=>x.zoneId===s.layout[0].id).trigger,'F1 Brake');
 assert.strictEqual(await vm.runInContext("otStopSelectedTrigger('F1 Brake')",context),true);
 assert.equal(live.seg[0].fx,0);assert.equal(live.seg[4].fx,0);assert(s.benchSignals.Brake);
 assert.strictEqual(await vm.runInContext('stopTrigger()',context),true);assert.deepStrictEqual(live,orig);ok('Brake/F1 priority, selective stop and Stop All restore');
 // Verify after rename, owner lookup still uses zone identity.
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),true);
 const topId=s.layout[0].id;
 s.layout[0].name='Renamed Top';
 assert.strictEqual(await vm.runInContext("otStopSelectedTrigger('F1 Brake')",context),true);assert.deepStrictEqual(live,orig);assert.equal(s.layout[0].id,topId);ok('Section rename does not break trigger ownership or baseline restore');
 // Fail safe if a physical segment is absent: none sent, no ACTIVE flag.
 live.seg=live.seg.filter(x=>x.id!==3);sent=[];
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),false);assert.equal(sent.length,0);assert(!s.benchSignals['F1 Brake']);assert(s.status.includes('Cannot test all'));
 ok('Missing WLED segment prevents partial trigger application');
 live=structuredClone(orig);sent=[];forcedFail=true;
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),false);assert(s.benchSignals['F1 Brake']);assert(s.status.includes('may still be active'));forcedFail=false;
 assert.strictEqual(await vm.runInContext('stopTrigger()',context),true);
 ok('Transport failure warns of unverified physical state, Stop All restores');
 // Import same physical WLED segments should preserve IDs, styles and animations.
 const oldTop=s.layout[0].id,oldBottom=s.layout[3].id;
 await vm.runInContext('importLiveSegments()',context);
 assert.equal(s.layout.find(z=>z.start===0).id,oldTop);assert.equal(s.layout.find(z=>z.start===269).id,oldBottom);
 assert.equal(s.profiles['F1 Brake'].sectionAnimations[oldBottom].color,'#0000ff');ok('WLED segment import preserves stable IDs and effects by pixel range');
 s.colorTab='cs';s.wledEdit={color:'#ffffff',tertiary:'#ffffff'};
 vm.runInContext("setChannelColor('#123456')",context);
 assert.equal(s.wledEdit.tertiary,'#123456');assert.equal(s.wledEdit.color,'#ffffff');ok('Third color slot does not overwrite FX color');
 const generated=vm.runInContext('otNewZoneId()',context);assert(!s.layout.some(z=>z.id===generated));ok('New zone IDs are independent of vehicle naming');
 const exported=vm.runInContext('({version:2,profiles:state.profiles,layout:state.layout,removedSections:state.removedSections,selectedPixels:state.selectedPixels,sectionStyles:state.sectionStyles,zoneAliases:state.zoneAliases,zoneRegistryVersion:state.zoneRegistryVersion})',context);
 assert.equal(exported.version,2);assert(exported.sectionStyles);assert(exported.zoneAliases);ok('Project v2 includes registry and section styles');
 // Validate every main workspace renders without throwing.
 for(const [tab,label] of [['home','System Overview'],['device','Controller Connection'],['scenes','Connected WLED Effects'],['builder','Trigger Builder'],['layout','Universal Zone Registry'],['diagnostics','Diagnostics']]){
  vm.runInContext(`go('${tab}')`,context);assert(document.app.innerHTML.includes(label),tab+' render');
 }
 ok('All six top-level workspaces render with the migrated registry');
 // Version-1 files remain importable; migrated data keeps per-zone custom animations.
 await vm.runInContext('importProject',context)({text:async()=>JSON.stringify({version:1,layout:oldLayout,profiles,selectedPixels:{topL:{0:'#ffffff'}}})});
 assert(s.layout.every(z=>z.id.startsWith('zone_')));
 assert.equal(s.profiles['F1 Brake'].sectionAnimations[s.layout.find(z=>z.start===269).id].color,'#0000ff');
 ok('Legacy v1 project import upgrades section references');
 // Controller mutations never occur when importing WLED segment definitions.
 sent=[];await vm.runInContext('importLiveSegments()',context);assert.equal(sent.length,0);
 ok('Import WLED segments is read-only on physical controller');
 // A failed stop retains its baseline so the user can retry safely.
 assert.strictEqual(await vm.runInContext("testTrigger('F1 Brake')",context),true);
 forcedFail=true;assert.strictEqual(await vm.runInContext("otStopSelectedTrigger('F1 Brake')",context),false);
 assert(vm.runInContext('benchBefore!==null',context));forcedFail=false;
 assert.strictEqual(await vm.runInContext('stopTrigger()',context),true);assert.deepStrictEqual(live,orig);
 ok('Failed baseline restoration can be retried and verified');
 assert(html.includes('<title>OpenTail Studio v0.17.1</title>'));assert(html.includes("const OT_VERSION='0.17.1'"));assert(!html.includes('v0.17.0'));ok('Visible version references are consistent');
 console.log('\n'+n+' software regression tests passed');
}
run().catch(e=>{console.error('FAILED:',e.stack||e);process.exitCode=1});
