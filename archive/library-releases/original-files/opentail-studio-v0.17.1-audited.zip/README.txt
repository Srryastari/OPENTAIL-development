OpenTail Studio v0.17.1 — Stability / trigger audit
=================================================

INSTALLATION
1. Back up your existing OpenTail project from the app first.
2. Connect to your GLEDOPTO WLED access point.
3. In WLED /edit, upload ONLY opentail-171.htm, not the ZIP archive.
4. Open http://4.3.2.1/opentail-171.htm in your browser.
5. Use Connect if needed. Do not delete the old file until this build is tested.

FIXES
- Builder: one Test Trigger, one Stop Trigger, plus separate Stop All.
- Legacy section IDs, saved per-section animations, pixel paints and styles migrate together.
- WLED segment import preserves stable IDs when exact pixel ranges match.
- F1 Brake and other trigger plans reject missing/unavailable sections before sending a partial test.
- WLED readback verifies segment effects, colors, brightness, speed and intensity.
- Stop restoration confirms on/off, global brightness and prior segment settings.
- Trigger ownership uses zone IDs/physical segment IDs rather than display names.
- Live Arrangement length edits are local until explicit Sync (avoids unintentional color/effect resets).
- Third WLED color slot now edits tertiary color rather than overriding primary Fx color.
- Project v2 exports include universal-zone alias data and saved section styles; legacy v1 imports remain supported.
- Removed superseded duplicate function definitions that obscured the executed code.

SCOPE AND LIMITATIONS
This is a WLED bench/show application, not a road-safe lighting controller.
12V vehicle harness inputs, fail-safe hardware, CAN, hardware Output Manager and custom sequences
are not fully implemented on the existing GLEDOPTO in this release.
Hardware playback, real iPhone/Safari interaction and live WLED color-order behavior have NOT been verified.
19 automated mock-controller regression checks passed; syntax and ZIP checks passed.

VALIDATION TARGET
With WLED segments 0-117 (Top) and 269-521 (Bottom), set F1 Brake Top = Strobe red,
Bottom = Chase blue. Tap Test Trigger, verify each section, then Stop Trigger.
Original scene restoration should be confirmed by Diagnostics and on the actual lights.
