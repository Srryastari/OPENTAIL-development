# OpenTail Studio v0.9 — live control repair

Upload `opentail.htm` to the WLED file manager at `/edit`. Open `http://YOUR-WLED-IP/opentail.htm?v=9`. If updating from v0.8, first back up your WLED settings/presets.

## What changed
- Larger arrangement slider, +/- stepper, live number entry, chained offsets. Slider edits are queued with ~95 ms debounce to WLED.
- Scene selection and scene-library buttons send a scene to the controller. Unknown custom patterns fall back to solid instead of pretending to run a custom renderer.
- Builder color/speed/intensity changes send live scene updates without continuously redrawing the document.
- WLED effect speed, intensity, palette, brightness, colors, three custom sliders and three options are available. Stock WLED effects may ignore controls not supported by each effect.
- Bench trigger buttons apply color to matching configured WLED segments, with whole-output fallback if no matching arrangement was found. Bench mode does NOT implement real turn flashing, F1 strobe, signal priority, startup or shutdown sequences.
- Section controls send commands even when app sync flag is false; require exact real segment boundaries. Color order selection in arrangement is metadata only: change actual color order in WLED LED Preferences.

## Known limits
Custom patterns/frames are not rendered by stock WLED. The preview maps only some pattern names to stock effects. Live API requests take network time and cannot guarantee visually instantaneous frame-accurate updates. GLEDOPTO is not accessible in this test environment, so physical behavior must be validated with the attached checklist. Save controller presets before editing physical WLED segments.

## Bench checklist
1. Connect and use Immediate All RED from Connect (independent of arrangements).
2. In Arrangement, verify numeric count, +/- and slider, watching live response.
3. Import current segments, then ON/OFF a matching section.
4. Home: choose Scene Show then Brake, check physical output.
5. Animations: choose WLED effect and edit speed, intensity, palette, color.
6. Builder: change primary color, choose zone and paint an LED.
7. Bench: enable Brake and Clear, verify prior scene restoration.
