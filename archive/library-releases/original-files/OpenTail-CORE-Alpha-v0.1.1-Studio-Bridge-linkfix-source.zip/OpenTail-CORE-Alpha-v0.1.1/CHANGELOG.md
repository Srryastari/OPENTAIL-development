# OpenTail CORE Alpha Changelog

## v0.1.1 — Studio bridge (source release)
- Embed OpenTail Studio v0.19.29 as gzip HTML on GET `/studio`, retaining the previous minimal homepage on `/`.
- Add Studio CORE API adapter; same-origin capability discovery, status, temporary demos/input tests, stop, automatic refresh.
- Use DMA for first LED channel, standard RMT for second, reflecting the successful v0.1.0 user hardware fix.
- Preserve previous 8-input / 2-output / bench-only firmware API and all existing safety limitations.
- NOT yet ESP-IDF compiled or hardware flashed/tested; source/static/host tests only.

## v0.1.0 — Initial source release
- Two WS2815 LED outputs; simulated/physical vehicle inputs; temporary demo HTTP API and stand-alone AP test page.
- First Windows ESP-IDF build and real ESP32-S3 boot confirmed by user; the initial DMA allocation caused a reboot loop until adjusted.
