OpenTail Studio v0.15.4
Upload opentail.htm to WLED /edit.
Live pixel feedback uses WLED WebSocket /ws with {"lv":true}; no LED state changes.
Exact status requires a full undownsampled frame.
If the controller does not support Peek, no exact preview is claimed.
Bench testing only.
