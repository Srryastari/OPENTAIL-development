# OpenTail Android v0.1.13 — Connection Status Integrity

Android-only UI/connection-state correction; compatible with existing CORE v0.1.24 (no firmware changes needed).

- Header badge now identifies **BLE authorized**, **BLE connected**, **Wi-Fi connected**, **connecting/scanning**, **Bluetooth off**, or **Disconnected** rather than an ambiguous green Connected label.
- Bluetooth adapter OFF broadcast immediately clears stale GATT/authorization/config transfer state; ongoing updates also use live adapter state.
- Wi-Fi header status requires a currently present Wi-Fi transport in addition to the previously verified CORE page. Bluetooth being off does not imply Wi-Fi is off.
- Layout BLE Output Manager exposes radio, connection, authorization, and progress feedback without scrolling to the bottom.
- Existing BLE writes, saved outputs, Wi-Fi Studio, and bundled Studio HTML remain unchanged.
- No native APK or phone/BLE electrical tests were performed here. Android SDK compilation and device verification pending.

## Test on phone
1. Start in BLE authorized state and confirm header explicitly says BLE authorized.
2. Turn Android Bluetooth OFF, leaving Wi-Fi off: header must say Bluetooth off in neutral gray; Layout must say Bluetooth off and Disconnected.
3. Turn Bluetooth ON, reconnect, authorize; verify badge updates and output readback works.
4. Repeat with CORE Wi-Fi connected: when BLE turns off, header must say **Wi-Fi connected** (not BLE connected). Disconnect CORE Wi-Fi too and confirm neutral offline.
5. Save GPIO17 and verify GPIO16 is unchanged and saved values survive restart.
