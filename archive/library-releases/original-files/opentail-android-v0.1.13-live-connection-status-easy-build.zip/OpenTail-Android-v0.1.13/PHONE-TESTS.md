# OpenTail Android v0.1.13 — phone validation

Use CORE v0.1.24 with the existing Wi-Fi and lighting configuration. No firmware update is needed.

1. With Wi-Fi off and BLE authorized, verify top-right badge says **BLE authorized** (not generic Connected).
2. Disable Bluetooth using Android Quick Settings. Verify within a moment that the green BLE badge disappears and header says **Bluetooth off** with neutral color. Layout > Bluetooth Output Manager should show Bluetooth Off / disconnected / not authorized.
3. Enable Bluetooth; use Find BLE if necessary, reconnect and authorize. The header and Output Manager should reflect the actual transitions.
4. With CORE Wi-Fi still connected, disable Bluetooth again; top-right must explicitly show **Wi-Fi connected** (not BLE connected). Disconnect CORE Wi-Fi as well and confirm status is no longer green.
5. Watch Output Manager show Scan / Connecting / Pairing / Authorizing / Reading / Saving and final confirmation or error messages near the top.
6. Reload GPIO17 (30-pixel test) and confirm stored configuration. Do not modify GPIO16 for this UI-only test.
7. Restart app / CORE and verify BLE authorization and readback still work, then verify that saved GPIO16 zones and Wi-Fi Studio remain intact.

If the phone differs, record Android version, specific badge text, Wi-Fi state, Bluetooth state, and steps to reproduce. Do not assert success without physical testing. BENCH ONLY; not vehicle safety certified.
