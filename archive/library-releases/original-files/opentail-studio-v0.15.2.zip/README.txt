OpenTail Studio v0.15.2 — WLED connected build

Changes: one effect selector (Connected WLED Effects), settings follow the chosen effect, and separate SELECTED/RUNNING indicators. No second effect dropdown.

Upload opentail.htm via WLED /edit, replacing the previous opentail.htm. Open /opentail.htm?v=152 to avoid Safari cache.

Bench-test only. Existing WLED effect commands still apply to all configured segments. No physical hardware testing performed.
