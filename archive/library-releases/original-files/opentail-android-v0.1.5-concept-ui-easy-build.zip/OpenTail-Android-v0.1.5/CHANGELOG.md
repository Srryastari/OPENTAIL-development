# OpenTail Android v0.1.5 — Compact UI consistency pass

- Home: concise controller overview and live output cards instead of full legacy dashboard.
- Triggers: compact eight-input mapping overview, with a one-tap full CORE editor.
- Layout: compact output/zone summaries; full existing add/delete, calibration, trigger role and save/readback editor remains accessible.
- Shows: preserves inline BLE / Wi-Fi transport selector and effect commands. Less frequently used color, brightness, speed and stop-timer settings are grouped under Customize.
- Retains the single Android header, two connection cards, five-tab nav and Settings.
- No changes to CORE firmware, BLE command protocol, saved device configurations or standalone Studio.
- Existing BLE authorization, haptics, auto-reconnect, and one-click Windows builder preserved.

Validation: 58 automated static/source/host checks passed. Android SDK compilation and actual phone layout/lighting controls require user testing.
