/* OpenTail Android v0.1.5: single-shell mobile UI. Enhances existing Studio without
   replacing its working CORE APIs, settings storage, trigger logic, or BLE GATT path. */
(function () {
  'use strict';
  if (window.__otUnifiedShell || !window.OpenTailNativeApp) return;
  window.__otUnifiedShell = true;

  const ico = {
    home:'<path d="M3 10 12 3l9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    shows:'<path d="m12 2 2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2z"/>',
    triggers:'<path d="m13 2-8 11h7l-1 9 8-12h-7z"/>',
    layout:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1-2 2-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-.9 1.5v.2h-3v-.2a1.6 1.6 0 0 0-.9-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1-2-2 .1-.1a1.6 1.6 0 0 0 .3-1.8A1.6 1.6 0 0 0 6 14H5v-3h1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1 2-2 .1.1a1.6 1.6 0 0 0 1.8.3A1.6 1.6 0 0 0 12 5V4h3v1a1.6 1.6 0 0 0 .9 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1 2 2-.1.1a1.6 1.6 0 0 0-.3 1.8A1.6 1.6 0 0 0 21 11h.5v3H21a1.6 1.6 0 0 0-1.6 1Z"/>',
    wifi:'<path d="M2 9a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8 15a5 5 0 0 1 8 0"/><circle cx="12" cy="19" r="1"/>',
    bluetooth:'<path d="m7 7 10 10-5 4V3l5 4L7 17"/>',
    arrow:'<path d="m9 18 6-6-6-6"/>',
    info:'<circle cx="12" cy="12" r="10"/><path d="M12 10v7M12 7h.01"/>'
  };
  const icon = (key) => `<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ico[key]}</svg>`;
  const html = document.documentElement;
  const style = document.createElement('style');
  style.id = 'ot-android-unified-css';
  style.textContent = `
  html,html[data-ot-theme],body{background:#080d0a!important;color:#eaf4ee!important;color-scheme:dark!important}
  body{margin:0!important;min-width:0;font-family:Roboto,Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
  #app>.shell{padding:9px 14px 118px!important;max-width:960px}
  #app .top,#app nav.tabs,#app nav.bottomnav{display:none!important}
  #app .ot-page-intro{margin-top:4px!important}
  body.ot-show-active #app .ot-page-intro{display:none!important}
  .ot-save-warning{color:#ffc0ad;background:#44241b;padding:9px 12px;border-radius:11px;margin-top:10px;font-size:12px;font-weight:650}
  #app .ot-page-intro h1{font-size:21px!important}
  #app .card{border-radius:17px!important}
  #app main{min-width:0}
  .ot-mobile-header{padding:13px 16px 9px;max-width:960px;margin:auto;position:relative;z-index:1}
  .ot-mobile-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}
  .ot-mobile-heading h1{font-size:25px;line-height:1.12;letter-spacing:-.7px;margin:0;font-weight:750;color:#effaf1}
  .ot-mobile-heading p{margin:5px 0 0;font-size:11px;color:#9aa89f}
  .ot-connected-badge{border-radius:100px;background:#162a1d;color:#a9ebbd;padding:8px 11px;border:1px solid #315c3e;font-size:11px;font-weight:700;white-space:nowrap}
  .ot-connected-badge.offline{background:#2a261b;color:#e8cca0;border-color:#514930}
  .ot-connection-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .ot-connection-card{appearance:none;display:flex;align-items:center;gap:9px;text-align:left;border:1px solid #2b3730;background:#151d18;color:#e8f2eb;border-radius:15px;padding:10px 11px;min-height:59px;font:inherit;width:100%;cursor:pointer}
  .ot-connection-card:focus-visible,.ot-native-nav button:focus-visible,.ot-quick-action:focus-visible{outline:2px solid #70e597;outline-offset:2px}
  .ot-connection-card svg{color:#71d995;flex-shrink:0;width:23px;height:23px}
  .ot-connection-card[data-active=false] svg{color:#9ca8a1}
  .ot-connection-card strong{display:block;font-size:13px;line-height:1.3}
  .ot-connection-card small{display:block;color:#a1afa6;font-size:11px;margin-top:3px}
  .ot-native-nav{position:fixed;bottom:0;left:0;right:0;z-index:1050;display:flex;justify-content:space-around;align-items:stretch;gap:3px;background:#0c140f;border-top:1px solid #293a30;padding:8px 6px calc(10px + env(safe-area-inset-bottom,0px));box-shadow:0 -8px 24px #0008}
  .ot-native-nav button{appearance:none;flex:1;min-width:0;min-height:52px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:4px;border:0;border-radius:12px;background:transparent;color:#99aca0;font:600 10px/1.15 Roboto,Inter,sans-serif;cursor:pointer}
  .ot-native-nav button[aria-current=page]{background:#1b3023;color:#84e5a9}
  .ot-native-nav button svg{width:21px;height:21px}
  .ot-settings-page{display:none;padding:10px 16px 130px;max-width:960px;margin:auto}
  body.ot-settings-active .ot-settings-page{display:block}
  body.ot-settings-active #app{display:none}
  .ot-settings-page h2{font-size:20px;margin:6px 0 7px}
  .ot-settings-page p{font-size:13px;line-height:1.5;color:#a5b1aa;margin:0 0 19px}
  .ot-settings-group{background:#151d18;border:1px solid #2d3c31;border-radius:17px;overflow:hidden;margin-bottom:14px}
  .ot-quick-action{display:flex;width:100%;background:transparent;color:#e2eee5;text-align:left;padding:17px;border:0;border-bottom:1px solid #2c3a30;font:inherit;align-items:center;justify-content:space-between;gap:12px;min-height:57px;cursor:pointer}
  .ot-quick-action:last-child{border-bottom:0}.ot-quick-action svg{color:#87d99d}
  .ot-settings-help{font-size:12px!important;line-height:1.6!important;padding:2px 3px}
  #ot-ble-inline{margin:7px 0 16px!important}
  #ot-ble-inline .ot-ble-head h2{font-size:19px!important}
  #ot-ble-inline .ot-ble-head p{font-size:11px!important}
  #ot-ble-inline .ot-ble-fields{gap:11px!important}
  #ot-ble-inline .ot-ble-actions button{min-height:50px!important}
  html[data-ot-theme="light"],html[data-ot-theme="light"] body{background:#f6faf7!important;color:#203025!important;color-scheme:light!important}
  html[data-ot-theme="light"] .ot-mobile-heading h1{color:#15261a}
  html[data-ot-theme="light"] .ot-mobile-heading p{color:#5b7061}
  html[data-ot-theme="light"] .ot-connected-badge{background:#e3f4e8;color:#2c7443;border-color:#b8d8c1}
  html[data-ot-theme="light"] .ot-connection-card,html[data-ot-theme="light"] .ot-settings-group{background:#ffffff;color:#17301d;border-color:#d6e3d8}
  html[data-ot-theme="light"] .ot-connection-card small,html[data-ot-theme="light"] .ot-settings-page p{color:#566b5a}
  html[data-ot-theme="light"] .ot-native-nav{background:#f8fbf8;border-color:#cdded0}
  html[data-ot-theme="light"] .ot-native-nav button{color:#526b58}
  html[data-ot-theme="light"] .ot-native-nav button[aria-current=page]{background:#dff4e5;color:#246b3c}
  html[data-ot-theme="light"] .ot-quick-action{color:#23442d;border-color:#d6e3d8}
    @media(min-width:700px){.ot-mobile-header,.ot-settings-page{padding-left:30px;padding-right:30px}#app>.shell{padding-left:30px!important;padding-right:30px!important}.ot-native-nav{max-width:960px;margin:auto;left:0;right:0;border-left:1px solid #293a30;border-right:1px solid #293a30}}
  @media(max-width:350px){.ot-connected-badge{padding:7px}.ot-connection-card{padding:10px 7px;gap:5px}.ot-mobile-heading h1{font-size:22px}}
  `;
  document.head.appendChild(style);
  const header = document.createElement('header');
  header.className = 'ot-mobile-header';
  header.innerHTML = `<div class="ot-mobile-heading"><div><h1>OpenTail</h1><p>Universal automotive lighting · Android v0.1.5</p></div><span class="ot-connected-badge offline" id="ot-connected-badge">Offline</span></div>
    <div id="ot-save-banner" class="ot-save-warning" hidden role="alert">Save failed · Review Studio changes</div><div class="ot-connection-grid"><button type="button" class="ot-connection-card" id="ot-wifi-card" data-active="false" aria-label="Wi-Fi connection settings">${icon('wifi')}<span><strong>Wi-Fi</strong><small id="ot-wifi-text">Not connected</small></span></button>
    <button type="button" class="ot-connection-card" id="ot-ble-card" data-active="false" aria-label="Bluetooth connection settings">${icon('bluetooth')}<span><strong>Bluetooth</strong><small id="ot-ble-text">Not connected</small></span></button></div>`;
  const settings = document.createElement('section');
  settings.className = 'ot-settings-page';
  settings.id = 'ot-unified-settings';
  settings.innerHTML = `<h2>Settings</h2><p>Connections, device preferences and advanced controller tools.</p><div class="ot-settings-group">
    <button class="ot-quick-action" data-ot-native="connect">Connect to CORE over Wi-Fi ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="wifi">Android Wi-Fi settings ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="scan">Find Bluetooth controller ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="authorize">Authorize BLE lighting ${icon('arrow')}</button>
  </div><div class="ot-settings-group">
    <button class="ot-quick-action" data-ot-native="prefs">Haptics and reconnection ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="appearance">Studio appearance ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="diagnostics">Diagnostics ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="advanced">Advanced Studio connection tools ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="offline">Offline Studio ${icon('arrow')}</button>
  </div><p class="ot-settings-help">Bluetooth lighting is currently BENCH ONLY. Physical lighting triggers override shows. The brightness control is not a current limiter. Keep vehicle road lighting independent of this prototype.</p>`;
  const nav = document.createElement('nav');
  nav.className = 'ot-native-nav';
  nav.setAttribute('aria-label', 'OpenTail main navigation');
  const destinations = [ ['home','Home','home'],['scenes','Shows','shows'],['builder','Triggers','triggers'],['layout','Layout','layout'],['settings','Settings','settings'] ];
  nav.innerHTML = destinations.map(([id,label,ic]) => `<button type="button" data-ot-destination="${id}" aria-current="false">${icon(ic)}<span>${label}</span></button>`).join('');
  document.body.prepend(header);
  document.body.appendChild(settings);
  document.body.appendChild(nav);
  let settingsOpen = false;
  const state = () => {
    try { return JSON.parse(window.OpenTailNativeApp.getState() || '{}'); } catch (_) { return {}; }
  };
  function refresh() {
    const s = state();
    const badge = document.getElementById('ot-connected-badge');
    const wifiText = document.getElementById('ot-wifi-text');
    const bleText = document.getElementById('ot-ble-text');
    const wifiCard = document.getElementById('ot-wifi-card');
    const bleCard = document.getElementById('ot-ble-card');
    const connected = Boolean(s.wifi || s.ble);
    const failure = document.getElementById('ot-save-failure');
    const warning = document.getElementById('ot-save-banner');
    if (warning) warning.hidden = !failure || failure.hidden;
    if (badge) {badge.textContent = connected ? 'Connected' : 'Offline';badge.classList.toggle('offline',!connected);}
    if (wifiText) wifiText.textContent = s.wifi ? 'Connected' : 'Not connected';
    if (bleText) bleText.textContent = s.ble ? (s.bleAuthorized ? 'Ready · Authorized' : 'Connected') : 'Not connected';
    if (wifiCard) wifiCard.dataset.active = String(Boolean(s.wifi));
    if (bleCard) bleCard.dataset.active = String(Boolean(s.ble));
    const activeTab = document.querySelector('.tabs .tab.active');
    let route = settingsOpen ? 'settings' : 'home';
    if (!settingsOpen && activeTab) {
      const text = activeTab.textContent || '';
      if (/Show Modes/i.test(text)) route='scenes';
      else if (/Triggers/i.test(text)) route='builder';
      else if (/Layout/i.test(text)) route='layout';
      else if (/Connect|Diagnostics/i.test(text)) route='settings';
    }
    document.body.classList.toggle('ot-show-active',!settingsOpen && route==='scenes');
    nav.querySelectorAll('button[data-ot-destination]').forEach(el => el.setAttribute('aria-current',el.dataset.otDestination===route?'page':'false'));
  }
  function navigate(target) {
    if (target === 'settings') {settingsOpen=true;document.body.classList.add('ot-settings-active');refresh();return;}
    settingsOpen=false;document.body.classList.remove('ot-settings-active');
    if (typeof window.go === 'function') window.go(target);
    refresh();
    window.scrollTo({top:0,behavior:'instant'});
  }
  document.addEventListener('click', event => {
    const dest = event.target.closest('.ot-native-nav [data-ot-destination]');
    if (dest) {navigate(dest.dataset.otDestination);return;}
    if (event.target.closest('#ot-wifi-card')) {navigate('settings');return;}
    if (event.target.closest('#ot-ble-card')) {navigate('settings');return;}
    const action = event.target.closest('[data-ot-native]');
    if (!action) return;
    const commands={
      connect:'connectWifi',wifi:'wifiSettings',scan:'scanBle',authorize:'authorizeBle',
      prefs:'appSettings',offline:'offlineStudio'
    };
    if (commands[action.dataset.otNative]) {
      window.OpenTailNativeApp[commands[action.dataset.otNative]]();
      if (action.dataset.otNative === 'offline') navigate('home');
      return;
    }
    if (action.dataset.otNative==='appearance' && typeof window.otSetTheme === 'function') window.otSetTheme(document.documentElement.dataset.otTheme==='light'?'dark':'light');
    if (action.dataset.otNative==='diagnostics') navigate('diagnostics');
    if (action.dataset.otNative==='advanced') navigate('device');
  });
  const app = document.getElementById('app');
  if (app) {
    let queued=false;
    new MutationObserver(() => {
      if (queued) return;
      queued=true;
      requestAnimationFrame(() => {queued=false;refresh();});
    }).observe(app,{childList:true,subtree:false});
  }
  window.OpenTailShell = { refresh, navigate };
  refresh();
  // Open directly to the agreed Show Modes design, without clearing saved projects.
  if (typeof window.go === 'function') navigate('scenes');
  setInterval(refresh,2000);
})();

/* OpenTail Android v0.1.5 — compact native-first surfaces.
   Preserve all existing Studio editors and their proven save/readback functions.
   These read-only overview cards never overwrite output or trigger configuration. */
(function () {
  'use strict';
  if (!window.OpenTailShell || window.__otCompactSurfaces) return;
  window.__otCompactSurfaces = true;
  const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const names = {park:'Parking',brake:'Brake',left:'Left turn',right:'Right turn',reverse:'Reverse',aux1:'Auxiliary 1',aux2:'Auxiliary 2',aux3:'Auxiliary 3',disabled:'Disabled'};
  const panel = document.createElement('main');
  panel.id='ot-compact-pages';
  panel.setAttribute('aria-live','polite');
  const header=document.querySelector('.ot-mobile-header');
  document.body.insertBefore(panel, header?.nextSibling || document.body.firstChild);
  const css=document.createElement('style');
  css.id='ot-compact-surface-style';
  css.textContent=`
    .ot-mobile-header{max-width:720px!important}
    .ot-mobile-heading h1{font-size:23px!important}
    #ot-compact-pages{display:none;padding:12px 16px calc(100px + env(safe-area-inset-bottom, 0px));max-width:720px;margin:0 auto;box-sizing:border-box}
    body.ot-compact-view #ot-compact-pages{display:block}
    body.ot-compact-view #app{display:none!important}
    body.ot-compact-view .ot-mobile-header{display:block}
    body.ot-settings-active #ot-compact-pages{display:none!important}
    .ot-simple-top{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:14px}
    .ot-simple-top h2{margin:0 0 4px;font-size:21px;line-height:1.2;font-weight:750;letter-spacing:-.3px}
    .ot-simple-top p{margin:0;color:#9eada4;font-size:12px;line-height:1.35}
    .ot-simple-tag{font-size:10px;color:#b0e9bd;white-space:nowrap;border-radius:999px;padding:6px 9px;background:#193021;border:1px solid #2f5e41}
    .ot-simple-card{background:#151e18;border:1px solid #2c3930;border-radius:17px;padding:15px;margin-bottom:12px}
    .ot-simple-card h3{font-size:15px;margin:0 0 11px;color:#edf9ef}
    .ot-simple-card .ot-muted{color:#9eaea4;font-size:12px;line-height:1.5}
    .ot-simple-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
    .ot-simple-stat{background:#0d1510;border:1px solid #304136;border-radius:13px;padding:13px}
    .ot-simple-stat strong{font-size:20px;font-variant-numeric:tabular-nums;display:block;line-height:1.2;margin-bottom:5px}
    .ot-simple-stat small{font-size:11px;color:#a9b9ad}
    .ot-simple-button{font:650 13px Roboto,Inter,sans-serif;appearance:none;border:0;min-height:43px;border-radius:11px;background:#27764a;color:#fff;padding:10px 14px;cursor:pointer}
    .ot-simple-button.secondary{background:#192b20;border:1px solid #426c4d;color:#c5f2d3}
    .ot-simple-button:focus-visible{outline:2px solid #75e69e;outline-offset:2px}
    .ot-simple-actions{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:14px}
    .ot-simple-line{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 1px;border-bottom:1px solid #28352c;font-size:13px}
    .ot-simple-line:last-child{border-bottom:none;padding-bottom:2px}
    .ot-simple-line strong{font-size:13px}
    .ot-simple-line small{display:block;font-size:11px;color:#9fac9f;margin-top:3px}
    .ot-simple-value{font-size:12px;font-weight:650;color:#d3f1d9;text-align:right;white-space:normal}
    .ot-simple-output{background:#0d1711;border:1px solid #314537;border-radius:12px;padding:12px;margin-top:10px}
    .ot-simple-output h4{font-size:14px;margin:0 0 5px}
    .ot-simple-tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}
    .ot-simple-tags span{font-size:10px;color:#b5d0bc;background:#1b2b21;border:1px solid #365042;border-radius:99px;padding:4px 7px}
    .ot-simple-readonly{font-size:11px;color:#a8b8ac;margin:8px 0 0;line-height:1.4}
    body.ot-compact-shows #app .ot-page-intro{display:none!important}
    body.ot-compact-shows #app>.shell{padding-top:4px!important}
    body.ot-compact-shows.ot-ble-mode #app main > :not(#ot-ble-inline){display:none!important}
    body.ot-compact-shows #app main:has(#ot-ble-inline [data-ot-ble="ble"][aria-pressed="true"]) > :not(#ot-ble-inline){display:none!important}
    body.ot-compact-shows #app .footer{display:none!important}
    body.ot-compact-shows.ot-ble-mode #ot-ble-inline{margin-top:0!important}
    body.ot-compact-shows .ot-ble-fields{row-gap:9px!important}
    body.ot-compact-shows .ot-ble-notice{display:none!important}
    body.ot-compact-shows .ot-ble-response{font-size:11px!important;margin-top:7px!important;min-height:15px!important}
    body.ot-compact-shows .ot-ble-actions{grid-template-columns:2fr 1fr!important}
    body.ot-compact-shows .ot-ble-actions button{min-height:50px!important}
    body.ot-compact-shows .ot-ble-inline .ot-ble-status{font-size:10px!important}
    body.ot-compact-shows .ot-ble-switch button{min-height:41px!important}
    body.ot-compact-shows .ot-ble-inline .ot-ble-fields label{font-size:11px!important}
    body.ot-compact-shows .ot-ble-inline .ot-ble-head p{font-size:11px!important}
    body.ot-compact-shows .ot-ble-inline .ot-ble-head h2{margin-bottom:3px!important}
    body.ot-editor-active #app .ot-page-intro{display:none!important}
    body.ot-editor-active #app .ot-om-card>p.small.muted,body.ot-editor-active #app .ot-tm-card>p.small.muted{display:none!important}
    body.ot-editor-active #app .ot-om-card,body.ot-editor-active #app .ot-tm-card{padding:12px!important}
    body.ot-editor-active #app .ot-om-zone{padding:12px!important;margin-top:9px!important}
    body.ot-editor-active #app .ot-om-zone-head{margin-bottom:7px!important}
    body.ot-editor-active #app .ot-om-card .field,body.ot-editor-active #app .ot-tm-card .field{margin-bottom:8px!important}
    html[data-ot-theme=light] .ot-simple-card{background:#fff;border-color:#d6e4d7}
    html[data-ot-theme=light] .ot-simple-card h3,html[data-ot-theme=light] .ot-simple-top h2{color:#1a2d20}
    html[data-ot-theme=light] .ot-simple-stat,html[data-ot-theme=light] .ot-simple-output{background:#f1f7f2;color:#193623;border-color:#d1e1d4}
    html[data-ot-theme=light] .ot-simple-line{border-color:#dce9df}
    html[data-ot-theme=light] .ot-simple-value{color:#23643b}
    @media(min-width:700px){#ot-compact-pages{padding-left:28px;padding-right:28px}}
  `;
  document.head.appendChild(css);
  let route='';
  let advanced=false;
  let requestEpoch=0;
  let outputs=null,triggers=null;
  let outputError='',triggerError='';
  function routeNow() {
    if (document.body.classList.contains('ot-settings-active')) return 'settings';
    const name=document.querySelector('.tabs .tab.active')?.textContent?.trim() || '';
    if (/Show Modes/i.test(name)) return 'shows';
    if (/Triggers/i.test(name)) return 'triggers';
    if (/Layout/i.test(name)) return 'layout';
    if (/Dashboard/i.test(name)) return 'home';
    return 'other';
  }
  const connection=()=>{try {return JSON.parse(window.OpenTailNativeApp.getState()||'{}')} catch(_){return {}}};
  function outputCards(){
    if (!outputs) return `<p class="ot-muted">${esc(outputError||'Connect to CORE Wi-Fi to load saved pixel outputs.')}</p>`;
    return outputs.map(o=>{
      const total=Array.isArray(o.zones)?o.zones.reduce((n,z)=>n+Number(z.pixels||0),0):null;
      return `<div class="ot-simple-output"><h4>${esc(o.name||'Pixel OUT '+(Number(o.index)+1))}</h4>
        <div class="ot-simple-line"><small>GPIO${esc(o.pin)} · ${esc(o.color_order)}</small><strong>${esc(o.pixels)} pixels</strong></div>
        <div class="ot-simple-tags">${(o.zones||[]).filter(z=>z.pixels>0).map(z=>`<span>${esc(z.name)} · ${esc(z.pixels)}</span>`).join('')||'<span>No active zones</span>'}</div>
        ${total!==null&&total!==Number(o.pixels)?'<p class="ot-simple-readonly">Assigned zone totals do not match active pixels.</p>':''}</div>`;
    }).join('');
  }
  function top(title,subtitle){return `<div class="ot-simple-top"><div><h2>${title}</h2><p>${subtitle}</p></div><span class="ot-simple-tag">CORE bench</span></div>`;}
  function summaryMarkup(){
    if (route==='home') {
      const total = outputs ? outputs.reduce((n,o)=>n+Number(o.pixels||0),0) : null;
      return top('Home','Your lighting controller, at a glance')+
        `<div class="ot-simple-card"><h3>Controller overview</h3><div class="ot-simple-stats">
          <div class="ot-simple-stat"><strong>${outputs?outputs.length:'—'}</strong><small>Physical pixel outputs</small></div>
          <div class="ot-simple-stat"><strong>${total===null?'—':total.toLocaleString()}</strong><small>Configured pixels</small></div>
        </div><p class="ot-simple-readonly">${esc(outputs?'Read from CORE output configuration.':'Connect to CORE Wi-Fi to load live configuration.')}</p>
        <div class="ot-simple-actions"><button class="ot-simple-button" data-ot-open="shows">Open Show Modes</button><button class="ot-simple-button secondary" data-ot-open="layout">View Layout</button></div></div>
        <div class="ot-simple-card"><h3>Lighting setup</h3>${outputCards()}</div>`;
    }
    if (route==='triggers') {
      const rows=triggers?.inputs || [];
      return top('Triggers','Eight programmable signal inputs')+`<div class="ot-simple-card"><h3>Input assignments</h3>`+
        (rows.length?rows.map(x=>`<div class="ot-simple-line"><div><strong>IN${esc(x.index)}</strong><small>GPIO${esc(x.gpio)}</small></div><span class="ot-simple-value">${esc(names[x.function]||x.function)}</span></div>`).join(''):
        `<p class="ot-muted">${esc(triggerError||'Connect to CORE Wi-Fi to view saved trigger assignments.')}</p>`)+
        `<div class="ot-simple-actions"><button class="ot-simple-button" data-ot-open="edit">Edit assignments</button><button class="ot-simple-button secondary" data-ot-open="diagnostics">Diagnostics</button></div>
        <p class="ot-simple-readonly">Overview only. Edits use Studio's existing verified CORE save and readback process.</p></div>`;
    }
    if (route==='layout') {
      return top('Layout','Outputs, zones and pixel mapping')+`<div class="ot-simple-card"><h3>Saved output configuration</h3>`+
        outputCards()+`<div class="ot-simple-actions"><button class="ot-simple-button" data-ot-open="edit">Edit outputs & zones</button><button class="ot-simple-button secondary" data-ot-open="shows">Test Show Modes</button></div>
        <p class="ot-simple-readonly">Full editing supports renaming, add/delete zones, RGB order, calibration and trigger roles.</p></div>`;
    }
    return '';
  }
  function refreshVisual(force=false){
    const next=routeNow();
    if (next!==route){advanced=false;route=next;force=true; if(['home','layout','triggers'].includes(route)) readConfig(route);}
    const showing=['home','layout','triggers'].includes(route);
    document.body.classList.toggle('ot-compact-view',showing&&!advanced);
    document.body.classList.toggle('ot-editor-active',showing&&advanced);
    document.body.classList.toggle('ot-compact-shows',route==='shows');
    const mode=document.querySelector('#ot-ble-inline [data-ot-ble="ble"]')?.getAttribute('aria-pressed');
    document.body.classList.toggle('ot-ble-mode',route==='shows'&&mode==='true');
    if (showing) {
      const current=advanced?`<div class="ot-simple-top"><div><h2>${esc(route==='layout'?'Layout editor':route==='triggers'?'Trigger editor':'Advanced Dashboard')}</h2><p>Full Studio editing tools</p></div><button class="ot-simple-button secondary" data-ot-open="back">Back</button></div>`:summaryMarkup();
      if (force||panel.innerHTML!==current) panel.innerHTML=current;
      panel.style.display=advanced?'block':'';
    } else {panel.innerHTML='';panel.style.display='';}
  }
  async function readConfig(which){
    const epoch=++requestEpoch;
    if (!connection().wifi || location.hostname!=='192.168.4.1') {
      outputs=null;triggers=null;outputError=triggerError='Connect to CORE Wi-Fi to read device settings.';
      refreshVisual(true);return;
    }
    const entries=which==='triggers'?[['triggers','/api/v1/triggers']]:[['outputs','/api/v1/outputs']];
    for(const [kind,path] of entries){
      try {
        const res=await fetch(path,{method:'GET',cache:'no-store',signal:AbortSignal.timeout(4500)});
        if (!res.ok) throw Error('HTTP '+res.status);
        const val=await res.json();
        if(epoch!==requestEpoch)return;
        if (kind==='outputs') {
          if(!Array.isArray(val.outputs)||val.outputs.length!==2) throw Error('Unexpected output response');
          outputs=val.outputs;outputError='';
        } else {
          if(!Array.isArray(val.inputs)||val.inputs.length!==8) throw Error('Unexpected trigger response');
          triggers=val;triggerError='';
        }
      } catch(err){if(epoch!==requestEpoch)return;if(kind==='outputs'){outputs=null;outputError='Output read unavailable: '+err.message;}else{triggers=null;triggerError='Trigger read unavailable: '+err.message;}}
    }
    if(epoch===requestEpoch)refreshVisual(true);
  }
  document.addEventListener('click', e=>{
    const b=e.target.closest('#ot-compact-pages [data-ot-open]');
    if(b){
      const action=b.dataset.otOpen;
      if(action==='edit'){advanced=true;refreshVisual(true);return;}
      if(action==='back'){advanced=false;readConfig(route);refreshVisual(true);return;}
      const destination={shows:'scenes',layout:'layout',diagnostics:'diagnostics'}[action];
      if(destination&&typeof window.go==='function'){window.go(destination);refreshVisual(true);}return;
    }
    if(e.target.closest('.ot-native-nav [data-ot-destination]')) requestAnimationFrame(()=>refreshVisual(true));
    if(e.target.closest('#ot-ble-inline [data-ot-ble]'))requestAnimationFrame(()=>refreshVisual(true));
  });
  const app=document.getElementById('app');
  if(app){let waiting=false;new MutationObserver(()=>{if(waiting)return;waiting=true;requestAnimationFrame(()=>{waiting=false;refreshVisual()})}).observe(app,{childList:true,subtree:false});}
  if(typeof window.OpenTailShell.navigate==='function'){
    const old=window.OpenTailShell.navigate;
    window.OpenTailShell.navigate=function(target){old(target);refreshVisual(true)};
  }
  refreshVisual(true);
  setInterval(()=>refreshVisual(),2500);
  window.OpenTailCompactUI={refresh:refreshVisual,readConfig};
})();
