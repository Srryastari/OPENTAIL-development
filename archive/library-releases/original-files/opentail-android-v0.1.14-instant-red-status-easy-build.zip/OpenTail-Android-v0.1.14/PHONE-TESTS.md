# OpenTail Android v0.1.14 — phone validation

Use CORE v0.1.24 with the existing Wi-Fi and lighting configuration. No firmware update is needed.

1. With Wi-Fi off and BLE authorized, verify top-right badge says **BLE authorized** (not generic Connected).
2. Disable Bluetooth using Android Quick Settings. Verify within a moment that the green BLE badge disappears and header says **Bluetooth off** with neutral color. Layout > Bluetooth Output Manager should show Bluetooth Off / disconnected / not authorized.
3. Enable Bluetooth; use Find BLE if necessary, reconnect and authorize. The header and Output Manager should reflect the actual transitions.
4. With CORE Wi-Fi still connected, disable Bluetooth again; top-right must explicitly show **Wi-Fi connected** (not BLE connected). Disconnect CORE Wi-Fi as well and confirm status is no longer green.
5. Watch Output Manager show Scan / Connecting / Pairing / Authorizing / Reading / Saving and final confirmation or error messages near the top.
6. Reload GPIO17 (30-pixel test) and confirm stored configuration. Do not modify GPIO16 for this UI-only test.
7. Restart app / CORE and verify BLE authorization and readback still work, then verify that saved GPIO16 zones and Wi-Fi Studio remain intact.

If the phone differs, record Android version, specific badge text, Wi-Fi state, Bluetooth state, and steps to reproduce. Do not assert success without physical testing. BENCH ONLY; not vehicle safety certified.

## v0.1.14 instant connection-state colors

- [ ] BLE authorized shows **green** at top-right.
- [ ] Switch Bluetooth off in Android Quick Settings while app remains open: badge immediately shows **red Bluetooth off**, without tab change.
- [ ] If Wi-Fi stays connected, Home's Wi-Fi card remains green, but the top-right BLE-off label is still red.
- [ ] Switch Bluetooth back on: red disconnected initially, **amber** while scanning/pairing/authorizing, **green** only once linked and authorized.
- [ ] Turn Wi-Fi off with no BLE link: show **red Disconnected**.
- [ ] Confirm Bluetooth Output Manager shows the same red/amber/green state and updates while on Layout.
- [ ] Confirm GPIO17 BLE read/save and GPIO16 isolation still work.

These are phone validation steps; they have not been run here.
