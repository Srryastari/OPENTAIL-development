# OpenTail Android v0.1.14 — Instant, red connection health

- Fix: BLE Off and Disconnected are **red**, not gray or stale green, including when Wi-Fi remains connected.
- Show amber while BLE scanning, connecting, pairing, authorizing, reading, or saving; show green only when linked and authorized or verified Wi-Fi is the displayed transport.
- Update header, Bluetooth Output Manager, and Home transport cards from native Bluetooth radio/GATT state change events and Wi-Fi network callbacks. No waiting for a screen change or manual refresh.
- Preserve CORE v0.1.24 firmware, Wi-Fi Studio, BLE BOOT enrollment, BLE output read/write/readback, and stored output settings.
- Automated checks use simulated state changes. **Android APK compilation and physical phone checks remain pending.**

## Test on phone
1. Verify authorized BLE is green.
2. Turn off Android Bluetooth in Quick Settings; top badge must immediately show red “Bluetooth off.”
3. Turn Bluetooth on and reconnect: amber while connecting, green only after authorization.
4. Turn Wi-Fi off with BLE disconnected: indicator red “Disconnected.”
5. With Wi-Fi still working and BLE turned off: red Bluetooth-off badge, plus Wi-Fi status in Home connection card.
