# Change log

## v0.1.16 firmware + v0.19.43 Studio — 522-pixel bench + status colors

- Per-output physical allocation increased 30 → 522; GS400 main housing configuration: 118/109/42/253/0.
- Corrected color order retained from saved NVS settings rather than being reset.
- Onboard RGB: connected green; disconnected blue; genuine fault red. Native effects no longer override connection health indication.
- Disabled the simulated red fault self-test; retained deliberate rainbow onboard LED test.
- Studio Diagnostics updated to match status LED behavior, v0.19.43, with refreshed embedded gzip asset.
- Bench-only, no automotive failover. Physical 522-pixel output and full power delivery remain unverified.

# Change log

## v0.1.15 firmware + v0.19.42 Studio (2026-10-24)

- Introduced Output Manager v1: two device-saved configurable physical outputs, names, 5 named contiguous zones per output, 5–30 active pixels, roles, RGB channel order (all six RGB permutations).
- New GET/POST `/api/v1/outputs`; validation, NVS persistence, readback, busy-device write guard, and no active reallocation beyond the tested 30-pixel driver allocation.
- Native effects now use configured per-output zone lengths. Real 12V trigger inputs select output zone roles; unmapped or disabled zones remain off. AUX6–IN8 can be assigned to lighting zones in the bench renderer.
- Studio Layout gains Output Manager while retaining preexisting local design Layout and WLED functionality. Show Modes now label outputs without hardcoding left/right.
- Status arbitration screen explicitly describes legacy section examples instead of falsely describing the configurable output map.
- New portable output-manager tests, and unchanged source timestamps for Windows ESP-IDF rebuild stability.

This is a **BENCH-ONLY** source release. The firmware has not been compiled or flashed against an ESP-IDF toolchain in this environment; output color order, output rendering and NVS persistence have not been physically verified.
