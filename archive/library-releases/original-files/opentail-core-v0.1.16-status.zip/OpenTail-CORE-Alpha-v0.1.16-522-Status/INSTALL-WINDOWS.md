# OpenTail CORE v0.1.16 (522 pixels + revised status LED) — Windows installation

This is **bench-only** development firmware. It is not automotive-safe; do not use as the car's only lighting system.

## 1. Download and extract

Save `opentail-core-v0.1.16-status.zip` to your Windows **Downloads** folder. Open **ESP-IDF 5.5.5 PowerShell** from the Start menu. Use these commands, one line at a time:

```powershell
$zip = Join-Path $env:USERPROFILE 'Downloads\opentail-core-v0.1.16-status.zip'
$dest = Join-Path $env:USERPROFILE 'Desktop\OpenTail'
Test-Path $zip
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
Get-ChildItem $dest -Directory | Where-Object Name -like '*v0.1.16*'
cd (Join-Path $dest 'OpenTail-CORE-Alpha-v0.1.16-522-Status')
Test-Path .\CMakeLists.txt
```

`Test-Path` should report `True` twice (ZIP and `CMakeLists.txt`). If not, stop: download or extraction path needs correcting. If Windows created a nested folder, use File Explorer to locate `CMakeLists.txt` and `cd` to *that* folder.

## 2. Check the ESP-IDF environment

Run `idf.py --version`. If `idf.py` is unrecognized, open the **ESP-IDF PowerShell** shortcut, not generic Windows PowerShell.

## 3. Prepare and compile

```powershell
idf.py set-target esp32s3
idf.py build
```

Expect `Project build complete`. If there is a build error, **do not flash**. Share the first error and the last 20 lines of output. `set-target` prepares a project configuration for ESP32-S3; it is NOT `erase-flash`.

## 4. Flash using USB

Check the ESP32-S3 is connected and is on COM9 (or look up the new COM port in Device Manager). Close any other serial monitor. Leave LED power disconnected during flashing if convenient.

```powershell
idf.py -p COM9 flash monitor
```

Look for `CORE 0.1.16-alpha is BENCH-ONLY`. Do **not** run `idf.py erase-flash` or use Erase All Flash. `flash` ordinarily preserves the NVS partition holding Output Manager settings. Exit serial monitor with **Ctrl+]**.

## 5. Reconnect Studio

On iPhone, join Wi-Fi `OpenTail-CORE-Alpha`, then visit `http://192.168.4.1/studio` (may use Safari reload). Footer should show Studio v0.19.43, and CORE status should report firmware v0.1.16-alpha.

Open **Layout → Universal Output Manager → Pixel OUT 1**. Verify the corrected color order survived. Select the **GS400 main housing · 522** preset: Top 118, Turn 109, Reverse 42, Bottom 253, Trunk 0. Save to CORE, then Reload device and confirm the exact readback. Do not set incorrect color order back to BRG if the saved corrected setting works.

## 6. Bench acceptance checks

- Onboard status light: after startup white flash, blue pulse with Studio inactive; green double pulse when Studio connects; back to blue (not red) about 8 seconds after Safari suspends its heartbeat. Only a *real firmware-reported fault* gets automatic rapid red flashing.
- Native solid effect on GPIO16 with common ground and properly powered WS2815: first verify low-current small region, correct RGB colors, then intended zones. Keep a conservative power budget and protect wiring with fuses.
- For the entire 522-pixel main housing, the **12V 4A supply is NOT validated for unrestricted simultaneous illumination**. Firmware 12.5% brightness cap is **not** a current limiter; use a suitably rated protected supply and power injection before stressing the whole assembly.
- Save/reload/reboot Output Manager. Repeat IN2+IN3+IN4 bench test only with correctly isolated 12V inputs, and confirm that Safari going into the background does not stop lighting logic.

## Important

A passing build does **not** prove physical WS2815 operation. There is no backup-controller failover or automotive transient protection in this build. Running 3.3V direct data into WS2815 worked for a short test only; it is not a validated long-run automotive signal path.
