# OpenTail Studio — foundation v0.1

A local-first, mobile-responsive, open-source **prototype** for configurable automotive addressable lighting controllers. Targets iOS and Android through an installable PWA first; the browser UI is **not** a compiled native app. A native wrapper or Flutter client can follow once the controller's API is stable.

## Features implemented
- GS400 starter configuration: 1,246 LEDs, left/right 623-pixel continuous chains, 10 independently editable software sections.
- Responsive desktop/iOS/Android-style UI with Home, Animations, Builder, Arrangement, Connect.
- Editable functional profiles: startup, shutdown, brake, tail/park, L/R turn, hazards, reverse, F1-style bench/show strobe, show, lock/unlock.
- Editable section groups, effect parameters, colors, durations, loops, keyframe data, and individual/range pixel color overrides.
- Strip/halo/matrix shape metadata, offsets, pixel directions, per-section extensible protocol registry.
- Local export/import JSON, local persistence, bench trigger **simulation**.
- Standard WLED: connect/discover effects, send basic color/brightness/effect commands via `/json` and `/json/state`.

## NOT implemented yet
- Real-time firmware automotive trigger priority renderer; the editor **stores** profiles but does not run them on hardware.
- True per-pixel live streaming and keyframe playback; rendering these requires firmware endpoints (DDP, E1.31, or a custom reliable protocol).
- Live coordinate mapping to WLED (offset/shape fields are currently metadata).
- Bluetooth transport, discovery, native builds, safe automotive controller, independent light fallback.
- Generic future LED types without a matching physical-layer driver. The protocol dropdown is an **extensible registry**, not proof of chipset compatibility.
- Ownership of or direct cloning of proprietary BlueGhozt effect assets; templates are original and inspired by general lighting categories.

## Running
Run `python3 -m http.server 8000` inside the project folder and visit `http://localhost:8000`. No dependencies are required. For iOS or Android install as a PWA, host under HTTPS and add application icons/service worker for full offline installation (not yet included). Opening index.html locally is fine for editing but networking/PWA features vary by browser.

WLED address: enter `http://4.3.2.1` on its access point or your controller LAN IP. The browser can be blocked by CORS/mixed-content rules; hosting the UI on the ESP32 or using a mobile-native networking layer can resolve that. Never expose bare WLED HTTP to the public internet.

## Architecture contribution contract (proposed)
- `profiles`: declarative animations; `zones`: groups and pixel indices; `layout`: physical coordinate descriptions; `drivers`: chipset capabilities (firmware verified).
- `vehicle-state`: priority logic should run on dedicated MCU firmware with hardware failsafe, not in the app.
- `transport`: separate WLED JSON, custom automotive control and future BLE.
- `renderer`: future timed pixel effects and overlays must respect road safety states regardless of client disconnection.

## Road safety
F1-style brake strobing is present **as a bench/show template only**. Road braking must use legally compliant steady signaling, with independent functioning fallback. Do not install unvalidated project hardware as the sole brake/turn/reverse lighting system.

## License
MIT; see LICENSE. Third-party firmware remains subject to its respective license; no WLED source is bundled in this project.
