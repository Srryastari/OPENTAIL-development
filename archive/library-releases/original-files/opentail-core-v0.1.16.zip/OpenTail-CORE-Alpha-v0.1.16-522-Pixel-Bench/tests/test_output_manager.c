#include "output_manager.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
static void color(ot_rgb_t c,unsigned r,unsigned g,unsigned b){assert(c.r==r&&c.g==g&&c.b==b);}
int main(void){
 ot_om_output_t out[OT_OM_OUTPUTS];ot_om_defaults(out);
 assert(ot_om_valid(&out[0])&&ot_om_valid(&out[1]));
 assert(!strcmp(out[0].name,"Pixel OUT 1"));
 assert(!strcmp(ot_om_role_name(out[0].zones[1].role),"left_turn"));
 assert(!strcmp(ot_om_role_name(out[1].zones[1].role),"right_turn"));
 assert(ot_om_section(&out[0],0)==0&&ot_om_section(&out[0],6)==1&&ot_om_section(&out[0],29)==4);
 assert(ot_om_section(&out[0],30)==-1);
 ot_layout_t layout;assert(ot_om_layout(&out[0],&layout));
 assert(ot_om_role_from_name("reverse")==OT_OM_REVERSE);
 assert(ot_om_order_from_name("BRG")==OT_OM_BRG);
 assert(ot_om_role_from_name("bad")==-1);
 out[0].zones[0].pixels=7;assert(!ot_om_valid(&out[0]));out[0].zones[1].pixels=5;assert(ot_om_valid(&out[0]));
 out[0].color_order=9;assert(!ot_om_valid(&out[0]));out[0].color_order=OT_OM_GRB;
 strcpy(out[0].name,"<script>");assert(!ot_om_valid(&out[0]));strcpy(out[0].name,"Front DRL");assert(ot_om_valid(&out[0]));
 color(ot_om_trigger_color(OT_OM_PARK_BRAKE,0,32),0,0,0);
 color(ot_om_trigger_color(OT_OM_PARK_BRAKE,OT_SIG_PARK,32),7,0,0);
 color(ot_om_trigger_color(OT_OM_PARK_BRAKE,OT_SIG_PARK|OT_SIG_BRAKE,32),32,0,0);
 color(ot_om_trigger_color(OT_OM_REVERSE,OT_SIG_REVERSE,32),32,32,32);
 color(ot_om_trigger_color(OT_OM_AUX1,1u<<5,32),16,0,32);
 ot_rgb_t v={11,22,33};
 const uint8_t seq[6][3]={{11,22,33},{11,33,22},{22,11,33},{22,33,11},{33,11,22},{33,22,11}};
 for(int i=0;i<6;i++){ot_rgb_t s=ot_om_swizzle(v,i);uint8_t actual[3]={s.b,s.r,s.g};assert(!memcmp(actual,seq[i],3));}
 printf("output manager: defaults, validation, zone boundaries, trigger priority and all six color-order permutations passed\n");
 return 0;
}
