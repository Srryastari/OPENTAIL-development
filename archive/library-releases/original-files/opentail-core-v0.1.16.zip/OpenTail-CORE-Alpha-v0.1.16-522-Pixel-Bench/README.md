# OpenTail CORE Alpha v0.1.15 — Universal Output Manager (BENCH ONLY)

This release extends the physically-tested v0.1.14 trigger/arbitration prototype. Studio v0.19.42 is embedded at `/studio`. **It is not automotive road-lighting firmware.** It has no independently verified pixel output, automotive transient protection, verified backup-controller failover, or independent conventional-lighting safety fallback. Do not use as the sole vehicle brake/turn/parking/reverse lights.

## Current hardware limits

- ESP32-S3: 8 vehicle trigger GPIO inputs 4–11, through verified isolated 12V optocoupler module (3.3V-safe logic inputs).
- Two current physical pixel output signals: GPIO16 = Pixel OUT 1; GPIO17 = Pixel OUT 2. External LED data requires a validated level shifter and suitable 12V strip supply.
- Output driver allocates **30 pixels per physical output**. Output Manager permits 5–30 active pixels per output, 5 individually named contiguous zones per output, with adjustable zone lengths whose sum must equal the active count. Pixels past active count up to physical 30 are rendered black. Larger limits and 12 independent outputs are not implemented.
- Supported color-order selections: RGB, RBG, GRB, GBR, BRG (default, previously tested user's strip), BGR. Software channel reorder over the existing BRG-configured strip driver; external physical colors are NOT yet tested.
- Trigger roles: Disabled, Parking + Brake (Brake priority), Parking, Brake, Left Turn, Right Turn, Reverse, Aux 1–3, Show Only. All connected 12V input signals suppress native decorative shows; appropriate assigned zones light for active triggers.
- Settings are written to ESP32 NVS flash, not merely browser local storage. Save is rejected while physical triggers, demos, simulations, or a native show are active. Saving is explicitly confirmed by reading the device back. Restart should preserve settings; actual power-cycle persistence must be bench verified.
- Existing firmware mode reports a **legacy default arbitration example** in `/api/v1/status/arbitration`. After changing zone roles, refer to `/api/v1/outputs` as the source of truth for saved output mappings. Legacy WLED Layout drafts remain separate.

## Windows ESP-IDF 5.5.5 — install

Download ZIP to Desktop, extract into `%USERPROFILE%\Desktop\OpenTail`. Open **ESP-IDF PowerShell**:

```powershell
Expand-Archive -Path "$env:USERPROFILE\Desktop\OpenTail-CORE-Alpha-v0.1.15-Universal-Output-Manager-source.zip" -DestinationPath "$env:USERPROFILE\Desktop\OpenTail" -Force
cd "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.15"
Copy-Item "..\OpenTail-CORE-Alpha-v0.1.14\sdkconfig" ".\sdkconfig" -Force
idf.py build
if ($LASTEXITCODE -eq 0) { idf.py -p COM9 flash }
```

Do not use `idf.py fullclean` unless diagnosing a failed build. Keep previous firmware available for rollback. Close serial monitor before flashing; check port in Device Manager if COM9 changes. The ZIP normalizes source modification times to 2 minutes before packaging (mitigates earlier Windows Ninja/CMake future timestamp loop).

## Bench acceptance checks without external LEDs

1. Connect USB ESP32 to power, join `OpenTail-CORE-Alpha` Wi-Fi, open `http://192.168.4.1/studio`, go to **Layout → Universal Output Manager**.
2. Check **Pixel OUT 1 / GPIO16** and **Pixel OUT 2 / GPIO17** load with 30 pixels and default BRG. Try renaming Pixel OUT 1 to `Front DRL`.
3. Change Zone 1 name or role, leave zone sizes summing to 30; press **Save to CORE**. Confirm **Saved on CORE** and readback.
4. Refresh Studio, use **Reload device**, and verify changes persisted. Reboot ESP32 and reload to validate NVS power-cycle persistence.
5. Test invalid zone sums (e.g. 7,6,6,6,6); saving must be rejected with a clear error, and the original saved map must remain unchanged.
6. Start a 30-second native rainbow Show Mode; saving should be rejected (HTTP 409). Stop it, then try saving again.
7. Use only safe USB/12V optocoupler bench setup previously tested. Activate IN1+IN2 and confirm `input_mask=3`; arbitrate Brake over Parking. Role edits should not alter GPIO numbers or original physical trigger detection. **Do not claim physical WS2815 colors or animation were tested until the shifter arrives.**

## Host tests

Run `bash tests/run-host-tests.sh` on a computer with a C compiler. Includes CORE input logic, RGB status timing, native show logic, arbitration, and new output manager validation and color byte order tests. These are simulation/host tests; **full ESP-IDF build, physical LED output, and NVS persistence tests must still be performed on the user's board**.
