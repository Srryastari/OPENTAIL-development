# OpenTail CORE v0.1.15 — Output Manager API (bench only)

## GET `/api/v1/outputs`
Returns device-saved output configuration, physical pins, active pixel counts, five zones per output, and a snapshot of whether each zone's configured trigger is currently active. Sample:

```json
{
  "revision":1,"saved_on_device":true,"bench_only":true,"physical_outputs":2,
  "future_outputs_target":12,"allocated_pixels_per_output":30,"max_zones_per_output":5,
  "effective_mask":0,"outputs":[{
    "index":0,"pin":16,"name":"Pixel OUT 1","pixels":30,"color_order":"BRG",
    "zones":[
      {"name":"Tail A","pixels":6,"role":"park_brake","trigger_active":false},
      {"name":"Turn","pixels":6,"role":"left_turn","trigger_active":false},
      {"name":"Reverse","pixels":6,"role":"reverse","trigger_active":false},
      {"name":"Tail B","pixels":6,"role":"park_brake","trigger_active":false},
      {"name":"Tail C","pixels":6,"role":"park_brake","trigger_active":false}]
  },{ "index":1,"pin":17,"name":"Pixel OUT 2","pixels":30,"color_order":"BRG","zones":["... corresponding five zone objects ..."] }]
}
```

## POST `/api/v1/outputs`
Send a complete replacement configuration for **one** existing output. No partial patch. Strictly validates names, two physical indices (0 or 1), pixels (5–30), valid color order, **exactly five zones**, zone length (>=1) and sum equal to output active pixel count. Rejects writes when actual or simulated inputs, demo, or Show Mode are active. On NVS write failure, the RAM configuration is not modified.

```json
{
  "index":0,"name":"Front DRL","pixels":30,"color_order":"GRB",
  "zones":[
    {"name":"DRL A","pixels":6,"role":"parking"},
    {"name":"Signal","pixels":6,"role":"left_turn"},
    {"name":"Accent","pixels":6,"role":"decorative"},
    {"name":"Aux","pixels":6,"role":"aux1"},
    {"name":"DRL B","pixels":6,"role":"park_brake"}
  ]
}
```

Successful POST responds with the same shape as GET; Studio independently GETs and compares readback before showing Saved. `409 Conflict` means inputs or temporary effects were active; `400 Bad Request` means invalid configuration; `500` means flash save failed.

Legacy `/api/v1/status`, `/api/v1/capabilities`, `/api/v1/show*`, `/api/v1/simulate`, `/api/v1/demo`, `/api/v1/stop`, RGB self-test endpoints remain supported. Legacy `chain` strings (`left`, `right`, `both`) are still API identifiers for compatibility, but Studio labels them Pixel OUT 1/2.
