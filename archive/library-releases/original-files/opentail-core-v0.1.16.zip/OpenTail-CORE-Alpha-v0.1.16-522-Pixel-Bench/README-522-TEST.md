# CORE v0.1.16 — 522-pixel GS400 bench test

- Derived from CORE v0.1.15; two RMT outputs GPIO16 and GPIO17, each allocated 522 physical pixels.
- Saved Output Manager mappings, including the corrected color order, are left intact. A fresh flash should not erase NVS.
- After flashing, open Studio Layout > Universal Output Manager, select Output 1, choose **GS400 main housing · 522**, then **Save to CORE**. Existing color order is preserved by the preset.
- Sections: Top 118; Turn 109; Reverse 42; Bottom 253; Trunk 0. Output 2 remains at its previously saved pixel count until deliberately configured.
- Test at conservative brightness, starting with first 30, then small regions before all 522. Firmware brightness cap 32/255 is NOT a current limiter: the 12V 4A supply is inadequate for unrestricted full-housing illumination. Use properly fused 12V power and injection.
- Direct 3.3V data worked on a short test, but is NOT validated for long runs or road use. No backup or automotive hardware protection.
- Flash command in ESP-IDF terminal: idf.py -p COM9 flash monitor (use actual port). DO NOT erase flash/NVS.
- Source changes are not yet device-tested; do not infer 522 pixels passed from a successful build.
