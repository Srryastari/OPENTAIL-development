# OpenTail Android v0.1.4 — Phone acceptance

1. Install APK update; app opens without overlap with Android status/navigation bars.
2. Header shows OpenTail and Wi-Fi + Bluetooth cards; badge accurately changes between Connected and Offline.
3. **Shows** opens directly and has an inline Wi-Fi/Bluetooth switch; no separate BLE effects dialog.
4. Bluetooth effects: authorize on CORE Wi-Fi, then test Output 2 / Zone 1 with Solid Red and Rainbow briefly at a safe low brightness.
5. With BLE authorized, disable Wi-Fi and repeat a brief effect. BLE should remain usable on offline Studio if GATT remains connected.
6. Re-enable Wi-Fi, select Wi-Fi in Show Modes, verify original CORE Native Effects.
7. Bottom navigation: Home, Shows, Triggers and Layout all reach their existing Studio features.
8. Settings: Wi-Fi connect, scan BLE, authorize, haptics, appearance, advanced Studio connection controls, diagnostics and offline Studio accessible.
9. Confirm haptic taps and automatic Wi-Fi/BLE reconnection still work.
10. Confirm previous output/zone and trigger settings are unchanged.

Note: Bench test only. Brightness slider is not an electrical current limiter.
