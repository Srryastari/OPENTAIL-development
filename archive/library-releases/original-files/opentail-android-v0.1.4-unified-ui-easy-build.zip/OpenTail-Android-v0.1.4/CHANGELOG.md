# Android v0.1.4 — Unified mobile UI

## Added
- Implemented the agreed OpenTail concept as the actual Android screen: OpenTail header, connection status cards, Show Modes with Wi-Fi/BLE switch, and Home/Shows/Triggers/Layout/Settings bottom navigation.
- Unified Settings page for connection tools, native haptics/reconnection, appearance, advanced Studio and Diagnostics.
- Runtime connection badge reflects verified Wi-Fi and BLE connection state.
- Offline Studio fallback after CORE Wi-Fi loss so BLE page remains accessible.

## Changed
- Removed duplicate native connection button rows and old native header.
- BLE controls prioritize Output/Zone/Effect selectors, then Color/Brightness/Speed and Start/Stop.
- Retained single on-page BLE control; no modal popup.

## Protected functions
- BLE AUTH/SHOW/STOP protocol, firmware cap, Wi-Fi CORE connection, Studio editors, configuration readback, haptics, saved preferences and reconnection.
- No ESP32 firmware or standalone Studio HTM changes.

## Verification
- Static tests: 52/52 passed in release build (re-run after edits for final count).
- Android SDK compilation, install, and real BLE/Wi-Fi testing: pending on device.
