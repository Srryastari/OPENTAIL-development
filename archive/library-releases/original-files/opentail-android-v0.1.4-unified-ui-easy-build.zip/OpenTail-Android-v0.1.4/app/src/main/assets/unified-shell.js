/* OpenTail Android v0.1.4: single-shell mobile UI. Enhances existing Studio without
   replacing its working CORE APIs, settings storage, trigger logic, or BLE GATT path. */
(function () {
  'use strict';
  if (window.__otUnifiedShell || !window.OpenTailNativeApp) return;
  window.__otUnifiedShell = true;

  const ico = {
    home:'<path d="M3 10 12 3l9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    shows:'<path d="m12 2 2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2z"/>',
    triggers:'<path d="m13 2-8 11h7l-1 9 8-12h-7z"/>',
    layout:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1-2 2-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-.9 1.5v.2h-3v-.2a1.6 1.6 0 0 0-.9-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1-2-2 .1-.1a1.6 1.6 0 0 0 .3-1.8A1.6 1.6 0 0 0 6 14H5v-3h1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1 2-2 .1.1a1.6 1.6 0 0 0 1.8.3A1.6 1.6 0 0 0 12 5V4h3v1a1.6 1.6 0 0 0 .9 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1 2 2-.1.1a1.6 1.6 0 0 0-.3 1.8A1.6 1.6 0 0 0 21 11h.5v3H21a1.6 1.6 0 0 0-1.6 1Z"/>',
    wifi:'<path d="M2 9a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8 15a5 5 0 0 1 8 0"/><circle cx="12" cy="19" r="1"/>',
    bluetooth:'<path d="m7 7 10 10-5 4V3l5 4L7 17"/>',
    arrow:'<path d="m9 18 6-6-6-6"/>',
    info:'<circle cx="12" cy="12" r="10"/><path d="M12 10v7M12 7h.01"/>'
  };
  const icon = (key) => `<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ico[key]}</svg>`;
  const html = document.documentElement;
  const style = document.createElement('style');
  style.id = 'ot-android-unified-css';
  style.textContent = `
  html,html[data-ot-theme],body{background:#080d0a!important;color:#eaf4ee!important;color-scheme:dark!important}
  body{margin:0!important;min-width:0;font-family:Roboto,Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
  #app>.shell{padding:9px 14px 110px!important;max-width:960px}
  #app .top,#app nav.tabs,#app nav.bottomnav{display:none!important}
  #app .ot-page-intro{margin-top:4px!important}
  body.ot-show-active #app .ot-page-intro{display:none!important}
  .ot-save-warning{color:#ffc0ad;background:#44241b;padding:9px 12px;border-radius:11px;margin-top:10px;font-size:12px;font-weight:650}
  #app .ot-page-intro h1{font-size:21px!important}
  #app .card{border-radius:17px!important}
  #app main{min-width:0}
  .ot-mobile-header{padding:16px 16px 10px;max-width:960px;margin:auto;position:relative;z-index:1}
  .ot-mobile-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px}
  .ot-mobile-heading h1{font-size:25px;line-height:1.12;letter-spacing:-.7px;margin:0;font-weight:750;color:#effaf1}
  .ot-mobile-heading p{margin:5px 0 0;font-size:11px;color:#9aa89f}
  .ot-connected-badge{border-radius:100px;background:#162a1d;color:#a9ebbd;padding:8px 11px;border:1px solid #315c3e;font-size:11px;font-weight:700;white-space:nowrap}
  .ot-connected-badge.offline{background:#2a261b;color:#e8cca0;border-color:#514930}
  .ot-connection-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .ot-connection-card{appearance:none;display:flex;align-items:center;gap:9px;text-align:left;border:1px solid #2b3730;background:#151d18;color:#e8f2eb;border-radius:15px;padding:13px 11px;min-height:72px;font:inherit;width:100%;cursor:pointer}
  .ot-connection-card:focus-visible,.ot-native-nav button:focus-visible,.ot-quick-action:focus-visible{outline:2px solid #70e597;outline-offset:2px}
  .ot-connection-card svg{color:#71d995;flex-shrink:0;width:23px;height:23px}
  .ot-connection-card[data-active=false] svg{color:#9ca8a1}
  .ot-connection-card strong{display:block;font-size:13px;line-height:1.3}
  .ot-connection-card small{display:block;color:#a1afa6;font-size:11px;margin-top:3px}
  .ot-native-nav{position:fixed;bottom:0;left:0;right:0;z-index:1050;display:flex;justify-content:space-around;align-items:stretch;gap:3px;background:#0c140f;border-top:1px solid #293a30;padding:8px 6px calc(10px + env(safe-area-inset-bottom,0px));box-shadow:0 -8px 24px #0008}
  .ot-native-nav button{appearance:none;flex:1;min-width:0;min-height:52px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:4px;border:0;border-radius:12px;background:transparent;color:#99aca0;font:600 10px/1.15 Roboto,Inter,sans-serif;cursor:pointer}
  .ot-native-nav button[aria-current=page]{background:#1b3023;color:#84e5a9}
  .ot-native-nav button svg{width:21px;height:21px}
  .ot-settings-page{display:none;padding:10px 16px 130px;max-width:960px;margin:auto}
  body.ot-settings-active .ot-settings-page{display:block}
  body.ot-settings-active #app{display:none}
  .ot-settings-page h2{font-size:20px;margin:6px 0 7px}
  .ot-settings-page p{font-size:13px;line-height:1.5;color:#a5b1aa;margin:0 0 19px}
  .ot-settings-group{background:#151d18;border:1px solid #2d3c31;border-radius:17px;overflow:hidden;margin-bottom:14px}
  .ot-quick-action{display:flex;width:100%;background:transparent;color:#e2eee5;text-align:left;padding:17px;border:0;border-bottom:1px solid #2c3a30;font:inherit;align-items:center;justify-content:space-between;gap:12px;min-height:57px;cursor:pointer}
  .ot-quick-action:last-child{border-bottom:0}.ot-quick-action svg{color:#87d99d}
  .ot-settings-help{font-size:12px!important;line-height:1.6!important;padding:2px 3px}
  #ot-ble-inline{margin:7px 0 16px!important}
  #ot-ble-inline .ot-ble-head h2{font-size:19px!important}
  #ot-ble-inline .ot-ble-head p{font-size:11px!important}
  #ot-ble-inline .ot-ble-fields{gap:11px!important}
  #ot-ble-inline .ot-ble-actions button{min-height:50px!important}
  html[data-ot-theme="light"],html[data-ot-theme="light"] body{background:#f6faf7!important;color:#203025!important;color-scheme:light!important}
  html[data-ot-theme="light"] .ot-mobile-heading h1{color:#15261a}
  html[data-ot-theme="light"] .ot-mobile-heading p{color:#5b7061}
  html[data-ot-theme="light"] .ot-connected-badge{background:#e3f4e8;color:#2c7443;border-color:#b8d8c1}
  html[data-ot-theme="light"] .ot-connection-card,html[data-ot-theme="light"] .ot-settings-group{background:#ffffff;color:#17301d;border-color:#d6e3d8}
  html[data-ot-theme="light"] .ot-connection-card small,html[data-ot-theme="light"] .ot-settings-page p{color:#566b5a}
  html[data-ot-theme="light"] .ot-native-nav{background:#f8fbf8;border-color:#cdded0}
  html[data-ot-theme="light"] .ot-native-nav button{color:#526b58}
  html[data-ot-theme="light"] .ot-native-nav button[aria-current=page]{background:#dff4e5;color:#246b3c}
  html[data-ot-theme="light"] .ot-quick-action{color:#23442d;border-color:#d6e3d8}
    @media(min-width:700px){.ot-mobile-header,.ot-settings-page{padding-left:30px;padding-right:30px}#app>.shell{padding-left:30px!important;padding-right:30px!important}.ot-native-nav{max-width:960px;margin:auto;left:0;right:0;border-left:1px solid #293a30;border-right:1px solid #293a30}}
  @media(max-width:350px){.ot-connected-badge{padding:7px}.ot-connection-card{padding:10px 7px;gap:5px}.ot-mobile-heading h1{font-size:22px}}
  `;
  document.head.appendChild(style);
  const header = document.createElement('header');
  header.className = 'ot-mobile-header';
  header.innerHTML = `<div class="ot-mobile-heading"><div><h1>OpenTail</h1><p>Universal automotive lighting · Android v0.1.4</p></div><span class="ot-connected-badge offline" id="ot-connected-badge">Offline</span></div>
    <div id="ot-save-banner" class="ot-save-warning" hidden role="alert">Save failed · Review Studio changes</div><div class="ot-connection-grid"><button type="button" class="ot-connection-card" id="ot-wifi-card" data-active="false" aria-label="Wi-Fi connection settings">${icon('wifi')}<span><strong>Wi-Fi</strong><small id="ot-wifi-text">Not connected</small></span></button>
    <button type="button" class="ot-connection-card" id="ot-ble-card" data-active="false" aria-label="Bluetooth connection settings">${icon('bluetooth')}<span><strong>Bluetooth</strong><small id="ot-ble-text">Not connected</small></span></button></div>`;
  const settings = document.createElement('section');
  settings.className = 'ot-settings-page';
  settings.id = 'ot-unified-settings';
  settings.innerHTML = `<h2>Settings</h2><p>Connections, device preferences and advanced controller tools.</p><div class="ot-settings-group">
    <button class="ot-quick-action" data-ot-native="connect">Connect to CORE over Wi-Fi ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="wifi">Android Wi-Fi settings ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="scan">Find Bluetooth controller ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="authorize">Authorize BLE lighting ${icon('arrow')}</button>
  </div><div class="ot-settings-group">
    <button class="ot-quick-action" data-ot-native="prefs">Haptics and reconnection ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="appearance">Studio appearance ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="diagnostics">Diagnostics ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="advanced">Advanced Studio connection tools ${icon('arrow')}</button>
    <button class="ot-quick-action" data-ot-native="offline">Offline Studio ${icon('arrow')}</button>
  </div><p class="ot-settings-help">Bluetooth lighting is currently BENCH ONLY. Physical lighting triggers override shows. The brightness control is not a current limiter. Keep vehicle road lighting independent of this prototype.</p>`;
  const nav = document.createElement('nav');
  nav.className = 'ot-native-nav';
  nav.setAttribute('aria-label', 'OpenTail main navigation');
  const destinations = [ ['home','Home','home'],['scenes','Shows','shows'],['builder','Triggers','triggers'],['layout','Layout','layout'],['settings','Settings','settings'] ];
  nav.innerHTML = destinations.map(([id,label,ic]) => `<button type="button" data-ot-destination="${id}" aria-current="false">${icon(ic)}<span>${label}</span></button>`).join('');
  document.body.prepend(header);
  document.body.appendChild(settings);
  document.body.appendChild(nav);
  let settingsOpen = false;
  const state = () => {
    try { return JSON.parse(window.OpenTailNativeApp.getState() || '{}'); } catch (_) { return {}; }
  };
  function refresh() {
    const s = state();
    const badge = document.getElementById('ot-connected-badge');
    const wifiText = document.getElementById('ot-wifi-text');
    const bleText = document.getElementById('ot-ble-text');
    const wifiCard = document.getElementById('ot-wifi-card');
    const bleCard = document.getElementById('ot-ble-card');
    const connected = Boolean(s.wifi || s.ble);
    const failure = document.getElementById('ot-save-failure');
    const warning = document.getElementById('ot-save-banner');
    if (warning) warning.hidden = !failure || failure.hidden;
    if (badge) {badge.textContent = connected ? 'Connected' : 'Offline';badge.classList.toggle('offline',!connected);}
    if (wifiText) wifiText.textContent = s.wifi ? 'Connected' : 'Not connected';
    if (bleText) bleText.textContent = s.ble ? (s.bleAuthorized ? 'Ready · Authorized' : 'Connected') : 'Not connected';
    if (wifiCard) wifiCard.dataset.active = String(Boolean(s.wifi));
    if (bleCard) bleCard.dataset.active = String(Boolean(s.ble));
    const activeTab = document.querySelector('.tabs .tab.active');
    let route = settingsOpen ? 'settings' : 'home';
    if (!settingsOpen && activeTab) {
      const text = activeTab.textContent || '';
      if (/Show Modes/i.test(text)) route='scenes';
      else if (/Triggers/i.test(text)) route='builder';
      else if (/Layout/i.test(text)) route='layout';
      else if (/Connect|Diagnostics/i.test(text)) route='settings';
    }
    document.body.classList.toggle('ot-show-active',!settingsOpen && route==='scenes');
    nav.querySelectorAll('button[data-ot-destination]').forEach(el => el.setAttribute('aria-current',el.dataset.otDestination===route?'page':'false'));
  }
  function navigate(target) {
    if (target === 'settings') {settingsOpen=true;document.body.classList.add('ot-settings-active');refresh();return;}
    settingsOpen=false;document.body.classList.remove('ot-settings-active');
    if (typeof window.go === 'function') window.go(target);
    refresh();
    window.scrollTo({top:0,behavior:'instant'});
  }
  document.addEventListener('click', event => {
    const dest = event.target.closest('.ot-native-nav [data-ot-destination]');
    if (dest) {navigate(dest.dataset.otDestination);return;}
    if (event.target.closest('#ot-wifi-card')) {navigate('settings');return;}
    if (event.target.closest('#ot-ble-card')) {navigate('settings');return;}
    const action = event.target.closest('[data-ot-native]');
    if (!action) return;
    const commands={
      connect:'connectWifi',wifi:'wifiSettings',scan:'scanBle',authorize:'authorizeBle',
      prefs:'appSettings',offline:'offlineStudio'
    };
    if (commands[action.dataset.otNative]) {
      window.OpenTailNativeApp[commands[action.dataset.otNative]]();
      if (action.dataset.otNative === 'offline') navigate('home');
      return;
    }
    if (action.dataset.otNative==='appearance' && typeof window.otSetTheme === 'function') window.otSetTheme(document.documentElement.dataset.otTheme==='light'?'dark':'light');
    if (action.dataset.otNative==='diagnostics') navigate('diagnostics');
    if (action.dataset.otNative==='advanced') navigate('device');
  });
  const app = document.getElementById('app');
  if (app) {
    let queued=false;
    new MutationObserver(() => {
      if (queued) return;
      queued=true;
      requestAnimationFrame(() => {queued=false;refresh();});
    }).observe(app,{childList:true,subtree:false});
  }
  window.OpenTailShell = { refresh, navigate };
  refresh();
  // Open directly to the agreed Show Modes design, without clearing saved projects.
  if (typeof window.go === 'function') navigate('scenes');
  setInterval(refresh,2000);
})();
