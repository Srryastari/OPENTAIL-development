/* Source-behavior smoke checks for OpenTail unified shell; not a real Android WebView test. */
const assert = require('assert');
const vm = require('vm');
const fs = require('fs');
const handlers = {};
const calls = [];
const nodes = {};
const emptyClassList = () => ({values: new Set(),add(n){this.values.add(n)}, remove(n){this.values.delete(n)},toggle(n,v){ if(v)this.add(n);else this.remove(n)}});
const body = {classList:emptyClassList(),prepend(node){nodes.header=node},appendChild(node){nodes[node.className]=node}};
const navButtons = ['home','scenes','builder','layout','settings'].map(t=>({dataset:{otDestination:t},setAttribute(k,v){this[k]=v}}));
const statusNodes = {
  'ot-connected-badge':{classList:{toggle(){}},textContent:''},
  'ot-wifi-text':{textContent:''},'ot-ble-text':{textContent:''},
  'ot-wifi-card':{dataset:{}},'ot-ble-card':{dataset:{}},
  'ot-save-banner':{hidden:true}
};
let currentPage='home';
const document = {
  documentElement:{},head:{appendChild(){}},body,
  createElement(name){return {className:'',innerHTML:'',id:'',classList:emptyClassList(),setAttribute(){},querySelectorAll(sel){return name==='nav'?navButtons:[]}}},
  getElementById(id){return id==='app'?{}:statusNodes[id]||null},
  querySelector(sel){return sel==='.tabs .tab.active'?{textContent:{home:'Dashboard',scenes:'Show Modes',builder:'Triggers',layout:'Layout',diagnostics:'Diagnostics',device:'Connect'}[currentPage]}:null},
  addEventListener(type,handler){handlers[type]=handler}
};
const native = {
  getState(){return JSON.stringify({wifi:true,ble:true,bleAuthorized:true})},
  connectWifi(){calls.push('connectWifi')},wifiSettings(){calls.push('wifiSettings')},
  scanBle(){calls.push('scanBle')},authorizeBle(){calls.push('authorizeBle')},
  appSettings(){calls.push('appSettings')},offlineStudio(){calls.push('offlineStudio')}
};
const context = {document,window:{OpenTailNativeApp:native,go(page){currentPage=page;calls.push('go:'+page)},scrollTo(){}},MutationObserver:class {observe(){}},requestAnimationFrame(fn){fn()},setInterval(){}};
vm.createContext(context);
vm.runInContext(fs.readFileSync('app/src/main/assets/unified-shell.js','utf8'),context);
assert(nodes.header.innerHTML.includes('<h1>OpenTail</h1>'));
assert(nodes.header.innerHTML.includes('Bluetooth'));
assert(nodes['ot-native-nav'].innerHTML.includes('Settings'));
assert(calls.includes('go:scenes'),'default Show Modes view');
assert.strictEqual(statusNodes['ot-connected-badge'].textContent,'Connected');
assert.strictEqual(statusNodes['ot-ble-text'].textContent,'Ready · Authorized');
function click(target){handlers.click({target:{closest(selector){if(target.selector===selector)return target.node;return null}}})}
click({selector:'.ot-native-nav [data-ot-destination]',node:{dataset:{otDestination:'settings'}}});
assert(body.classList.values.has('ot-settings-active'));
click({selector:'[data-ot-native]',node:{dataset:{otNative:'scan'}}});
assert(calls.includes('scanBle'));
click({selector:'.ot-native-nav [data-ot-destination]',node:{dataset:{otDestination:'builder'}}});
assert(!body.classList.values.has('ot-settings-active'));
assert(calls.includes('go:builder'));
console.log('PASS: Unified header, transport cards, Shows default, Settings, BLE scan and Triggers route.');
