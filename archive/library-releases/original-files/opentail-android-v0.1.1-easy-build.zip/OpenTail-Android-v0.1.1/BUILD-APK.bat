@echo off
setlocal
cd /d "%~dp0"
echo.
echo ==========================================
echo   OpenTail Android v0.1.1 - APK Builder
echo ==========================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-APK.ps1"
if errorlevel 1 (
  echo.
  echo Build did not finish. Copy the error shown above.
) else (
  echo.
  echo Build finished. APK location shown above.
)
echo.
pause
