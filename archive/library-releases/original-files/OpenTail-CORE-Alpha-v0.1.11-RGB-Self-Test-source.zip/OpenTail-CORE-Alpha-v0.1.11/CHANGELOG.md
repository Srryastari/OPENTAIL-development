## CORE Alpha v0.1.11 — Onboard RGB self-test (bench only)

- Added standalone `http://192.168.4.1/status-self-test` page; kept regular Studio UI and Diagnostics unchanged (Studio v0.19.38).
- Rainbow (1.4s fluid color cycle) and simulated fault flashes (90ms ON/OFF) each play on the **onboard RGB only** for a fixed maximum of 5 seconds. Stop restores normal automatic status immediately.
- Automatic timeout, real-fault precedence, board LED availability check, and explicit `self_test_active` reporting.
- No actual fault is generated; no output to WS2815 strips, no safety state change, no native Show Mode activation.
- API: POST `/api/v1/status-led/self-test` with `{"mode":"rainbow"}`, `{"mode":"fault"}`, or `{"mode":"stop"}`. GET `/api/v1/status-led` returns temporary self-test metadata.
- Main firmware `0.1.11-alpha`. Actual on-device ESP-IDF compilation and flash still require user validation.

# Color correction addendum — CORE v0.1.10 / Studio v0.19.38

- Replaced pastel status RGB mixes with saturated blue/green/red values, and pure hue-wheel stops for Show Mode. Fixed brightness still 65%.
- No status timings, GPIO assignment, feature support or LED-strip output logic changed.
- Updated the small Studio Diagnostics color indicators only (no UI redesign).
- Color order (GRB) is unchanged pending on-board verification. Hardware testing outstanding.

---

# OpenTail CORE Alpha v0.1.10 / Studio v0.19.38

- Recolored the Wi-Fi-ready onboard RGB status pulse to electric blue `#1673FF` (RGB 22,115,255) from cyan; 1.0-second timing unchanged.
- Updated Studio status labels. No changes to the approved UI or other RGB status patterns.
- Added host assertions for the blue channel and preserved timing.
- Bench-only source; requires ESP-IDF build and physical validation.

---

# CORE Alpha v0.1.10 / Studio v0.19.38 — Simplified automatic RGB status LED

- Removed status LED brightness slider and enable/disable control from Studio Diagnostics (both themes, CORE/WLED UI unchanged elsewhere).
- Onboard RGB operates automatically at **fixed 65% brightness** as defined in firmware. Previous alpha NVS settings are ignored; no status-LED setting persists.
- Read-only `GET /api/v1/status-led`, nested `/api/v1/status`, and Studio session heartbeat remain. The old `POST /api/v1/status-led` setting endpoint was removed and capabilities now report `status_led_control:false`.
- Preserved 300ms white startup flash, 1s blue pulse, double green/red connection pulses, 1.4s rainbow renderer, and continuous 90ms fault warning.
- Source release only: needs a real ESP-IDF compile, flash, and onboard GPIO48/LED verification. Bench-only; no road-lighting failover.

---

# CORE Alpha v0.1.8 / Studio v0.19.36 — Onboard RGB status light

- Added GPIO48 (provisional; board-specific) WS2812 status LED over SPI2 to avoid reintroducing RMT allocation failures.
- Added white startup flash, 1.0 s blue Wi-Fi pulse, green connected / red disconnected double pulse, 1.4 s rainbow show state renderer, and continuous 90 ms ON / 90 ms OFF red fault indication.
- Explicit Studio session heartbeat; a simple Wi-Fi client association is not treated as Studio connection.
- Uses a fixed firmware brightness (65%) and automatic operation; prior NVS user settings are ignored.
- Added compact read-only Diagnostics status; no brightness, enable/disable, or animated preview controls. Existing OLED/white themes retained.
- Added `/api/v1/status-led`, `/api/v1/status-led/session`, nested status and capabilities detection.
- External RMT init error now sets fault state and keeps Wi-Fi/diagnostics available when possible, instead of aborting.
- Show Mode LED visual logic exists but does not become active until the future native CORE Show Modes engine calls its state hook.
- Host tests verify timing and RGB outputs. Firmware not ESP-IDF-compiled or hardware-tested here.

---

## v0.1.7 — Unified appearance settings (bench only)
- Bundles OpenTail Studio v0.19.35 with a pure-black/white UI theme switch and chat-preview-style segmented controls.
- Keeps exactly the same pill-shaped LED preview design and existing CORE/WLED capabilities; adds honest mode selector and editable slider values.
- Theme choice persists in each browser's local storage (not across devices).
- No physical LED engine, vehicle-safety protection, failover or CORE API changes. Firmware compile/flash still requires ESP-IDF on user's PC.

## v0.1.7 — Studio simulation preview (bench only)
- Embeds OpenTail Studio v0.19.35 with the approved pill-shaped strips and local motion preview.
- Adds offline effect/sequence/trigger preview with clear SIMULATED labels, no device commands.
- Preserves read-only WLED Peek frames as LIVE where available.
- No physical LED-engine, failover or CORE API changes. No physical ESP32-S3 build/flash performed in this environment.

## v0.1.7 — OLED black Studio UI asset (bench only)
- Embeds OpenTail Studio v0.19.35 with pure-black background and very dark panels.
- Replaces gray card sheets with near-black surfaces, understated borders and crisp white text.
- No CORE API, firmware pixel engine or supported behavior changes from v0.1.4.
- Source has not been built or flashed onto physical hardware here.

## v0.1.7 — Black UI theme asset (bench only)
- Embeds OpenTail Studio v0.19.35 with pure black background and neutral charcoal panels.
- Green retained only as an accent for active, connected and primary states.
- All existing navigation, UI behaviors, controller logic and API preserved from v0.1.3.
- Source not compiled or flashed to physical hardware here.

## v0.1.7 — Unified Studio UI asset (source release, bench only)
- Embeds OpenTail Studio v0.19.35 with polished, shared chat-preview-inspired design.
- Same six-tab editor for WLED and CORE connection modes; CORE execution limitations remain explicit.
- Firmware logic, GPIO assignments, API, LED outputs and safety behavior unchanged from v0.1.2.
- Source not compiled or hardware-flashed in this environment.

# OpenTail CORE Alpha Changelog

## v0.1.2 — Restore existing OpenTail Studio workspace in CORE mode (source release)
- Embedded OpenTail Studio v0.19.30; established Dashboard, Show Modes, Triggers, Layout, Connect and Diagnostics visible in CORE mode.
- Universal Effect Editor modal available for local authoring in CORE mode.
- On-screen separation of local project editing from live CORE bench commands.
- WLED-only REST requests blocked in CORE mode; no fake CORE animation support.
- Firmware network and LED control logic unchanged from the user-flashed v0.1.1 except version metadata and embedded Studio asset.
- Requires compilation/flash on physical ESP32-S3; not hardware tested.

# OpenTail CORE Alpha Changelog

## v0.1.1 — Studio bridge (source release)
- Embed OpenTail Studio v0.19.29 as gzip HTML on GET `/studio`, retaining the previous minimal homepage on `/`.
- Add Studio CORE API adapter; same-origin capability discovery, status, temporary demos/input tests, stop, automatic refresh.
- Use DMA for first LED channel, standard RMT for second, reflecting the successful v0.1.0 user hardware fix.
- Preserve previous 8-input / 2-output / bench-only firmware API and all existing safety limitations.
- NOT yet ESP-IDF compiled or hardware flashed/tested; source/static/host tests only.

## v0.1.0 — Initial source release
- Two WS2815 LED outputs; simulated/physical vehicle inputs; temporary demo HTTP API and stand-alone AP test page.
- First Windows ESP-IDF build and real ESP32-S3 boot confirmed by user; the initial DMA allocation caused a reboot loop until adjusted.
