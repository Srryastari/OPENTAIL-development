/* OpenTail CORE Alpha 0.1.11 — bench-only prototype, NOT vehicle lighting firmware.
 * ESP-IDF 5.5.x, ESP32-S3, 2x WS2815-compatible 800kHz RMT outputs.
 * No watchdog, fail-safe, independent backup or OEM-bulb fallback. Do not drive on road.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "cJSON.h"
#include "led_strip.h"
#include "led_strip_rmt.h"
#include "board_config.h"
#include "status_led.h"

#define OT_FW "0.1.11-alpha"
#define OT_AP_SSID "OpenTail-CORE-Alpha"
static const char *TAG="OPENTAIL";
static const gpio_num_t input_pin[OT_IN_COUNT]=OT_INPUT_GPIO_LIST;
static const gpio_num_t out_pin[OT_CHAIN_COUNT]={OT_OUT_LEFT_GPIO,OT_OUT_RIGHT_GPIO};
static led_strip_handle_t strip[OT_CHAIN_COUNT]={0};
static const ot_layout_t layout={OT_LAYOUT_SECTIONS,OT_CHAIN_PIXELS,OT_MAX_BRIGHTNESS};
static ot_inputs_t inputs={0};

static portMUX_TYPE state_lock=portMUX_INITIALIZER_UNLOCKED;
static uint8_t live_input_mask=0;
static uint8_t sim_mask=0;
static TickType_t sim_deadline=0;
static ot_demo_t demo={OT_DEMO_OFF,{0,0,0},0};
static TickType_t demo_deadline=0;
static uint32_t frame_index=0;

static bool before_deadline(TickType_t now,TickType_t deadline) {
    return (int32_t)(deadline-now)>0;
}
static unsigned bounded_int(const cJSON *o,const char *key,int def,int low,int high) {
    cJSON *value=cJSON_GetObjectItemCaseSensitive((cJSON *)o,key);
    if(!cJSON_IsNumber(value)) return (unsigned)def;
    int n=value->valueint;
    return (unsigned)(n<low?low:n>high?high:n);
}
static int recv_json(httpd_req_t *req,cJSON **result) {
    if(req->content_len<2 || req->content_len>512) return 400;
    char buf[513]; int len=0;
    while(len<req->content_len) {
        int n=httpd_req_recv(req,buf+len,req->content_len-len);
        if(n<=0) return 408;
        len+=n;
    }
    buf[len]=0;
    *result=cJSON_ParseWithLength(buf,(size_t)len);
    return cJSON_IsObject(*result)?200:400;
}
static esp_err_t send_json(httpd_req_t *r,const char *body) {
    httpd_resp_set_type(r,"application/json; charset=utf-8");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_sendstr(r,body);
}
static esp_err_t respond_err(httpd_req_t *r,int status,const char *reason) {
    httpd_resp_set_status(r,status==409?"409 Conflict":status==408?"408 Request Timeout":"400 Bad Request");
    char buf[120];snprintf(buf,sizeof(buf),"{\"error\":\"%s\"}",reason);
    return send_json(r,buf);
}
static uint8_t signal_mask_of(const char *name) {
    if(!strcmp(name,"park")) return OT_SIG_PARK;
    if(!strcmp(name,"brake")) return OT_SIG_BRAKE;
    if(!strcmp(name,"left")) return OT_SIG_LEFT;
    if(!strcmp(name,"right")) return OT_SIG_RIGHT;
    if(!strcmp(name,"reverse")) return OT_SIG_REVERSE;
    return 0;
}
static esp_err_t status_get(httpd_req_t *r) {
    TickType_t now=xTaskGetTickCount();
    uint8_t physical,sim;bool sim_active,demo_active;ot_demo_mode_t mode;uint32_t frames;
    portENTER_CRITICAL(&state_lock);
    physical=live_input_mask;
    sim_active=before_deadline(now,sim_deadline);
    sim=sim_active?sim_mask:0;
    demo_active=before_deadline(now,demo_deadline);
    mode=demo_active?demo.mode:OT_DEMO_OFF;
    frames=frame_index;
    portEXIT_CRITICAL(&state_lock);
    char buf[768];char led_json[384];ot_st_format_json(led_json,sizeof(led_json));
    snprintf(buf,sizeof(buf),"{\"name\":\"OpenTail CORE Alpha\",\"version\":\"%s\",\"bench_only\":true,\"hardware_failover\":false,\"mode\":\"%s\",\"input_mask\":%u,\"simulated_mask\":%u,\"effective_mask\":%u,\"demo_active\":%s,\"frames\":%lu,\"leds_per_chain\":%u,\"brightness_cap\":%u,\"status_led\":%s}",
       OT_FW,OT_SMALL_BENCH_LAYOUT?"30-pixel-bench":"gs400-623-provisional",
       (unsigned)physical,(unsigned)sim,(unsigned)(physical|sim),mode==OT_DEMO_OFF?"false":"true",
       (unsigned long)frames,(unsigned)layout.chain_pixels,(unsigned)layout.brightness_cap,led_json);
    return send_json(r,buf);
}
static esp_err_t caps_get(httpd_req_t *r) {
    return send_json(r,"{\"protocol\":\"opentail-core-alpha-v1\",\"bench_only\":true,\"pixel_protocol\":\"WS2815-compatible RMT 800kHz\",\"color_order\":\"BRG\",\"outputs\":2,\"physical_inputs\":8,\"active_functions\":[\"park\",\"brake\",\"left\",\"right\",\"reverse\"],\"reserved_inputs\":[6,7,8],\"wifi\":\"WPA2 Access Point\",\"bluetooth\":false,\"firmware_sequences\":false,\"studio_wled_api_compatible\":false,\"hardware_failover\":false,\"status_led\":true,\"status_led_control\":false}");
}
static esp_err_t status_led_get(httpd_req_t *r){
    char buf[384];ot_st_format_json(buf,sizeof(buf));return send_json(r,buf);
}
/* Fixed-duration, strictly onboard RGB self-test; never touches external WS2815 outputs. */
static esp_err_t status_self_test_post(httpd_req_t *r){
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    const cJSON *v=cJSON_GetObjectItemCaseSensitive(obj,"mode");
    const char *mode=cJSON_IsString(v)?v->valuestring:"";
    ot_st_mode_t test=OT_ST_OFF;
    if(!strcmp(mode,"rainbow"))test=OT_ST_SHOW;
    else if(!strcmp(mode,"fault"))test=OT_ST_FAULT;
    else if(strcmp(mode,"stop")){cJSON_Delete(obj);return respond_err(r,400,"mode must be rainbow, fault or stop");}
    cJSON_Delete(obj);
    if(!ot_st_self_test(test))return respond_err(r,409,"self test unavailable or real fault active");
    return send_json(r,test==OT_ST_OFF?
        "{\"ok\":true,\"self_test_active\":false,\"message\":\"normal status restored\"}":
        "{\"ok\":true,\"self_test_active\":true,\"duration_ms\":5000,\"message\":\"onboard RGB only; no real fault or show started\"}");
}
static const char status_self_test_page[]=
"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>OpenTail RGB Self-Test</title><style>body{background:#000;color:#fff;font:15px system-ui,sans-serif;max-width:560px;margin:auto;padding:24px}"
".card{border:1px solid #2b2b2b;border-radius:20px;padding:22px}h1{font-size:22px;margin:0 0 8px}p{color:#aaa;line-height:1.6}"
"button{background:#161616;border:1px solid #363636;color:white;border-radius:13px;padding:13px 17px;margin:5px 5px 5px 0;min-height:48px;cursor:pointer}"
"button:disabled{opacity:.5}a{color:#aaa}#info{font-size:13px;color:#ddd;background:#0a0a0a;border-radius:12px;padding:14px;white-space:pre-wrap}</style></head>"
"<body><div class='card'><h1>CORE RGB Self-Test</h1><p>BENCH ONLY. Tests affect only the onboard RGB chip for 5 seconds."
"No physical fault, Show Mode, or external LED output is activated.</p>"
"<button onclick=\"run('rainbow')\">Rainbow · 5s</button>"
"<button onclick=\"run('fault')\">Fault flashes · 5s</button>"
"<button onclick=\"run('stop')\">Stop / Restore</button>"
"<p id='info' role='status' aria-live='polite'>Reading status…</p>"
"<p><a href='/studio'>Back to Studio</a></p></div><script>"
"async function run(mode){try{const res=await fetch('/api/v1/status-led/self-test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode})});"
"const j=await res.json();if(!res.ok)throw Error(j.error||'Request failed');await update()}catch(e){document.getElementById('info').textContent='Error: '+e.message}}"
"async function update(){try{const s=await(await fetch('/api/v1/status-led',{cache:'no-store'})).json();"
"document.getElementById('info').textContent=s.self_test_active?('TEST: '+s.self_test_mode+' · '+(s.self_test_remaining_ms/1000).toFixed(1)+'s remaining')"
":('NORMAL STATUS: '+s.mode+(s.available?'':' (RGB unavailable)'))}catch(e){document.getElementById('info').textContent='Status error: '+e.message}}"
"setInterval(update,300);update()</script></body></html>";
static esp_err_t status_self_test_get(httpd_req_t *r){
    httpd_resp_set_type(r,"text/html; charset=utf-8");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_sendstr(r,status_self_test_page);
}
static esp_err_t status_session_post(httpd_req_t *r){
    cJSON *obj=NULL;int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    const cJSON *active=cJSON_GetObjectItemCaseSensitive(obj,"connected");
    if(!cJSON_IsBool(active)){cJSON_Delete(obj);return respond_err(r,400,"connected must be boolean");}
    ot_st_session(cJSON_IsTrue(active));cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true}");
}
static esp_err_t demo_post(httpd_req_t *r) {
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    cJSON *mode_json=cJSON_GetObjectItemCaseSensitive(obj,"mode");
    const char *str=cJSON_IsString(mode_json)?mode_json->valuestring:"";
    ot_demo_mode_t mode=OT_DEMO_OFF;
    if(!strcmp(str,"solid")) mode=OT_DEMO_SOLID;
    else if(!strcmp(str,"chase")) mode=OT_DEMO_CHASE;
    else if(strcmp(str,"off")){cJSON_Delete(obj);return respond_err(r,400,"mode must be solid, chase or off");}
    unsigned rcol=bounded_int(obj,"r",0,0,255),gcol=bounded_int(obj,"g",0,0,255),bcol=bounded_int(obj,"b",0,0,255);
    unsigned brightness=bounded_int(obj,"brightness",32,0,OT_MAX_BRIGHTNESS);
    unsigned ttl=bounded_int(obj,"ttl_ms",3000,100,OT_DEMO_MAX_MS);
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    demo=(ot_demo_t){mode,{rcol,gcol,bcol},brightness};
    demo_deadline=mode==OT_DEMO_OFF?now:now+pdMS_TO_TICKS(ttl);
    portEXIT_CRITICAL(&state_lock);
    cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true,\"message\":\"temporary demo scheduled; real trigger inputs have priority\"}");
}
static esp_err_t simulate_post(httpd_req_t *r) {
    cJSON *obj=NULL;
    int status=recv_json(r,&obj);
    if(status!=200){cJSON_Delete(obj);return respond_err(r,status,"invalid JSON request");}
    cJSON *arr=cJSON_GetObjectItemCaseSensitive(obj,"signals");
    if(!cJSON_IsArray(arr)){cJSON_Delete(obj);return respond_err(r,400,"signals must be an array");}
    uint8_t mask=0;
    cJSON *v=NULL;
    cJSON_ArrayForEach(v,arr){
       if(!cJSON_IsString(v)||!signal_mask_of(v->valuestring)){
          cJSON_Delete(obj);return respond_err(r,400,"unrecognized signal");
       }
       mask|=signal_mask_of(v->valuestring);
    }
    unsigned ttl=bounded_int(obj,"ttl_ms",2000,100,OT_DEMO_MAX_MS);
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    sim_mask=mask;
    sim_deadline=mask?now+pdMS_TO_TICKS(ttl):now;
    portEXIT_CRITICAL(&state_lock);
    cJSON_Delete(obj);
    return send_json(r,"{\"ok\":true,\"message\":\"temporary isolated bench input simulation scheduled\"}");
}
static esp_err_t stop_post(httpd_req_t *r) {
    TickType_t now=xTaskGetTickCount();
    portENTER_CRITICAL(&state_lock);
    demo.mode=OT_DEMO_OFF;demo_deadline=now;
    sim_mask=0;sim_deadline=now;
    portEXIT_CRITICAL(&state_lock);
    return send_json(r,"{\"ok\":true,\"message\":\"demo and simulation cleared; physical inputs still take precedence\"}");
}
static const char page[]=
"<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
"<title>OpenTail CORE Alpha</title><style>body{background:#0b0f0d;color:#f3fff4;font:16px system-ui;max-width:620px;margin:auto;padding:18px}"
"button{background:#193924;border:1px solid #39ff70;border-radius:12px;color:white;padding:12px;margin:5px;min-height:45px}"
"pre{white-space:pre-wrap;background:#171c19;padding:14px;border-radius:12px}h1{color:#39ff70}small{color:#afb9b1}</style></head><body>"
"<h1>OpenTail CORE Alpha</h1><p>BENCH ONLY - no road lighting or failover</p>"
"<p><a style=\"color:#39ff70;font-weight:bold\" href=\"/studio\">Open OpenTail Studio v0.19.38 →</a></p>"
"<p><a style=\"color:#aaa\" href=\"/status-self-test\">Onboard RGB self-test (bench only) →</a></p>"
"<h3>Inputs (2 second test)</h3><div id=signals></div>"
"<h3>Color demos (3 second test)</h3><div id=colors></div>"
"<p><button onclick=post('/api/v1/stop',{})>STOP DEMO</button></p>"
"<h3>Controller Status</h3><pre id=status>Connecting...</pre><small>OpenTail Alpha uses its own API. Current Studio WLED connection mode is not compatible.</small>"
"<script>async function post(p,b){try{const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});"
"if(!r.ok)alert(await r.text());await refresh()}catch(e){alert(e.message)}}"
"async function refresh(){try{document.getElementById('status').textContent=JSON.stringify(await(await fetch('/api/v1/status')).json(),null,2)}catch(e){document.getElementById('status').textContent=e.message}}"
"for(const n of ['park','brake','left','right','reverse']){let b=document.createElement('button');b.textContent=n;b.onclick=()=>post('/api/v1/simulate',{signals:[n],ttl_ms:2000});document.getElementById('signals').append(b)}"
"for(const [n,c] of Object.entries({Red:[255,0,0],Green:[0,255,0],Blue:[0,0,255],White:[255,255,255]})){let b=document.createElement('button');b.textContent=n;b.onclick=()=>post('/api/v1/demo',{mode:'solid',r:c[0],g:c[1],b:c[2],brightness:24,ttl_ms:3000});document.getElementById('colors').append(b)}"
"setInterval(refresh,1000);refresh()</script></body></html>";
/* OpenTail Studio v0.19.38 is served locally from the CORE access point.
 * Gzip is embedded into the application at compile time; no filesystem or WLED needed.
 * Browser uses same-origin /api/v1/... and does not require broad CORS access. */
extern const uint8_t studio_gz_start[] asm("_binary_studio_htm_gz_start");
extern const uint8_t studio_gz_end[] asm("_binary_studio_htm_gz_end");
static esp_err_t studio_get(httpd_req_t *r) {
    httpd_resp_set_type(r,"text/html; charset=utf-8");
    httpd_resp_set_hdr(r,"Content-Encoding","gzip");
    httpd_resp_set_hdr(r,"Cache-Control","no-store");
    return httpd_resp_send(r,(const char *)studio_gz_start,(ssize_t)(studio_gz_end-studio_gz_start));
}
static esp_err_t root_get(httpd_req_t *r) {httpd_resp_set_type(r,"text/html; charset=utf-8");return httpd_resp_sendstr(r,page);}
static void http_start(void) {
    httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();cfg.max_uri_handlers=14;cfg.stack_size=8192;
    httpd_handle_t server=NULL;
    ESP_ERROR_CHECK(httpd_start(&server,&cfg));
    const httpd_uri_t routes[]={
        {.uri="/",.method=HTTP_GET,.handler=root_get},
        {.uri="/studio",.method=HTTP_GET,.handler=studio_get},
        {.uri="/api/v1/status",.method=HTTP_GET,.handler=status_get},
        {.uri="/api/v1/status-led",.method=HTTP_GET,.handler=status_led_get},
        {.uri="/status-self-test",.method=HTTP_GET,.handler=status_self_test_get},
        {.uri="/api/v1/status-led/self-test",.method=HTTP_POST,.handler=status_self_test_post},
        {.uri="/api/v1/status-led/session",.method=HTTP_POST,.handler=status_session_post},
        {.uri="/api/v1/capabilities",.method=HTTP_GET,.handler=caps_get},
        {.uri="/api/v1/demo",.method=HTTP_POST,.handler=demo_post},
        {.uri="/api/v1/simulate",.method=HTTP_POST,.handler=simulate_post},
        {.uri="/api/v1/stop",.method=HTTP_POST,.handler=stop_post}
    };
    for(size_t i=0;i<sizeof(routes)/sizeof(routes[0]);++i) ESP_ERROR_CHECK(httpd_register_uri_handler(server,&routes[i]));
}
static void wifi_ap_init(void) {
    const char *psk=CONFIG_OPENTAIL_AP_PASSWORD;
    size_t n=strlen(psk);
    if(n<8||n>63){ESP_LOGE(TAG,"AP password must be 8-63 characters");abort();}
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_ap();
    wifi_init_config_t init=WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    wifi_config_t conf={0};
    strncpy((char*)conf.ap.ssid,OT_AP_SSID,sizeof(conf.ap.ssid)-1);
    conf.ap.ssid_len=strlen(OT_AP_SSID);
    strncpy((char*)conf.ap.password,psk,sizeof(conf.ap.password)-1);
    conf.ap.channel=1;
    conf.ap.max_connection=2;
    conf.ap.authmode=WIFI_AUTH_WPA2_PSK;
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP,&conf));
    ESP_ERROR_CHECK(esp_wifi_start());
    ot_st_wifi_ready();
    ESP_LOGW(TAG,"BENCH ONLY: connect to Wi-Fi %s; browse http://192.168.4.1/",OT_AP_SSID);
}
static void input_init(void) {
    for(int i=0;i<OT_IN_COUNT;++i){
        gpio_config_t cfg={.pin_bit_mask=1ULL<<input_pin[i],.mode=GPIO_MODE_INPUT,
                           .pull_up_en=GPIO_PULLUP_ENABLE,.pull_down_en=GPIO_PULLDOWN_DISABLE,
                           .intr_type=GPIO_INTR_DISABLE};
        ESP_ERROR_CHECK(gpio_config(&cfg));
    }
}
static bool strip_init(void) {
    for(int ch=0;ch<OT_CHAIN_COUNT;++ch){
        const led_strip_config_t cfg={
            .strip_gpio_num=out_pin[ch],.max_leds=OT_CHAIN_PIXELS,
            .led_model=LED_MODEL_WS2812, // WS2815 uses compatible nominal 800kHz data; scope verification required.
            .color_component_format={.format={.r_pos=1,.g_pos=2,.b_pos=0,.w_pos=3,.num_components=3}}, // B-R-G
            .flags={.invert_out=false}
        };
        const led_strip_rmt_config_t rmt={
            .clk_src=RMT_CLK_SRC_DEFAULT,.resolution_hz=10000000,.mem_block_symbols=64,
            .flags={.with_dma=(ch==0)}
        };
        esp_err_t e=led_strip_new_rmt_device(&cfg,&rmt,&strip[ch]);
        if(e==ESP_OK)e=led_strip_clear(strip[ch]);
        if(e!=ESP_OK){ESP_LOGE(TAG,"RMT output %d failed: %s",ch,esp_err_to_name(e));
            ot_st_set_fault("external pixel RMT initialization failed");return false;}
    }
    return true;
}
static void led_task(void *p) {
    (void)p;
    unsigned tenth=0;
    while(1){
       bool levels[OT_IN_COUNT];
       for(int i=0;i<OT_IN_COUNT;++i) {
           int pin=gpio_get_level(input_pin[i]);
           levels[i]=OT_INPUT_ACTIVE_LOW?(pin==0):(pin!=0);
       }
       uint8_t physical=ot_debounce(&inputs,levels,OT_DEBOUNCE_TICKS);
       TickType_t now=xTaskGetTickCount();
       ot_demo_t local_demo={0};uint8_t combined=0;
       portENTER_CRITICAL(&state_lock);
       live_input_mask=physical;
       combined=physical;
       if(before_deadline(now,sim_deadline)) combined|=sim_mask;
       if(before_deadline(now,demo_deadline)) local_demo=demo;
       portEXIT_CRITICAL(&state_lock);
       if((tenth++%5)==0){
           for(int ch=0;ch<OT_CHAIN_COUNT;++ch){
               for(unsigned px=0;px<layout.chain_pixels;++px){
                   ot_rgb_t c=ot_pixel_color(&layout,ch,px,combined,&local_demo,frame_index);
                   ESP_ERROR_CHECK(led_strip_set_pixel(strip[ch],px,c.r,c.g,c.b));
               }
               // Only this LED task owns set_pixel/refresh, avoiding data races.
               ESP_ERROR_CHECK(led_strip_refresh(strip[ch]));
           }
           portENTER_CRITICAL(&state_lock); frame_index++; portEXIT_CRITICAL(&state_lock);
       }
       vTaskDelay(pdMS_TO_TICKS(10));
    }
}
void app_main(void) {
    ESP_LOGW(TAG,"CORE %s is BENCH-ONLY. No hardware failover. Do not install as road lights.",OT_FW);
    ESP_ERROR_CHECK(nvs_flash_init());
    if(!ot_layout_valid(&layout)){ESP_LOGE(TAG,"Invalid LED layout");abort();}
    ot_st_init();
    input_init();
    bool outputs_ready=strip_init();
    wifi_ap_init();
    http_start();
    if(outputs_ready){
        BaseType_t created=xTaskCreate(led_task,"ot_led",8192,NULL,8,NULL);
        if(created!=pdPASS){ot_st_set_fault("render task could not start");}
    }else ESP_LOGE(TAG,"Pixel task intentionally disabled; CORE is in BENCH FAULT state");
}
