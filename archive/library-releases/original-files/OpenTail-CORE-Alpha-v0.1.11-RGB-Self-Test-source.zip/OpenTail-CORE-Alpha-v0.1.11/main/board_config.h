#pragma once
#include "core_logic.h"

// Provisional wiring map: verify pin labels on your exact hiBCTR N16R8 before connecting.
#define OT_OUT_LEFT_GPIO 16    // to Pixel Shifter DAT -> D5 -> left WS2815 DI
#define OT_OUT_RIGHT_GPIO 17   // to Pixel Shifter CLK -> C5 -> right WS2815 DI
// 8 digital outputs of a pre-verified 3.3-V-safe, isolated trigger interface.
#define OT_INPUT_GPIO_LIST {4,5,6,7,8,9,10,11}
// Set to 0 if the measured optocoupler output goes 3.3 V HIGH when 12 V is applied.
#define OT_INPUT_ACTIVE_LOW 1

// Small 30-pixel PER CHAIN bench profile by default. DO NOT connect entire car lamps yet.
#define OT_SMALL_BENCH_LAYOUT 1
#if OT_SMALL_BENCH_LAYOUT
#define OT_CHAIN_PIXELS 30
#define OT_LAYOUT_SECTIONS {6,6,6,6,6}
#else
// GS400 example: Top 118, Turn 109, Reverse 42, Bottom 253, Trunk 101 = 623 per side.
// Changing to this does not certify the existing PSU, wiring or thermal conditions.
#define OT_CHAIN_PIXELS 623
#define OT_LAYOUT_SECTIONS {118,109,42,253,101}
#endif
#define OT_MAX_BRIGHTNESS 32 // <= 12.5% channel brightness; not a measured current limiter.
#define OT_DEBOUNCE_TICKS 4 // four 10ms samples
#define OT_DEMO_MAX_MS 10000

// Verify onboard RGB pin on your exact PCB revision (some boards need an RGB solder jumper).
#define OT_STATUS_LED_GPIO 48 // provisional onboard WS2812/NeoPixel; independent SPI2 backend
