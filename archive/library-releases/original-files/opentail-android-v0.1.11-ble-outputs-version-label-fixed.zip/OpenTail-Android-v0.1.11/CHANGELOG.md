# v0.1.11 — BLE Output Manager test build

- Added native BLE Output Manager panel in Layout, including offline Studio.
- Added read/write transfer for both GPIO16/GPIO17 output profiles, multi-zone roles, color order, calibration-preserving save, CRC/readback verification.
- Saved output profiles remain on controller NVS, not in the app.
- Existing v0.1.10 UI, Show Modes BLE commands, haptics, CORE Wi-Fi controls, trigger arbitration preserved.
- Initial BLE control authorization STILL requires Wi-Fi for each BLE connection. Secure BLE-only commissioning is future work.
- Not built with Android SDK or tested with physical device in this environment.
