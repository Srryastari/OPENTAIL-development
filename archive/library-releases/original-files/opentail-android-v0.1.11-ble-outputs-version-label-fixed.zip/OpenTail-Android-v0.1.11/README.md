# OpenTail Android v0.1.11

Approved OLED-black UI implementation and dynamic CORE zone preview. Extract All, run BUILD-APK.bat. Existing CORE firmware v0.1.20 unchanged.

See CHANGELOG.md and QA-RESULTS.txt.

Bench-only: Android APK has not been compiled or hardware-tested in this environment.

## Matching CORE Studio

When connected to CORE Wi-Fi the Android app loads Studio from the ESP32. To obtain the repaired simulated trigger preview on that screen, install matching CORE v0.1.22 (source package separately supplied). Older CORE firmware still serves the older Studio page even when the Android app itself is updated.

## Preview trigger repair
Embedded Studio v0.19.51 aligns simulated trigger colors with saved CORE zone roles. Hardware trigger tests remain independent.


## BLE Output Manager (new in 0.1.11)
Open Layout in the native Android app. The **Bluetooth Output Manager** card is available whether the app displays the local/offline or CORE-hosted Studio. Tap **Find BLE**, **Authorize**, and **Reload Output**. Choose GPIO16 or GPIO17; edit output name, count, BRG/order, and zones/roles. Tap **Save to CORE over BLE**. The app sends 261 bytes in 15-byte write chunks, validates CRC16 and reads the persisted output back before confirming a save. You must first authorize with a Wi-Fi token **for each BLE connection**; then Wi-Fi is not needed during editing. Stop all shows/inputs before saving. This is for bench testing and does not provide production BLE-only pairing, BLE trigger-input mapping, or hardware road-lighting safety. No APK or physical BLE validation is included.
