# OpenTail CORE v0.1.22 / Studio v0.19.51

This is a Studio/zone-preview integration update based on the BLE-capable CORE v0.1.20 source.

- Firmware BLE command protocol, GPIO outputs, trigger logic, NVS mapping and hardware behavior are unchanged.
- `/studio` serves OpenTail Studio v0.19.51, including the same Live Lighting Preview engine and read-only CORE Output Manager zone adapter.
- The preview renders one section per saved nonzero zone on each output. This is visualization only; no SPI/RMT pixel data is inferred.
- No automotive safety/failover certification. Bench-only operation.
- **Before flashing:** preserve the existing CORE AP password with PREPARE-AND-BUILD.ps1, confirm `Project build complete`, use `idf.py -p <actual port> flash` (no erase-flash).
- **Not compiled with ESP-IDF in this environment.** Host regression tests below do not constitute hardware validation.
\n## v0.1.22 preview repair
Local simulated triggers now follow CORE Output Manager zone roles (including parking/brake priority, left/right/hazards and reverse) instead of old WLED-only profile section IDs. No firmware lighting behavior or persistence changed.
