# Build + flash v0.1.22 on Windows (ESP-IDF 5.5.5)

1. Extract the ZIP using **Extract All** into `%USERPROFILE%\Desktop\OpenTail`; do not run builds from within the ZIP.
2. Open your ESP-IDF PowerShell (same one used for v0.1.17/v0.1.18).
3. Run:

```powershell
cd "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.22-Preview-Triggers"
.\PREPARE-AND-BUILD.ps1
```

The script looks for the previously configured v0.1.21/v0.1.20/v0.1.18/v0.1.17 `sdkconfig` and silently copies **only** the Wi-Fi password setting if necessary. It **refuses** to build if a non-default password is not found. It never prints or distributes the password. It does not overwrite the previous project and it does **not** flash automatically.

4. **Only after `Project build complete`:** connect ESP32 on COM9 and run:

```powershell
idf.py -p COM9 flash monitor
```

No `erase-flash`. Ctrl+] quits monitor. If COM9 is in use, close monitors before retrying. Keep v0.1.17/v0.1.18 source for rollback. Test on isolated bench power, low brightness, and no vehicle wiring.
