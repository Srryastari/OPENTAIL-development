# CORE v0.1.22 / Studio v0.19.51

Only embedded Studio refresh and firmware-reported version update. Existing BLE, WS2815 GPIO16/GPIO17 control and saved settings remain source-identical to v0.1.20 except version strings. Studio preview now takes saved CORE output zones rather than the unrelated local WLED layout, retaining the existing Live/Synced/Simulated rendering and section strip styling. No new hardware output capability claimed.
\n## v0.1.22 preview repair
Local simulated triggers now follow CORE Output Manager zone roles (including parking/brake priority, left/right/hazards and reverse) instead of old WLED-only profile section IDs. No firmware lighting behavior or persistence changed.
