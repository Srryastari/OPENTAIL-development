# OpenTail UI v0.1.8: compact monochrome pass

- Compact shell/header, smaller status panels, slimmer BLE effect form controls and range thumbs, shorter cards/navigation.
- True black and neutral greys. Green limited to small connection/ready indicators. Selected controls and primary buttons use neutral greys.
- BLE Show Modes interaction and numeric values retained; Customize still contains RGB color and automatic stop.
- Scope: style-only shell changes plus Customize label. Firmware, BLE commands, haptics, reconnection and configuration persistence are not modified.
- Live Lighting Preview engine, HTML and interaction code is preserved; editor restyling is explicitly scoped away from .ot-preview.
- Simulated rendering and static tests are not equivalent to user-phone testing.
