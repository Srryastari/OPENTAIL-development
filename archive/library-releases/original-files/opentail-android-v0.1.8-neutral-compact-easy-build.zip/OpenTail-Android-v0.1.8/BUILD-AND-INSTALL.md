# Build OpenTail Android v0.1.8

1. Download ZIP, right-click → Extract All.
2. Enter the extracted `OpenTail-Android-v0.1.8` folder.
3. Run `BUILD-APK.bat`; requires Windows Android SDK, JDK 17/21, internet for first dependencies.
4. On success the BAT opens File Explorer with `app/build/outputs/apk/debug/app-debug.apk` selected.
5. Install as an update. Do NOT uninstall current app if signing conflicts; preserve preferences.

This release changes UI chrome/appearance, not CORE firmware. Existing CORE v0.1.20 BLE commands remain in effect. No firmware flash required.

## Expected
A compact, almost monochrome shell; green only on connection/ready status. Live Lighting Preview remains untouched.

## Test boundary
Browser mock and source tests pass. Actual APK compilation/phone testing not performed here.
