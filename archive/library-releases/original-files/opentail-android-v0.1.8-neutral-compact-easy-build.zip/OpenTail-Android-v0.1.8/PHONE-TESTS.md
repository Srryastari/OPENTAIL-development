# Android v0.1.8 — phone acceptance

1. Install updated APK over v0.1.4 (keep saved project).
2. Home: compact controller overview and output cards instead of full Studio dashboard.
3. Shows: Wi-Fi/Bluetooth selector, Output/Zone/Effect, Customize panel and visible Start/Stop; old Studio preview hidden in BLE mode.
4. Start Solid Red and Rainbow on the same previously verified GPIO17 30-LED test strip at low brightness; stop after the test.
5. Triggers: verify eight CORE mappings load; tap Edit assignments, change **no settings** and return using Back.
6. Layout: verify pixel output counts and zones are read from CORE; tap Edit outputs & zones to access the full original CORE editor, including add/delete and save/readback.
7. Settings: Wi-Fi, BLE, haptics, reconnection and Diagnostics work; no duplicate toolbar.
8. Background/reopen: verify previously tested Wi-Fi and BLE reconnection and light haptic feedback remain functional.
9. Check Android system navigation isn't obscuring Start/Stop or settings.

Stop bench effects and ensure adequate fused 12V strip power. Brightness percentage does not limit electrical current.
