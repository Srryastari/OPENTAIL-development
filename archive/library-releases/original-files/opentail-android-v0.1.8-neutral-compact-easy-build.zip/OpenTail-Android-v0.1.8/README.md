# OpenTail Android v0.1.8 — Neutral Compact UI

One-click Windows Android debug APK builder and source project. UI refinements over v0.1.7 remove green tint and bulk without touching Live Lighting Preview. Full BLE lighting command behavior, haptics, Wi-Fi, saved settings, navigation and reconnection paths are retained in source. Build on Windows with `BUILD-APK.bat`.

Automated static and simulated browser tests do not constitute Android hardware validation. See BUILD-AND-INSTALL.md and VISUAL-REFERENCE.md.
