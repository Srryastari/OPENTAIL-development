# OpenTail Android v0.1.8

- Replaced green-tinted overall UI with true black and greys. Green is reserved for connected/ready status.
- Reduced excess vertical padding and heavy field dimensions, while retaining tap targets.
- Compact navigation, cards, buttons and sliders.
- Preserved Live Lighting Preview, BLE output controls, haptics, Wi-Fi and reconnection.
- Paired standalone Studio v0.19.49.
