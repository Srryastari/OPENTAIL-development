# OpenTail Android v0.1.2

- Native Wi-Fi-authorized Bluetooth show controls: effects, output/zone targeting, RGB hex input, brightness cap, speed, 5/15/30/60 second TTL, stop.
- Preserves v0.1.1 haptic settings, automatic BLE and Wi-Fi reconnection, selected controller, off-line Studio, import/export and UI restrictions.
- Includes matching Studio v0.19.47 (same bytes as CORE firmware).
- BLE info read/discovery stays backwards-compatible with v0.1.18/0.1.19; show controls require CORE v0.1.20.
- 29 Android static checks passed before packaging; **not compiled or hardware tested here**.
