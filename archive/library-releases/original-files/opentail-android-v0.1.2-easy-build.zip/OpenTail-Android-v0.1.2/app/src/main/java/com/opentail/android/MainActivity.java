package com.opentail.android;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.SeekBar;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native OpenTail Android shell. Wi-Fi controls use the device's unchanged Studio web app. */
public final class MainActivity extends Activity {
    private static final int PICK_PROJECT = 201;
    private static final int SAVE_PROJECT = 202;
    private static final String OFFLINE_URL = "https://appassets.androidplatform.net/assets/opentail.htm";
    private static final int MAX_EXPORT_CHARS = 2_000_000;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WebView web;
    private WebViewAssetLoader assets;
    private TextView connectionLabel;
    private TextView bleLabel;
    private ValueCallback<Uri[]> uploadCallback;
    private String pendingExport;
    private BleDiscovery ble;
    private boolean coreMode = false;
    private boolean wifiConnectInProgress = false;
    private boolean appReady = false;
    private boolean pageHadError = false;
    private boolean offlineSelected = false;
    private HapticController haptics;
    private SharedPreferences preferences;
    private static final String AUTO_WIFI = "auto_wifi";
    private static final String AUTO_BLE = "auto_ble";
    private static final String USE_CORE = "prefer_core_wifi";

    /** Runs only on allowlisted local Studio pages. No network or controller commands. */
    private static final String STUDIO_HAPTIC_JS = "(function(){"
        + "if(window.__otNativeHaptics)return;window.__otNativeHaptics=true;"
        + "var pendingSave='';var since=0;var scheduled=false;"
        + "document.addEventListener('click',function(e){"
        + "var t=e.target.closest('button,[role=button],input[type=button],input[type=submit]');"
        + "if(t&&!t.disabled){var title=t.textContent||'';"
        + "if(title.includes('Save to CORE')){"
        + "pendingSave=t.closest('.ot-om-card')?'output':(t.closest('.ot-tm-card')?'trigger':'');"
        + "since=Date.now();}window.OpenTailHaptics.feedback('tap');}},true);"
        + "document.addEventListener('change',function(e){"
        + "var t=e.target;if(t.matches('input[type=checkbox],input[type=radio],select'))"
        + "window.OpenTailHaptics.feedback('toggle');else if(t.matches('input[type=range]'))"
        + "window.OpenTailHaptics.feedback('slider');},true);"
        + "new MutationObserver(function(){if(!pendingSave||scheduled)return;scheduled=true;"
        + "setTimeout(function(){scheduled=false;"
        + "if(!pendingSave)return;if(Date.now()-since>15000){pendingSave='';return;}"
        + "var sel=pendingSave==='output'?'#ot-om-message':'.ot-tm-card [role=status]';"
        + "var node=document.querySelector(sel);var x=node?node.textContent||'':'';"
        + "var ok=x.includes('Saved to CORE and verified by device readback.')"
        + "||x.includes('Saved and verified by CORE readback.');"
        + "var fail=x.includes('Save not confirmed:');"
        + "if(ok||fail){window.OpenTailHaptics.feedback(fail?'error':'saved');pendingSave='';}"
        + "},120);"
        + "}).observe(document.body,{childList:true,subtree:true,characterData:true});"
        + "})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(HapticController.PREFS, MODE_PRIVATE);
        haptics = new HapticController(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 19, 16));
        root.setPadding(dp(10), dp(8), dp(10), 0);

        TextView title = new TextView(this);
        title.setText("OPENTAIL  /  ANDROID  v0.1.2");
        title.setTextSize(17);
        title.setTextColor(Color.rgb(100, 227, 139));
        title.setTypeface(null, 1);
        root.addView(title);

        connectionLabel = label("Offline Studio · Device not connected");
        root.addView(connectionLabel);
        bleLabel = label("BLE · Not connected");
        root.addView(bleLabel);

        LinearLayout row1 = row();
        addButton(row1, "Wi-Fi settings", this::openWifiSettings);
        addButton(row1, "Connect CORE", this::connectCore);
        root.addView(row1);

        LinearLayout row2 = row();
        addButton(row2, "Offline Studio", this::openOffline);
        addButton(row2, "Find BLE", () -> ble.scan());
        addButton(row2, "Settings", this::showSettings);
        root.addView(row2);
        LinearLayout row3=row();
        addButton(row3,"Enable BLE lighting",this::enableBleControls);
        addButton(row3,"BLE Show Modes",this::showBleControls);
        root.addView(row3);

        TextView warning = label("BENCH ONLY · BLE shows expire after 60s max · Physical triggers retain priority");
        warning.setTextSize(11);
        warning.setTextColor(Color.rgb(201, 175, 112));
        root.addView(warning);

        assets = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12, 19, 16));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);  // Android document picker import.
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new ProjectExportBridge(), "OpenTailApp");
        web.addJavascriptInterface(new HapticBridge(), "OpenTailHaptics");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (OFFLINE_URL.equals(url.toString())) return assets.shouldInterceptRequest(url);
                if ("192.168.4.1".equals(url.getHost()) && "http".equals(url.getScheme())) return null;
                // No external scripts, sites, analytics or CDN assets are needed by Studio.
                return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (allowedPage(request.getUrl().toString())) return false;
                show("External navigation blocked. Only local OpenTail Studio and CORE are allowed.");
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (OFFLINE_URL.equals(url) && offlineSelected) {
                    coreMode = false;
                    CoreConnection.releaseWifi(MainActivity.this);
                    connectionLabel.setText("Offline Studio v0.19.47 · Local design only, no device sync");
                }
                if (allowedPage(url)) {
                    // Intercept Studio's project export to use Android's user-chosen document picker.
                    view.evaluateJavascript("window.download=function(name,text){window.OpenTailApp.exportJson(String(name),String(text));};", null);
                    view.evaluateJavascript(STUDIO_HAPTIC_JS, null);
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageHadError = true;
                    connectionLabel.setText("Page unavailable · Check controller Wi-Fi and reconnect");
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.setType("application/json");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, PICK_PROJECT);
                    return true;
                } catch (Exception ex) {
                    uploadCallback = null;
                    show("File picker unavailable: " + ex.getMessage());
                    return false;
                }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        ble = new BleDiscovery(this, message -> bleLabel.setText("BLE · " + message));
        ble.setPreferredListener(address -> preferences.edit().putString("preferred_ble_address", address).apply());
        appReady = true;
        openOffline(false);
        if (preferences.getBoolean(USE_CORE, false) && preferences.getBoolean(AUTO_WIFI, true)) {
            // The user must already have joined the CORE Wi-Fi AP using Android settings.
            connectCore(true);
        }
        if (preferences.getBoolean(AUTO_BLE, true)) {
            ble.tryReconnect(preferences.getString("preferred_ble_address", null));
        }
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(12);
        v.setTextColor(Color.rgb(200, 211, 204));
        v.setPadding(0, dp(4), 0, dp(4));
        return v;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private void addButton(LinearLayout row, String title, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title);
        button.setTextSize(12);
        button.setTextColor(Color.rgb(229, 250, 233));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(26, 69, 43)));
        button.setOnClickListener(v -> { haptics.tap(button, "tap"); action.run(); });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(48), 1);
        params.setMargins(dp(2), 0, dp(2), dp(2));
        row.addView(button, params);
    }

    private void openWifiSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_WIFI));
            else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception ex) { show("Open Android Wi-Fi settings and join OpenTail-CORE-Alpha"); }
    }

    private void connectCore() { connectCore(false); }

    private void connectCore(boolean automatic) {
        if (wifiConnectInProgress) return;
        wifiConnectInProgress = true;
        if (!automatic) offlineSelected = false;
        if (!automatic) connectionLabel.setText("Checking OpenTail CORE on 192.168.4.1…");
        io.execute(() -> {
            boolean bound = CoreConnection.bindToWifi(this);
            try {
                if (!bound) throw new Exception("Wi-Fi is not connected; join OpenTail-CORE-Alpha first");
                CoreConnection.verify();
                runOnUiThread(() -> {
                    wifiConnectInProgress = false;
                    if (offlineSelected) { CoreConnection.releaseWifi(this); return; }
                    coreMode = true;
                    preferences.edit().putBoolean(USE_CORE, true).apply();
                    connectionLabel.setText("CORE verified · Wi-Fi Studio · 192.168.4.1");
                    if (pageHadError || !CoreConnection.STUDIO.equals(web.getUrl())) {
                        pageHadError = false;
                        web.loadUrl(CoreConnection.STUDIO);
                    }
                });
            } catch (Exception ex) {
                CoreConnection.releaseWifi(this);
                runOnUiThread(() -> {
                    wifiConnectInProgress = false;
                    coreMode = false;
                    if (!automatic) {
                        connectionLabel.setText("CORE not reachable · Check Wi-Fi settings");
                        show(ex.getMessage());
                    }
                });
            }
        });
    }

    private void openOffline() { openOffline(true); }
    private void openOffline(boolean selectedByUser) {
        if (selectedByUser) {
            offlineSelected = true;
            preferences.edit().putBoolean(USE_CORE, false).apply();
        }
        coreMode = false;
        CoreConnection.releaseWifi(this);
        connectionLabel.setText("Offline Studio v0.19.47 · Local design only, no device sync");
        if (!OFFLINE_URL.equals(web.getUrl())) web.loadUrl(OFFLINE_URL);
    }

    /** Obtain a fresh authorization using the already verified WPA2 Wi-Fi AP. */
    private void enableBleControls(){
        if (ble == null) return;
        bleLabel.setText("BLE · Obtaining temporary bench authorization from CORE Wi-Fi…");
        io.execute(() -> {
            try {
                if(!CoreConnection.bindToWifi(this))throw new Exception("Join OpenTail-CORE-Alpha Wi-Fi first");
                CoreConnection.verify();
                String token=CoreConnection.bleSessionToken();
                runOnUiThread(() -> ble.authorize(token));
            }catch(Exception ex){
                runOnUiThread(() -> {
                    bleLabel.setText("BLE · Authorization unavailable");
                    show(ex.getMessage());
                });
            }
        });
    }

    /** Dedicated native BLE controls: never changes vehicle triggers or saved zone maps. */
    private void showBleControls(){
        if(ble==null)return;
        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView note=label("BENCH ONLY · Authorize over CORE Wi-Fi first, then BLE Show Modes work with Wi-Fi off. Physical triggers override shows. Brightness is NOT electrical current limiting.");
        controls.addView(note);
        Spinner effect=new Spinner(this);
        effect.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Solid","Chase","Breathe","Wipe","Rainbow"}));
        controls.addView(label("Native effect"));controls.addView(effect);
        Spinner output=new Spinner(this);
        output.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Output 1 (GPIO16)","Output 2 (GPIO17)","Both"}));
        controls.addView(label("Pixel output"));controls.addView(output);
        Spinner zone=new Spinner(this);
        zone.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Zone 1","Zone 2","Zone 3","Zone 4","Zone 5","Zone 6","Zone 7","Zone 8","All zones"}));
        controls.addView(label("Zone (uses saved CORE output mapping)"));controls.addView(zone);
        EditText color=new EditText(this);
        color.setSingleLine(true);color.setText("#FF0000");color.setHint("#RRGGBB");
        controls.addView(label("RGB color, e.g. #FFAA00"));controls.addView(color);
        SeekBar brightness=new SeekBar(this);brightness.setMax(32);brightness.setProgress(6);
        TextView brightLabel=label("Brightness: 6 / 32 (firmware cap; start low)");
        brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int n,boolean user){brightLabel.setText("Brightness: "+n+" / 32");}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){haptics.tap(b,"slider");}
        });
        controls.addView(brightLabel);controls.addView(brightness);
        SeekBar speed=new SeekBar(this);speed.setMax(100);speed.setProgress(50);
        TextView speedLabel=label("Speed: 50 / 100");
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int n,boolean user){speedLabel.setText("Speed: "+n+" / 100");}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
        controls.addView(speedLabel);controls.addView(speed);
        Spinner ttl=new Spinner(this);
        ttl.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"5 seconds","15 seconds","30 seconds","60 seconds"}));
        ttl.setSelection(1);
        controls.addView(label("Automatic stop"));controls.addView(ttl);
        android.widget.ScrollView scroll=new android.widget.ScrollView(this);scroll.addView(controls);
        new AlertDialog.Builder(this).setTitle("OpenTail · Bluetooth Show Modes")
            .setView(scroll).setNeutralButton("STOP",(d,w)->ble.stopShow())
            .setNegativeButton("Cancel",null)
            .setPositiveButton("START",(d,w)->{
                String hex=color.getText().toString().trim();
                if(!hex.matches("#[0-9A-Fa-f]{6}")){show("Use a six-digit RGB color such as #FFAA00");return;}
                int rgb=Integer.parseInt(hex.substring(1),16);
                int mask=zone.getSelectedItemPosition()==8?255:(1<<zone.getSelectedItemPosition());
                int chain=output.getSelectedItemPosition()==2?3:output.getSelectedItemPosition()+1;
                int duration=new int[]{5,15,30,60}[ttl.getSelectedItemPosition()];
                ble.show(effect.getSelectedItemPosition()+1,chain,mask,(rgb>>16)&255,(rgb>>8)&255,rgb&255,
                    brightness.getProgress(),speed.getProgress(),duration);
                haptics.tap(web,"tap");
            }).show();
    }

    private void showSettings() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), dp(4));
        CheckBox hapticToggle = new CheckBox(this);
        hapticToggle.setText("Enable haptic feedback");
        hapticToggle.setChecked(haptics.enabled());
        content.addView(hapticToggle);
        TextView title = label("Haptic intensity");
        content.addView(title);
        Spinner intensity = new Spinner(this);
        intensity.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Light", "Medium", "Strong"}));
        intensity.setSelection(haptics.strength());
        content.addView(intensity);
        CheckBox slider = new CheckBox(this);
        slider.setText("Slider feedback (on release)");
        slider.setChecked(haptics.sliderEnabled());
        content.addView(slider);
        CheckBox wifi = new CheckBox(this);
        wifi.setText("Reconnect Wi-Fi Studio when available");
        wifi.setChecked(preferences.getBoolean(AUTO_WIFI, true));
        content.addView(wifi);
        CheckBox bt = new CheckBox(this);
        bt.setText("Reconnect preferred BLE controller");
        bt.setChecked(preferences.getBoolean(AUTO_BLE, true));
        content.addView(bt);
        TextView note = label("BLE show controls require one Wi-Fi authorization per BLE connection. Trigger/config changes stay on Wi-Fi.");
        content.addView(note);
        new AlertDialog.Builder(this).setTitle("OpenTail Android settings")
                .setView(content).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    haptics.configure(hapticToggle.isChecked(), intensity.getSelectedItemPosition(), slider.isChecked());
                    preferences.edit().putBoolean(AUTO_WIFI, wifi.isChecked())
                            .putBoolean(AUTO_BLE, bt.isChecked()).apply();
                    haptics.tap(web, "saved");
                }).show();
    }

    private final class HapticBridge {
        @JavascriptInterface public void feedback(String kind) {
            runOnUiThread(() -> {
                if (web != null && allowedPage(web.getUrl())) {
                    if ("tap".equals(kind) || "toggle".equals(kind) || "slider".equals(kind)
                            || "saved".equals(kind) || "error".equals(kind)) {
                        haptics.tap(web, kind);
                    }
                }
            });
        }
    }

    private static boolean allowedPage(String url) {
        return OFFLINE_URL.equals(url)
                || CoreConnection.STUDIO.equals(url)
                || (CoreConnection.ORIGIN + "/").equals(url)
                || "about:blank".equals(url);
    }

    /** Export bridge is only enabled on the two allowlisted Studio origins. */
    private final class ProjectExportBridge {
        @JavascriptInterface public void exportJson(String proposedName, String json) {
            runOnUiThread(() -> {
                if (web == null || !allowedPage(web.getUrl())) return;
                if (json == null || json.length() > MAX_EXPORT_CHARS) {
                    show("Project too large to export");
                    return;
                }
                pendingExport = json;
                String safe = proposedName == null ? "opentail-project.json"
                        : proposedName.replaceAll("[^A-Za-z0-9_.-]", "_");
                if (!safe.endsWith(".json")) safe += ".json";
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.setType("application/json");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_TITLE, safe);
                try { startActivityForResult(intent, SAVE_PROJECT); }
                catch (Exception ex) { show("Save picker unavailable"); pendingExport = null; }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PROJECT) {
            ValueCallback<Uri[]> callback = uploadCallback;
            uploadCallback = null;
            if (callback != null) callback.onReceiveValue(resultCode == RESULT_OK && data != null && data.getData() != null
                    ? new Uri[]{data.getData()} : null);
        } else if (requestCode == SAVE_PROJECT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new Exception("Destination not writable");
                    out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    show("Project exported to your chosen location");
                } catch (Exception ex) { show("Export failed: " + ex.getMessage()); }
            }
            pendingExport = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (ble != null) ble.handlePermissions(requestCode, results);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!appReady) return;
        if (preferences.getBoolean(AUTO_WIFI, true) && preferences.getBoolean(USE_CORE, false)
                && !offlineSelected) connectCore(true);
        if (preferences.getBoolean(AUTO_BLE, true) && ble != null) {
            ble.tryReconnect(preferences.getString("preferred_ble_address", null));
        }
    }

    @Override protected void onStop() {
        super.onStop();
        if (ble != null) ble.stopScan();
    }

    @Override protected void onDestroy() {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        if (ble != null) ble.shutdown();
        io.shutdownNow();
        CoreConnection.releaseWifi(this);
        if (web != null) { web.removeJavascriptInterface("OpenTailApp"); web.removeJavascriptInterface("OpenTailHaptics"); web.destroy(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void show(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private int dp(int px) { return Math.round(px * getResources().getDisplayMetrics().density); }
}
