package com.opentail.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import java.nio.charset.StandardCharsets;
import android.bluetooth.BluetoothStatusCodes;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** BLE discovery and temporary, Wi-Fi-authorized BENCH SHOW commands. Triggers cannot be changed here. */
final class BleDiscovery {
    interface StatusListener { void onStatus(String message); }
    // ESP-IDF NimBLE BLE_UUID128_INIT uses little-endian byte order.
    private static final UUID SERVICE_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf21");
    private static final UUID INFO_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf22");
    private static final UUID COMMAND_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf23");
    private static final UUID REPLY_UUID = UUID.fromString("55a56022-4915-7a92-cf44-b8b7102eaf24");
    private static final int REQUEST_NEARBY = 137;
    private static final long SCAN_DURATION_MS = 10000L;

    private final Activity activity;
    private final StatusListener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final ArrayList<String> labels = new ArrayList<>();
    private final ArrayAdapter<String> entries;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private AlertDialog scanDialog;
    private boolean scanning;
    private boolean stopped;
    private boolean connected = false;
    private boolean connecting = false;
    private BluetoothGattCharacteristic command;
    private BluetoothGattCharacteristic reply;
    private volatile boolean authorized = false;
    private boolean authPending = false;
    private boolean writePending = false;
    private boolean readReplyPending = false;
    private byte[] pendingPacket;
    private byte[] nextPacket;

    boolean canControl() { return connected && authorized && command != null; }

    /** Token must come from the paired phone's Wi-Fi connection to CORE; never persist it. */
    void authorize(String tokenHex) {
        if (!connected || command == null || reply == null) {
            notifyStatus("Connect OpenTail BLE before authorizing lighting controls"); return;
        }
        if (tokenHex == null || !tokenHex.matches("[a-fA-F0-9]{32}")) {
            notifyStatus("Invalid CORE BLE authorization token");return;
        }
        byte[] packet = new byte[18];packet[0]=1;packet[1]=1;
        for(int i=0;i<16;i++)packet[i+2]=(byte)Integer.parseInt(tokenHex.substring(2*i,2*i+2),16);
        authorized=false;
        authPending=true;
        enqueueWrite(packet);
    }

    /** Only native bench effects. TTL is 1..60 seconds; trigger priority remains in CORE. */
    void show(int effect,int chainMask,int zoneMask,int r,int g,int b,int brightness,int speed,int ttl) {
        if (!canControl()){notifyStatus("Authorize BLE once while connected to CORE Wi-Fi");return;}
        if (effect<1||effect>5||chainMask<1||chainMask>3||zoneMask<1||zoneMask>255||
                brightness<0||brightness>32||speed<0||speed>100||ttl<1||ttl>60) {
            notifyStatus("Invalid BLE show settings");return;
        }
        enqueueWrite(new byte[]{1,2,(byte)effect,(byte)chainMask,(byte)zoneMask,
            (byte)r,(byte)g,(byte)b,(byte)brightness,(byte)speed,(byte)ttl});
    }
    void stopShow() {
        if (!canControl()) {notifyStatus("BLE show control not authorized");return;}
        enqueueWrite(new byte[]{1,3});
    }

    /** Serialize Android GATT operations; BLE GATT only allows one pending request. */
    private void enqueueWrite(byte[] data) {
        if (writePending || readReplyPending) {
            // One pending latest action; explicit STOP replaces queued starts.
            nextPacket=Arrays.copyOf(data,data.length);return;
        }
        pendingPacket=Arrays.copyOf(data,data.length);
        writeNow();
    }
    @SuppressWarnings({"MissingPermission","deprecation"})
    private void writeNow(){
        if(gatt==null||command==null||pendingPacket==null)return;
        byte[] packet=pendingPacket;
        writePending=true;
        try {
            boolean ok;
            if(Build.VERSION.SDK_INT>=33)
                ok=gatt.writeCharacteristic(command,packet,BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)==BluetoothStatusCodes.SUCCESS;
            else {
                command.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                command.setValue(packet);
                ok=gatt.writeCharacteristic(command);
            }
            if(!ok){writePending=false;authPending=false;notifyStatus("BLE write could not start");}
        }catch(SecurityException ex){writePending=false;authPending=false;notifyStatus("BLE permission missing");}
    }
    private void pumpQueue(){
        if (!writePending&&!readReplyPending&&nextPacket!=null){
            pendingPacket=nextPacket;nextPacket=null;writeNow();
        }
    }
    private String preferredPending = null;
    private Consumer<String> preferredListener;
    private static final long RECONNECT_DELAY_MS = 10000L;
    private long lastReconnectAttempt = 0L;

    void setPreferredListener(Consumer<String> listener) { this.preferredListener = listener; }

    /** One bounded background scan for the previously selected BLE address; no infinite reconnect loop. */
    void tryReconnect(String address) {
        if (stopped || connected || connecting || scanning || address == null || address.isEmpty()) return;
        if (android.os.SystemClock.elapsedRealtime() - lastReconnectAttempt < RECONNECT_DELAY_MS) return;
        if (Build.VERSION.SDK_INT >= 31 && (activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                || activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) return;
        if (Build.VERSION.SDK_INT < 31 && activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        lastReconnectAttempt = android.os.SystemClock.elapsedRealtime();
        preferredPending = address;
        beginScan(true);
    }

    BleDiscovery(Activity activity, StatusListener listener) {
        this.activity = activity;
        this.listener = listener;
        entries = new ArrayAdapter<>(activity, android.R.layout.simple_list_item_1, labels);
    }

    boolean handlePermissions(int requestCode, int[] results) {
        if (requestCode != REQUEST_NEARBY) return false;
        for (int status : results) {
            if (status != PackageManager.PERMISSION_GRANTED) {
                notifyStatus("Bluetooth permission denied; Wi-Fi Studio still works");
                return true;
            }
        }
        beginScan(false);
        return true;
    }

    void scan() {
        if (Build.VERSION.SDK_INT >= 31) {
            if (activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                    || activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[] {
                        Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
                }, REQUEST_NEARBY);
                return;
            }
        } else if (activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_NEARBY);
            return;
        }
        beginScan(false);
    }

    @SuppressWarnings("MissingPermission")
    private void beginScan(boolean background) {
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Activity.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            notifyStatus("Bluetooth LE is unavailable on this phone");
            return;
        }
        if (!adapter.isEnabled()) {
            notifyStatus("Enable Bluetooth in Android settings, then scan again");
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            notifyStatus("Bluetooth LE scanner unavailable");
            return;
        }
        stopScan();
        found.clear();
        labels.clear();
        entries.notifyDataSetChanged();
        if (!background) {
            preferredPending = null;
            scanDialog = new AlertDialog.Builder(activity)
                    .setTitle("Find OpenTail CORE")
                    .setAdapter(entries, (dialog, position) -> {
                        String address = new ArrayList<>(found.keySet()).get(position);
                        stopScan();
                        BluetoothDevice device = found.get(address);
                        if (device != null) connectReadOnly(device);
                    })
                    .setNegativeButton("Close", (dialog, which) -> stopScan())
                    .create();
            scanDialog.setOnDismissListener(dialog -> stopScan());
            scanDialog.show();
        }
        try {
            scanning = true;
            scanner.startScan(scanCallback);
            if (!background) notifyStatus("Scanning for OpenTail CORE (10 seconds)…");
            ui.postDelayed(() -> {
                if (!scanning) return;
                stopScan();
                if (!background) notifyStatus(found.isEmpty() ? "No OpenTail BLE advertisement detected" : "Scan complete; tap OpenTail CORE to connect");
                preferredPending = null;
            }, SCAN_DURATION_MS);
        } catch (SecurityException | IllegalStateException ex) {
            stopScan();
            notifyStatus("BLE scan couldn't start: " + ex.getMessage());
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            final String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
            if (name == null || !name.startsWith("OpenTail CORE")) return;
            ui.post(() -> {
                String address = result.getDevice().getAddress();
                if (!found.containsKey(address)) {
                    found.put(address, result.getDevice());
                    labels.add(name + "  •  " + address);
                    entries.notifyDataSetChanged();
                }
                if (preferredPending != null && preferredPending.equalsIgnoreCase(address)) {
                    preferredPending = null;
                    stopScan();
                    connectReadOnly(result.getDevice());
                }
            });
        }
        @Override public void onScanFailed(int errorCode) {
            ui.post(() -> { stopScan(); notifyStatus("BLE scan error " + errorCode); });
        }
    };

    @SuppressWarnings("MissingPermission")
    private void connectReadOnly(BluetoothDevice device) {
        if (Build.VERSION.SDK_INT >= 31
                && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            notifyStatus("Nearby-device permission required");
            return;
        }
        if (gatt != null) { gatt.close(); gatt = null; }
        authorized=false;command=null;reply=null;writePending=false;readReplyPending=false;nextPacket=null;
        connecting = true;
        connected = false;
        notifyStatus("Connecting to OpenTail BLE…");
        try { gatt = device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE); }
        catch (SecurityException ex) { connecting = false; notifyStatus("BLE connection permission denied"); }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @SuppressWarnings("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt connection, int status, int newState) {
            if (stopped) { connection.close(); return; }
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                connecting = false;
                connected = true;
                notifyStatus("BLE connected · reading status…");
                connection.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                connecting = false;
                connected = false;
                authorized = false;command=null;reply=null;writePending=false;readReplyPending=false;nextPacket=null;
                notifyStatus("BLE disconnected (GATT status " + status + ")");
                connection.close();
                if (gatt == connection) gatt = null;
            }
        }

        @SuppressWarnings("MissingPermission")
        @Override public void onServicesDiscovered(BluetoothGatt connection, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                notifyStatus("BLE service discovery failed: " + status);
                return;
            }
            BluetoothGattService service = connection.getService(SERVICE_UUID);
            BluetoothGattCharacteristic info = service == null ? null : service.getCharacteristic(INFO_UUID);
            if (info == null) {
                notifyStatus("BLE connected; no supported OpenTail info characteristic");
                return;
            }
            // Existing read-only connection remains compatible with older CORE firmware.
            command = service.getCharacteristic(COMMAND_UUID);
            reply = service.getCharacteristic(REPLY_UUID);
            authorized = false;
            if (preferredListener != null) preferredListener.accept(connection.getDevice().getAddress());
            connection.readCharacteristic(info);
        }

        @Override public void onCharacteristicRead(BluetoothGatt connection, BluetoothGattCharacteristic characteristic,
                                                    byte[] value, int status) {
            if (REPLY_UUID.equals(characteristic.getUuid())) { acceptReply(value,status);return; }
            if (INFO_UUID.equals(characteristic.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
                notifyStatus("BLE connected · " + new String(value, StandardCharsets.UTF_8));
            } else {
                notifyStatus("BLE connected; information read failed: " + status);
            }
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicRead(BluetoothGatt connection, BluetoothGattCharacteristic characteristic,
                                                    int status) {
            if (Build.VERSION.SDK_INT < 33) {
                if (REPLY_UUID.equals(characteristic.getUuid())) {
                    acceptReply(characteristic.getValue(),status);return;
                }
                if (INFO_UUID.equals(characteristic.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
                    byte[] value = characteristic.getValue();
                    notifyStatus("BLE connected · " + new String(value == null ? new byte[0] : value, StandardCharsets.UTF_8));
                } else notifyStatus("BLE connected; information read failed: " + status);
            }
        }
        @Override public void onCharacteristicWrite(BluetoothGatt connection,BluetoothGattCharacteristic characteristic,int status){
            if (!COMMAND_UUID.equals(characteristic.getUuid())) return;
            writePending=false;
            if(status!=BluetoothGatt.GATT_SUCCESS){
                authPending=false;authorized=false;
                notifyStatus("BLE write failed (GATT " + status + ")");pumpQueue();return;
            }
            if(reply==null){authPending=false;notifyStatus("CORE missing BLE reply characteristic");pumpQueue();return;}
            readReplyPending=true;
            try {
                if (!connection.readCharacteristic(reply)){
                    readReplyPending=false;authPending=false;
                    notifyStatus("Could not read CORE BLE result");pumpQueue();
                }
            } catch(SecurityException ex){readReplyPending=false;authPending=false;notifyStatus("BLE read permission missing");pumpQueue();}
        }
    };

    private void acceptReply(byte[] raw,int status){
        readReplyPending=false;
        String response = status==BluetoothGatt.GATT_SUCCESS && raw!=null
                ? new String(raw,StandardCharsets.US_ASCII) : "ERR READ";
        if(authPending){authorized="OK AUTH".equals(response);authPending=false;}
        if(response.startsWith("ERR"))notifyStatus("BLE · " + response + " (Wi-Fi control unaffected)");
        else notifyStatus("BLE · " + response + (authorized?" · lighting enabled":""));
        pumpQueue();
    }

    @SuppressWarnings("MissingPermission")
    void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCallback); }
        catch (SecurityException | IllegalStateException ignored) { }
    }

    @SuppressWarnings("MissingPermission")
    void shutdown() {
        stopped = true;
        connected = false;
        connecting = false;
        authorized = false;
        stopScan();
        if (scanDialog != null) { scanDialog.dismiss(); scanDialog = null; }
        if (gatt != null) { gatt.disconnect(); gatt.close(); gatt = null; }
    }

    private void notifyStatus(String message) {
        ui.post(() -> {
            if (!stopped) listener.onStatus(message);
        });
    }
}
