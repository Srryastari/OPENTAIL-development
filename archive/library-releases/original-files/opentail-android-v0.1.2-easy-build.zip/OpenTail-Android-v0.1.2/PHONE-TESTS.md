# Phone bench acceptance tests — v0.1.2

1. Install APK while saving/restoring Android v0.1.1 if needed. Verify launch, haptic tap, Wi-Fi Studio, saved projects, and prior BLE reconnect behavior.
2. With CORE v0.1.20 running, join `OpenTail-CORE-Alpha` Wi-Fi; connect BLE to `OpenTail CORE`, check familiar green/purple/teal onboard indicators.
3. Press **Enable BLE lighting**. Expect `OK AUTH`. If unavailable, check CORE version and Wi-Fi first.
4. Open **BLE Show Modes**; Output 2 with the physically connected 30-pixel test strip, Zone 1 (30 pixels), Solid Red, brightness 6, 5 seconds. Expect only this strip lit; no flash resets.
5. Open BLE Show Modes again; start Solid Green then STOP. Verify it stops and the rainbow onboard status returns to connection color.
6. Turn phone Wi-Fi off **after `OK AUTH`**, keep BLE connection. Start a 5-second Solid Blue show on Output 2; it should still function.
7. Disconnect BLE: show ends and BLE control authorization is cleared; connection can reconnect automatically but commands require another Wi-Fi authorization.
8. Verify standard Studio Wi-Fi Show Mode still works and saved trigger profiles/outputs survive ESP32 restart; do NOT repeat every previous 522 LED test unless a regression appears.

**Stop immediately if anything heats, resets, trips or flickers. Low brightness ≠ safe electrical current limit. Never test in actual road traffic.**
