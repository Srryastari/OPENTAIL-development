# OpenTail Android v0.1.2 — Wi-Fi + temporary BLE bench-show control

Android v0.1.1 native app, haptics, settings, automatic Wi-Fi/BLE reconnection, preferred BLE device, document import/export, and embedded Studio are retained.

## New

Native **Enable BLE lighting** and **BLE Show Modes** buttons. When CORE v0.1.20 is running and BLE is connected, authorize once **while connected to CORE Wi-Fi**. You may then disable Wi-Fi and send temporary Bluetooth-native shows (output, zone mask, mode, RGB, brightness, speed, start and stop). CORE trigger priority is unchanged; BLE cannot change road/trigger mapping.

Requires CORE v0.1.20+ for commands. The read-only BLE status still functions on older CORE. BLE must be reauthorized after each disconnect. New functionality has not been compiled with Android SDK or tested on phone here.

**Bench use only — this is not a vehicle safety controller.** BLE token is provisioned over WPA2 CORE AP and transferred over BLE without production-grade encryption/MITM protection. Do not use for road-lighting controls.

## Simple Windows build

Right-click ZIP → **Extract All**. Inside `OpenTail-Android-v0.1.2` double-click `BUILD-APK.bat`. It uses JDK 17/21, Android SDK 35, and Gradle 8.11.1. First build may download Gradle/dependencies. Only displays success if `app/build/outputs/apk/debug/app-debug.apk` exists.

Install the new APK over the existing debug-signed app. If signing differs, do not uninstall until your locally saved projects are exported.
