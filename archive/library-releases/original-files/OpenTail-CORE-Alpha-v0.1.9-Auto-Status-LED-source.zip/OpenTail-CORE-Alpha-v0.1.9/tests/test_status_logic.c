#include <assert.h>
#include <stdio.h>
#include "status_logic.h"
static int lit(ot_st_rgb_t c){return c.r||c.g||c.b;}
int main(void){
    int checks=0;
    #define CHECK(x) do{assert(x);++checks;}while(0)
    CHECK(lit(ot_st_render(OT_ST_STARTUP,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_STARTUP,299,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_STARTUP,300,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_WIFI,150,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,400,65,true)));
    CHECK(lit(ot_st_render(OT_ST_WIFI,1150,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,1400,65,true)));
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,0,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,120,65,true)));
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,240,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,360,65,true)));
    CHECK(lit(ot_st_render(OT_ST_DISCONNECTED,240,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,89,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,90,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,179,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,180,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,360,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,90,65,false))); /* off half stays off */
    CHECK(lit(ot_st_render(OT_ST_FAULT,0,5,false))); /* fault visible despite mute */
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,0,65,false)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,150,65,false)));
    CHECK(lit(ot_st_render(OT_ST_SHOW,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_SHOW,700,65,true)));
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).r==ot_st_render(OT_ST_SHOW,1400,65,true).r);
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).g==ot_st_render(OT_ST_SHOW,1400,65,true).g);
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).b==ot_st_render(OT_ST_SHOW,1400,65,true).b);
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,0,100,true)));
    CHECK(ot_st_render(OT_ST_CONNECTED,0,100,true).g>=ot_st_render(OT_ST_CONNECTED,0,50,true).g);
    printf("Passed %d onboard RGB timing assertions.\n",checks);
    return 0;
}
