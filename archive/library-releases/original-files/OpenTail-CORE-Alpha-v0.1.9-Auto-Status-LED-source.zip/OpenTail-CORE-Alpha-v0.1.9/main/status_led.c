#include "status_led.h"
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/portmacro.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "led_strip.h"
#include "led_strip_spi.h"
#include "driver/spi_master.h"
#include "board_config.h"

#define OT_ST_TICK_MS 10
#define OT_ST_HEARTBEAT_TIMEOUT_MS 8000
static const char *TAG="OT_STATUS_LED";
static portMUX_TYPE lock=portMUX_INITIALIZER_UNLOCKED;
static led_strip_handle_t status_pixel=NULL;
static bool available=false,wifi_ready=false,had_session=false,show_active=false,fault=false;
static uint32_t startup_ms=0,last_heartbeat_ms=0;
static uint32_t ms_now(void){return (uint32_t)(esp_timer_get_time()/1000LL);}

static ot_st_mode_t mode_at(uint32_t now){
    if(fault)return OT_ST_FAULT;
    if((uint32_t)(now-startup_ms)<300u)return OT_ST_STARTUP;
    if(show_active)return OT_ST_SHOW;
    if(had_session && (uint32_t)(now-last_heartbeat_ms)<OT_ST_HEARTBEAT_TIMEOUT_MS)return OT_ST_CONNECTED;
    if(had_session)return OT_ST_DISCONNECTED;
    if(wifi_ready)return OT_ST_WIFI;
    return OT_ST_OFF;
}
void ot_st_snapshot(ot_st_snapshot_t *out){
    if(!out)return;
    uint32_t now=ms_now();
    portENTER_CRITICAL(&lock);
    *out=(ot_st_snapshot_t){.available=available,.enabled=true,.wifi_ready=wifi_ready,
        .show_active=show_active,.ever_connected=had_session,.brightness=OT_ST_FIXED_BRIGHTNESS,.mode=mode_at(now)};
    portEXIT_CRITICAL(&lock);
}
void ot_st_wifi_ready(void){portENTER_CRITICAL(&lock);wifi_ready=true;portEXIT_CRITICAL(&lock);}
void ot_st_set_fault(const char *reason){
    portENTER_CRITICAL(&lock);fault=true;portEXIT_CRITICAL(&lock);
    ESP_LOGE(TAG,"CORE fault: %s",reason?reason:"unknown");
}
void ot_st_show_active(bool on){portENTER_CRITICAL(&lock);show_active=on;portEXIT_CRITICAL(&lock);}
void ot_st_session(bool active){
    uint32_t now=ms_now();portENTER_CRITICAL(&lock);
    if(active){had_session=true;last_heartbeat_ms=now;}
    else if(had_session)last_heartbeat_ms=now-OT_ST_HEARTBEAT_TIMEOUT_MS;
    portEXIT_CRITICAL(&lock);
}
void ot_st_format_json(char *buf,size_t size){
    ot_st_snapshot_t s;ot_st_snapshot(&s);
    snprintf(buf,size,"{\"supported\":true,\"available\":%s,\"enabled\":%s,\"brightness\":%u,\"mode\":\"%s\",\"gpio\":%u,\"studio_session_seen\":%s}",
        s.available?"true":"false",s.enabled?"true":"false",s.brightness,ot_st_mode_name(s.mode),
        (unsigned)OT_STATUS_LED_GPIO,s.ever_connected?"true":"false");
}
static void status_task(void *arg){
    (void)arg;ot_st_rgb_t prior={255,255,255};
    while(1){
        uint32_t now=ms_now();ot_st_snapshot_t s;ot_st_snapshot(&s);
        ot_st_rgb_t c=ot_st_render(s.mode,now-startup_ms,s.brightness,s.enabled);
        if(status_pixel && (c.r!=prior.r||c.g!=prior.g||c.b!=prior.b)){
            esp_err_t e=led_strip_set_pixel(status_pixel,0,c.r,c.g,c.b);
            if(e==ESP_OK)e=led_strip_refresh(status_pixel);
            if(e!=ESP_OK){ESP_LOGE(TAG,"Onboard RGB update failed: %s",esp_err_to_name(e));
                portENTER_CRITICAL(&lock);available=false;portEXIT_CRITICAL(&lock);status_pixel=NULL;
            }
        }
        prior=c;
        vTaskDelay(pdMS_TO_TICKS(OT_ST_TICK_MS));
    }
}
void ot_st_init(void){
    startup_ms=ms_now();
    const led_strip_config_t cfg={.strip_gpio_num=OT_STATUS_LED_GPIO,.max_leds=1,
        .led_model=LED_MODEL_WS2812,.color_component_format=LED_STRIP_COLOR_COMPONENT_FMT_GRB,
        .flags={.invert_out=false}};
    const led_strip_spi_config_t spi={.clk_src=SPI_CLK_SRC_DEFAULT,.spi_bus=SPI2_HOST,.flags={.with_dma=false}};
    esp_err_t e=led_strip_new_spi_device(&cfg,&spi,&status_pixel);
    if(e==ESP_OK){
        available=true;
        ESP_LOGI(TAG,"Onboard WS2812 status RGB initialized at GPIO%d via SPI2",OT_STATUS_LED_GPIO);
        e=led_strip_clear(status_pixel);
    }
    if(e!=ESP_OK){ESP_LOGE(TAG,"Onboard status LED unavailable: %s; continuing without it",esp_err_to_name(e));available=false;status_pixel=NULL;}
    if(xTaskCreate(status_task,"ot_status_rgb",4096,NULL,5,NULL)!=pdPASS){
        ESP_LOGE(TAG,"Could not start onboard RGB task");available=false;
    }
}
