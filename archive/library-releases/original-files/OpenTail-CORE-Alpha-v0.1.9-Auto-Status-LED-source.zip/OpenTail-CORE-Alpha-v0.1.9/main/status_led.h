#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "status_logic.h"
// Fixed onboard status LED brightness; not user-configurable.
#define OT_ST_FIXED_BRIGHTNESS 65u
typedef struct {
    bool available,enabled,wifi_ready,show_active,ever_connected;
    uint8_t brightness;
    ot_st_mode_t mode;
} ot_st_snapshot_t;
void ot_st_init(void);
void ot_st_wifi_ready(void);
void ot_st_set_fault(const char *reason);
void ot_st_show_active(bool on); // reserved until native Show Modes exist
void ot_st_session(bool active); // Studio heartbeat or explicit disconnect
void ot_st_snapshot(ot_st_snapshot_t *out);
void ot_st_format_json(char *buf,size_t size);
