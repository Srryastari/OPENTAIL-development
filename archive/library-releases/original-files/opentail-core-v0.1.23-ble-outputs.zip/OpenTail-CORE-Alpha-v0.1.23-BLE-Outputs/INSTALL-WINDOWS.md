# Windows ESP-IDF 5.5.5 / ESP32-S3

1. Extract next to the existing working v0.1.22 project in `Desktop\OpenTail`. This folder must be named `OpenTail-CORE-Alpha-v0.1.23-BLE-Outputs`.
2. Open **ESP-IDF 5.5 PowerShell** and run:

```powershell
cd "$env:USERPROFILE\Desktop\OpenTail\OpenTail-CORE-Alpha-v0.1.23-BLE-Outputs"
.\PREPARE-AND-BUILD.ps1
```

3. The script finds your existing custom AP password from v0.1.22 or v0.1.21, performs `idf.py reconfigure`, then `ninja -C build -j 2` (two workers to reduce compiler instability). It does **not** display or ship your password. If it cannot find a password, configure it with `idf.py menuconfig` and rerun.
4. Verify `Project build complete`, then flash using `idf.py -p COM9 flash` if COM9 is still your board's port. **Never run `erase-flash`**.
5. Install matching Android v0.1.11 app. Connect to controller using BLE, authorize once over CORE Wi-Fi, then switch to offline Studio and use Layout > Bluetooth Output Manager.

No `sdkconfig`, password, binaries, APK, or tested device flash is included. Keep original firmware for recovery.
