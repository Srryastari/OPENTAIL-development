# OpenTail CORE v0.1.23-alpha — BLE Output Manager transport

BENCH ONLY. No backup controller, vehicle-protected power, road-light fallback, or production BLE pairing.

Changes from verified v0.1.22: BLE output configuration transport added to existing protected 2-output architecture, no RMT output GPIO/pixel changes. Wi-Fi Studio v0.19.51 is EMBEDDED UNCHANGED. The existing Output Manager NVS `ot_output_cfg/profile_v2` and Trigger Manager `ot_trig_cfg/profile_v1` are preserved.

**Current security limitation:** BLE configuration requires the current Wi-Fi-issued, ephemeral token once per BLE connection. This is NOT zero-Wi-Fi BLE onboarding and NOT production secure pairing. No Wi-Fi password is included in the release. Production must use per-unit credential provisioning with authenticated/bonded BLE and secure authorization.

GATT characteristic UUIDs (little-endian NimBLE UUID definition): service `55a56022-4915-7a92-cf44-b8b7102eaf21`, config WRITE `...af25`, config READ `...af26`. Fixed 20-byte maximum framing supports minimum MTU. 261-byte serialized output, CRC16-CCITT and generation check prevent truncated/stale writes. The firmware writes NVS first, updates live output only after commit, and rejects writes while a show, demo, simulation, or physical trigger is active. No trigger profile BLE editing yet.

Keep v0.1.22 available for rollback. See `INSTALL-WINDOWS.md` and Android v0.1.11 package for first phone test. Python/host tests do not prove firmware compilation or BLE timing on the ESP32-S3.
