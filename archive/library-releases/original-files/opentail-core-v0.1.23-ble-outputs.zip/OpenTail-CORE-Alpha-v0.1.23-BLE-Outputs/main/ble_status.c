/* OpenTail CORE BLE v1: temporary authorized BENCH SHOW and Output Manager config commands.
 * This firmware has NO automotive-safe backup lighting or secure production pairing.
 * Provision a fresh 128-bit token on CORE WPA2 Wi-Fi; authorize one BLE connection.
 * Output mapping writes require the existing Wi-Fi-issued session token.
 * Do not use as a production pairing/security design.
 */
#include "sdkconfig.h"
#include "esp_log.h"
#include "esp_random.h"
#include "status_led.h"
#include "ble_command.h"
#include "ble_config.h"
#include <stdio.h>
#include <string.h>
extern bool ot_ble_apply_show(const ot_ble_show_packet_t *request);
extern void ot_ble_stop_show(void);
extern bool ot_ble_config_get(uint8_t index,ot_om_output_t *out,uint16_t *revision);
extern int ot_ble_config_save(uint8_t index,const ot_om_output_t *out,uint16_t base_revision);
static uint8_t token[OT_BLE_TOKEN_BYTES];
static bool token_ready=false;
void ot_ble_session_hex(char out[33]){
    if(!out)return;
    out[0]='\0';
    if(!token_ready)return;
    for(unsigned i=0;i<OT_BLE_TOKEN_BYTES;i++)snprintf(out+i*2,3,"%02x",token[i]);
}
#if CONFIG_BT_ENABLED && CONFIG_BT_NIMBLE_ENABLED
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "host/util/util.h"
#include "os/os_mbuf.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
static const char *TAG="OT_BLE";
static uint8_t addr_type;
static uint16_t active_conn=BLE_HS_CONN_HANDLE_NONE;
static bool authorized=false;
static ot_ble_result_t last_result=OT_BLE_ERR_AUTH;
static const ble_uuid128_t ot_service_uuid=BLE_UUID128_INIT(0x21,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_info_uuid=BLE_UUID128_INIT(0x22,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_cmd_uuid=BLE_UUID128_INIT(0x23,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_cfg_cmd_uuid=BLE_UUID128_INIT(0x25,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_cfg_rsp_uuid=BLE_UUID128_INIT(0x26,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static const ble_uuid128_t ot_reply_uuid=BLE_UUID128_INIT(0x24,0xaf,0x2e,0x10,0xb7,0xb8,0x44,0xcf,0x92,0x7a,0x15,0x49,0x22,0x60,0xa5,0x55);
static int info_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)conn;(void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    const char *message="OpenTail CORE 0.1.23 | BLE show + outputs v1 | Wi-Fi authorization required";
    return os_mbuf_append(ctx->om,message,strlen(message))==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int reply_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    const char *result=conn==active_conn?ot_ble_result_string(last_result):"ERR AUTH";
    return os_mbuf_append(ctx->om,result,strlen(result))==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int command_write(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_WRITE_CHR || conn!=active_conn)return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t buf[20];uint16_t n=0;
    if(ble_hs_mbuf_to_flat(ctx->om,buf,sizeof(buf),&n)!=0){last_result=OT_BLE_ERR_WIRE;return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;}
    ot_ble_show_packet_t show={0};
    last_result=ot_ble_parse(buf,n,token,&authorized,&show);
    if(last_result==OT_BLE_OK_SHOW && !ot_ble_apply_show(&show))last_result=OT_BLE_ERR_BUSY;
    if(last_result==OT_BLE_OK_STOP)ot_ble_stop_show();
    /* Errors are returned by read-only reply characteristic; always acknowledge write. */
    return 0;
}
/* BLE Output Config v1: fixed 20-byte frames work even at minimum ATT MTU=23.
 * No configuration is applied until CRC, zone validation, trigger-idle check,
 * NVS persistence, and session revision checks ALL succeed.
 */
static uint8_t cfg_snapshot[OT_CFG_WIRE_BYTES],cfg_upload[OT_CFG_WIRE_BYTES];
static bool cfg_received[OT_CFG_WIRE_BYTES];
static uint16_t cfg_read_revision=0,cfg_upload_revision=0,cfg_upload_crc=0;
static uint8_t cfg_read_index=255,cfg_upload_index=255;
static uint8_t cfg_response[OT_CFG_PACKET_BYTES]={2,0xff,0,5};
static uint8_t cfg_response_len=4;
static void cfg_ack(uint8_t opcode,uint8_t index,uint8_t code){
    memset(cfg_response,0,sizeof(cfg_response));cfg_response[0]=2;
    cfg_response[1]=(uint8_t)(0x80u|opcode);cfg_response[2]=index;
    cfg_response[3]=code;cfg_response_len=4;
}
static void cfg_reset(void){
    cfg_read_index=255;cfg_upload_index=255;
    memset(cfg_received,0,sizeof(cfg_received));cfg_ack(0x7f,0,5);
}
static int cfg_read(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_READ_CHR)return BLE_ATT_ERR_UNLIKELY;
    if(conn!=active_conn)return BLE_ATT_ERR_READ_NOT_PERMITTED;
    return os_mbuf_append(ctx->om,cfg_response,cfg_response_len)==0?0:BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int cfg_write(uint16_t conn,uint16_t handle,struct ble_gatt_access_ctxt *ctx,void *arg){
    (void)handle;(void)arg;
    if(ctx->op!=BLE_GATT_ACCESS_OP_WRITE_CHR||conn!=active_conn)return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t packet[OT_CFG_PACKET_BYTES];uint16_t n=0;
    if(ble_hs_mbuf_to_flat(ctx->om,packet,sizeof(packet),&n)!=0||n<3||packet[0]!=2){
        cfg_ack(0x7f,0,1);return 0;
    }
    const uint8_t opcode=packet[1],index=packet[2];
    cfg_ack(opcode,index,0);
    if(!authorized){cfg_ack(opcode,index,5);return 0;}
    if(index>=OT_OM_OUTPUTS){cfg_ack(opcode,index,1);return 0;}
    switch(opcode){
        case 1: { /* snapshot */
            if(n!=3){cfg_ack(opcode,index,1);break;}
            ot_om_output_t output;
            if(!ot_ble_config_get(index,&output,&cfg_read_revision)){cfg_ack(opcode,index,4);break;}
            ot_cfg_encode(&output,cfg_snapshot);cfg_read_index=index;
            const uint16_t crc=ot_cfg_crc16(cfg_snapshot,OT_CFG_WIRE_BYTES);
            cfg_response[4]=(uint8_t)OT_CFG_WIRE_BYTES;
            cfg_response[5]=(uint8_t)(OT_CFG_WIRE_BYTES>>8);
            cfg_response[6]=(uint8_t)crc;cfg_response[7]=(uint8_t)(crc>>8);
            cfg_response[8]=(uint8_t)cfg_read_revision;
            cfg_response[9]=(uint8_t)(cfg_read_revision>>8);
            cfg_response_len=10;break;
        }
        case 2: { /* chunk read */
            if(n!=5||cfg_read_index!=index){cfg_ack(opcode,index,1);break;}
            const uint16_t off=(uint16_t)(packet[3]|((unsigned)packet[4]<<8));
            if(off>=OT_CFG_WIRE_BYTES){cfg_ack(opcode,index,1);break;}
            unsigned count=OT_CFG_WIRE_BYTES-off;
            if(count>14u)count=14u;
            cfg_response[4]=packet[3];cfg_response[5]=packet[4];
            memcpy(cfg_response+6,cfg_snapshot+off,count);cfg_response_len=(uint8_t)(6+count);
            break;
        }
        case 3: { /* begin upload */
            if(n!=9){cfg_ack(opcode,index,1);break;}
            const uint16_t len=(uint16_t)(packet[3]|((unsigned)packet[4]<<8));
            if(len!=OT_CFG_WIRE_BYTES){cfg_ack(opcode,index,1);break;}
            cfg_upload_crc=(uint16_t)(packet[5]|((unsigned)packet[6]<<8));
            cfg_upload_revision=(uint16_t)(packet[7]|((unsigned)packet[8]<<8));
            cfg_upload_index=index;memset(cfg_upload,0,sizeof(cfg_upload));
            memset(cfg_received,0,sizeof(cfg_received));break;
        }
        case 4: { /* upload 1-15 bytes */
            if(n<6||cfg_upload_index!=index){cfg_ack(opcode,index,1);break;}
            const uint16_t off=(uint16_t)(packet[3]|((unsigned)packet[4]<<8));
            const unsigned count=n-5;
            if(count>OT_CFG_CHUNK_BYTES||off>=OT_CFG_WIRE_BYTES||off+count>OT_CFG_WIRE_BYTES){cfg_ack(opcode,index,1);break;}
            memcpy(cfg_upload+off,packet+5,count);
            for(unsigned i=off;i<off+count;i++)cfg_received[i]=true;
            break;
        }
        case 5: { /* commit */
            if(n!=3||cfg_upload_index!=index){cfg_ack(opcode,index,1);break;}
            for(unsigned i=0;i<OT_CFG_WIRE_BYTES;i++){
                if(!cfg_received[i]){cfg_ack(opcode,index,1);cfg_upload_index=255;return 0;}
            }
            if(ot_cfg_crc16(cfg_upload,OT_CFG_WIRE_BYTES)!=cfg_upload_crc){
                cfg_ack(opcode,index,6);cfg_upload_index=255;break;
            }
            ot_om_output_t output;
            if(!ot_cfg_decode(cfg_upload,&output)){cfg_ack(opcode,index,1);cfg_upload_index=255;break;}
            const int rc=ot_ble_config_save(index,&output,cfg_upload_revision);
            cfg_ack(opcode,index,(uint8_t)rc);cfg_upload_index=255;
            break;
        }
        case 6: { /* cancel */
            if(n!=3){cfg_ack(opcode,index,1);break;}
            cfg_upload_index=255;break;
        }
        default:cfg_ack(opcode,index,1);break;
    }
    return 0;
}
static const struct ble_gatt_chr_def characteristics[]={
  {.uuid=&ot_info_uuid.u,.access_cb=info_read,.flags=BLE_GATT_CHR_F_READ},
  {.uuid=&ot_cmd_uuid.u,.access_cb=command_write,.flags=BLE_GATT_CHR_F_WRITE},
  {.uuid=&ot_reply_uuid.u,.access_cb=reply_read,.flags=BLE_GATT_CHR_F_READ},
  {.uuid=&ot_cfg_cmd_uuid.u,.access_cb=cfg_write,.flags=BLE_GATT_CHR_F_WRITE},
  {.uuid=&ot_cfg_rsp_uuid.u,.access_cb=cfg_read,.flags=BLE_GATT_CHR_F_READ},
  {0}
};
static const struct ble_gatt_svc_def services[]={
  {.type=BLE_GATT_SVC_TYPE_PRIMARY,.uuid=&ot_service_uuid.u,.characteristics=characteristics},{0}
};
static int gap_event(struct ble_gap_event *ev,void *arg);
static void advertise(void){
    struct ble_hs_adv_fields fields={0};
    fields.flags=BLE_HS_ADV_F_DISC_GEN|BLE_HS_ADV_F_BREDR_UNSUP;
    const char *name=ble_svc_gap_device_name();
    fields.name=(uint8_t*)name;fields.name_len=strlen(name);fields.name_is_complete=1;
    int rc=ble_gap_adv_set_fields(&fields);
    if(rc){ESP_LOGE(TAG,"Advertising fields failed: %d",rc);return;}
    struct ble_gap_adv_params p={0};p.conn_mode=BLE_GAP_CONN_MODE_UND;p.disc_mode=BLE_GAP_DISC_MODE_GEN;
    rc=ble_gap_adv_start(addr_type,NULL,BLE_HS_FOREVER,&p,gap_event,NULL);
    if(rc)ESP_LOGE(TAG,"Advertising failed: %d",rc);
}
static int gap_event(struct ble_gap_event *ev,void *arg){
    (void)arg;
    if(ev->type==BLE_GAP_EVENT_CONNECT){
        if(ev->connect.status==0){active_conn=ev->connect.conn_handle;authorized=false;last_result=OT_BLE_ERR_AUTH;ot_st_ble_connected(true);cfg_reset();}
        else advertise();
    }else if(ev->type==BLE_GAP_EVENT_DISCONNECT){
        active_conn=BLE_HS_CONN_HANDLE_NONE;authorized=false;last_result=OT_BLE_ERR_AUTH;
        ot_st_ble_connected(false);ot_ble_stop_show();cfg_reset();advertise();
    }else if(ev->type==BLE_GAP_EVENT_ADV_COMPLETE)advertise();
    return 0;
}
static void on_sync(void){
    int rc=ble_hs_util_ensure_addr(0);
    if(!rc)rc=ble_hs_id_infer_auto(0,&addr_type);
    if(rc){ESP_LOGE(TAG,"BLE address error: %d",rc);return;}
    advertise();
}
static void host_task(void *arg){(void)arg;nimble_port_run();nimble_port_freertos_deinit();}
void ot_ble_start(void){
    esp_fill_random(token,sizeof(token));
    token_ready=true;
    esp_err_t err=nimble_port_init();
    if(err!=ESP_OK){token_ready=false;ESP_LOGE(TAG,"NimBLE init failed: %s",esp_err_to_name(err));return;}
    ble_svc_gap_init();ble_svc_gatt_init();
    int rc=ble_svc_gap_device_name_set("OpenTail CORE");
    if(!rc)rc=ble_gatts_count_cfg(services);
    if(!rc)rc=ble_gatts_add_svcs(services);
    if(rc){token_ready=false;ESP_LOGE(TAG,"BLE service registration failed: %d",rc);return;}
    ble_hs_cfg.sync_cb=on_sync;
    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG,"BLE show and Output Manager ready. Wi-Fi token required after each BLE connection.");
}
#else
void ot_ble_start(void){token_ready=false;}
#endif
