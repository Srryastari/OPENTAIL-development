# v0.1.23-alpha — development, unflashed
- Added Output Manager BLE read/write through `af25`/`af26` GATT characteristics.
- Explicit 261-byte ABI-independent binary codec and CRC16 checks; host codec tests.
- Atomic per-output save to existing NVS v2, rejects live triggers/shows; stale-revision protection across Wi-Fi and BLE.
- No changes to electrical input/output GPIO, LED rendering, trigger logic, WS2815 wiring, or embedded Studio v0.19.51.
- BLE still requires Wi-Fi-issued temporary token for each connection; trigger-manager BLE editing and secure BLE-only onboarding remain future work.
