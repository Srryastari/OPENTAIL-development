OpenTail Studio v0.16.1 — UI State & Navigation Revision

Upload ONLY opentail.htm to the WLED /edit page, not this ZIP.
Open http://4.3.2.1/opentail.htm?v=161

Changes:
- Navigation: Dashboard, Connect, Show Modes, Builder, Arrangement, Diagnostics.
- Selected effect highlighting is session-local and distinct from controller RUNNING readback.
- Builder trigger editing selection and bench ACTIVE state are visually distinct.
- Section and preview selections clear on switching tabs.
- Temporary UI state resets on reopening; saved profiles, section mapping/names, favorites and controller address persist.
- Multi-zone trigger playback from v0.16.0 retained.

Safety: Bench/show use only. WLED controller effects are not a road-lighting failsafe.
Verification: JavaScript syntax and ZIP integrity checked; physical GLEDOPTO test required.
