OpenTail Studio interactive UI prototype. Open index.html in a browser. This is a design prototype only and intentionally does not connect to WLED or persist changes.
