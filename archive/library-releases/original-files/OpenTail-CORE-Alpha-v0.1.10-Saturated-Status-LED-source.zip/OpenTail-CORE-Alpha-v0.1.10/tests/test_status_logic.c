#include <assert.h>
#include <stdio.h>
#include "status_logic.h"
static int lit(ot_st_rgb_t c){return c.r||c.g||c.b;}
int main(void){
    int checks=0;
    #define CHECK(x) do{assert(x);++checks;}while(0)
    CHECK(lit(ot_st_render(OT_ST_STARTUP,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_STARTUP,299,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_STARTUP,300,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_WIFI,150,65,true)));
    ot_st_rgb_t wifi_blue=ot_st_render(OT_ST_WIFI,150,100,true);
    CHECK(wifi_blue.b==255);
    CHECK(wifi_blue.b>wifi_blue.g && wifi_blue.g==wifi_blue.r);
    CHECK(wifi_blue.r==0 && wifi_blue.g==0);
    /* Pure primaries prevent pastel/pink/washed-out status hues. */
    ot_st_rgb_t green=ot_st_render(OT_ST_CONNECTED,0,100,true);
    ot_st_rgb_t red=ot_st_render(OT_ST_DISCONNECTED,0,100,true);
    ot_st_rgb_t fault=ot_st_render(OT_ST_FAULT,0,100,true);
    CHECK(green.r==0 && green.g==255 && green.b==0);
    CHECK(red.r==255 && red.g==0 && red.b==0);
    CHECK(fault.r==255 && fault.g==0 && fault.b==0);
    ot_st_rgb_t rainbow_red=ot_st_render(OT_ST_SHOW,0,100,true);
    ot_st_rgb_t rainbow_cyan=ot_st_render(OT_ST_SHOW,700,100,true);
    CHECK(rainbow_red.r==255 && rainbow_red.g==0 && rainbow_red.b==0);
    CHECK(rainbow_cyan.r==0 && rainbow_cyan.g==255 && rainbow_cyan.b==255);
    CHECK(!lit(ot_st_render(OT_ST_WIFI,400,65,true)));
    CHECK(lit(ot_st_render(OT_ST_WIFI,1150,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,1400,65,true)));
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,0,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,120,65,true)));
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,240,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,360,65,true)));
    CHECK(lit(ot_st_render(OT_ST_DISCONNECTED,240,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,89,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,90,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,179,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,180,65,true)));
    CHECK(lit(ot_st_render(OT_ST_FAULT,360,65,true)));
    CHECK(!lit(ot_st_render(OT_ST_FAULT,90,65,false))); /* off half stays off */
    CHECK(lit(ot_st_render(OT_ST_FAULT,0,5,false))); /* fault visible despite mute */
    CHECK(!lit(ot_st_render(OT_ST_CONNECTED,0,65,false)));
    CHECK(!lit(ot_st_render(OT_ST_WIFI,150,65,false)));
    CHECK(lit(ot_st_render(OT_ST_SHOW,0,65,true)));
    CHECK(lit(ot_st_render(OT_ST_SHOW,700,65,true)));
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).r==ot_st_render(OT_ST_SHOW,1400,65,true).r);
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).g==ot_st_render(OT_ST_SHOW,1400,65,true).g);
    CHECK(ot_st_render(OT_ST_SHOW,0,65,true).b==ot_st_render(OT_ST_SHOW,1400,65,true).b);
    CHECK(lit(ot_st_render(OT_ST_CONNECTED,0,100,true)));
    CHECK(ot_st_render(OT_ST_CONNECTED,0,100,true).g>=ot_st_render(OT_ST_CONNECTED,0,50,true).g);
    printf("Passed %d onboard RGB timing assertions.\n",checks);
    return 0;
}
