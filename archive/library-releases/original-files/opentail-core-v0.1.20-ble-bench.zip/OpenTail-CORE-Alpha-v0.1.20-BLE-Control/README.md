# OpenTail CORE Alpha v0.1.20 — BLE Bench Show Control

**BENCH USE ONLY. NOT FOR ROAD LIGHTING OR PUBLIC INSTALLATION.** No fail-safe controller, no independently validated input isolation, no electrical capacity validation, no authenticated production BLE pairing, no safety certification.

## Added

- Keeps the same GPIO16/GPIO17 pixel hardware, 8 optical trigger GPIOs, zone maps, output and trigger NVS schemas, saved GRB/BRG configuration, native effect rendering, and existing Wi-Fi Studio API.
- BLE service keeps its already-tested name and read-only information characteristic.
- New **temporary 128-bit BLE session token** generated at CORE boot. Android obtains it from the CORE WPA2 Wi-Fi network at `GET /api/v1/ble/session`. The token is RAM-only and never included in BLE advertisements or diagnostic logs.
- Android sends token through BLE AUTH GATT write. Subsequent commands on **that BLE connection** control short-lived native shows (`solid`, `chase`, `breathe`, `wipe`, `rainbow`) for either/both outputs, specified zones, custom RGB, limited brightness and speed. Stop cancels a BLE-owned show.
- Disconnect ends BLE authorization and stops BLE-owned shows, *not* a newer Wi-Fi-owned show. An existing physical input always retains priority in the renderer.
- BLE cannot modify/disable vehicle triggers, saved outputs, GPIOs or NVS mappings. Any show automatically ends after 1–60 seconds. LED color brightness cap is 32/255, **not** an electrical current limiter.

## Limits / security

The temporary token is provisioned over plain HTTP on CORE's WPA2-protected local AP and sent over BLE without production-grade link encryption or MITM-resistant pairing. This is **only suitable for an isolated, supervised bench prototype**. Never use as a vehicle's sole or road-use lighting controller.

For the first authorization each BLE connection: connect Android to `OpenTail-CORE-Alpha` Wi-Fi, connect OpenTail Android by BLE, tap **Enable BLE lighting**. Once authorized, you can turn off Wi-Fi and use **BLE Show Modes** until BLE disconnects or CORE restarts. Repeat authorization after reconnection.

## Build

Open ESP-IDF 5.5.5 PowerShell in this directory; do not erase flash. Before compilation, restore your custom AP password from the existing project using `INSTALL-WINDOWS.md`, then run `idf.py build` and `idf.py -p COM9 flash monitor` only **after** seeing `Project build complete`.

## Test status

C host logic tests and Studio simulated API tests are run by `python qa/run-regression.py`. An actual ESP-IDF build, Android SDK build, Android Bluetooth control, and vehicle-safety testing **have not** been performed here.
