# OpenTail release notes

## CORE Alpha v0.1.20 / Studio v0.19.47

- Added BLE temporary Wi-Fi-provisioned authorization and BLE GATT commands for native bench shows only.
- Preserved BLE discovery and informational GATT characteristic UUIDs.
- Added write-command and read-result characteristics, 60-second maximum show duration and 32/255 brightness ceiling.
- Preserved current Wi-Fi APIs, Output Manager v2, Trigger Manager v1, saved settings, GPIO16/17, input pins, priority handling, and onboard RGB status animations.
- Included status LED purple/teal tuning from the v0.1.19 source baseline; this has not yet been tested on actual hardware.
- Included Studio v0.19.47 in standalone and stable .htm filenames and embedded gzip copy.
- Host regression includes BLE authentication and malformed-frame tests; user hardware and SDK compile still pending.

No 12-output hardware, automotive failover, encrypted production pairing, CAN bus, or road-ready trigger safety is implied.
